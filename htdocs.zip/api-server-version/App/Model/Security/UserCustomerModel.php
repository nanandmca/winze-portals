<?php

    namespace App\Model\Security;

    use App\Model\Security\SecurityModel;

    /**
     * UserModel - This Model is consumed basically by the UserController and is also consumed by other controllers and Middlewares...
     *
     * @author      Ilori Stephen A <stephenilori458@gmail.com>
     * @link        https://github.com/learningdollars/php-rest-api/App/Model/UserModel.php
     * @license     MIT
     */
    class UserCustomerModel extends SecurityModel {

        public static function getActiveCompanyDetails($email)
        {
            $Response = [];
            $Response["id"] = "1";
            $Response["code"] = "C01";
            $Response["companyName"] = "Hiranandani";
            $Response["contact_email"] = "contact@hiranandani.com";
            $Response["contact_phone"] = "95657657667";
            $Response["active"] = "Y";
            return $Response;
        }

        public static function isIndividualCustomerDetails($email)
        {
            $Response = [];
            $Response["id"] = "2";
            $Response["code"] = "C01";
            $Response["name"] = "Hiranandani";
            $Response["email"] = "contact@hiranandani.com";
            $Response["phone"] = "95657657667";
            $Response["active"] = "Y";
            return $Response;
        }

    }
?>
