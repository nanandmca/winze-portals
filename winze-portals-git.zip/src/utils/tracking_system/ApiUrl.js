let trackingSystemDomainUrl = "http://projects.winzetech.com";

try{
    let tempTrackingSystemDomain = eval("window.trackingSystemDomain");
    if(tempTrackingSystemDomain != undefined){
        trackingSystemDomainUrl = tempTrackingSystemDomain;
    }
}catch (err){
    console.log("Error while retrieve domain URL");
}

export const overallSummaryUrl = trackingSystemDomainUrl + "/api/v1/project/overallSummary";
export const projectsUrl = trackingSystemDomainUrl + "/api/v1/projects";
export const projectAccessUrl = trackingSystemDomainUrl + "/api/v1/projects-access";
export const modifiedLogsUrl = trackingSystemDomainUrl + "/api/v1/project/modifiedLogs";
export const modifiedLogsForProjectUrl = trackingSystemDomainUrl + "/api/v1/project/modifiedLogsForProject";
export const securityRoomsUrl = trackingSystemDomainUrl + "/api/v1/project/modifiedLogsForProject";
export const updateStatusUrl = trackingSystemDomainUrl + "/api/v1/project/updateStatus";
export const updateServerUrl = trackingSystemDomainUrl + "/api/v1/project/updateServer";
export const serverUrl = trackingSystemDomainUrl + "/api/v1/project/serverRooms";
export const serverLogsUrl = trackingSystemDomainUrl + "/api/v1/project/serverRoomsLogs";
export const serverLogsForProjectUrl = trackingSystemDomainUrl + "/api/v1/project/serverRoomsLogsForProject";
export const cleanCacheUrl = trackingSystemDomainUrl + "/api/v1/project/cleanCache";

