<?php

namespace App\Utils\TrackingSystem;

class OverallStatusFilter
{
    private $projectName;
    private $status;

    function __construct($projectName, $status) {
        $this->projectName = $projectName;
        $this->status = $status;
    }

    function getStatusCount($data) {
        $statusFlag = false;
        $logReqd = false;
        //echo "data -> " . gettype($data);
        //echo "occupied -> " . empty($data->occupied) ? 'Empty' : $data->occupied;
        /*if($data["projectName"] === "VDP-Calgary" && $data["wing"] === "D"
                    && $data["floorNo"] === 2 && $data["roomNo"] === 204){
            $logReqd = true;
        }*/
        if(in_array($this->status, TrackingSystemConstants::$directStatusList, TRUE)){
            if($this->status === 'occupied'
                && !empty($data->occupied)
                && $data->occupied === 'Yes'){
                $statusFlag = true;
            }
            if($this->status === 'notOccupied'
                && (empty($data->occupied) || $data->occupied === 'No')){
                $statusFlag = true;
            }
        }else if(in_array($this->status, TrackingSystemConstants::$inDirectStatusList, TRUE)){
            if(isset(TrackingSystemConstants::$inDirectStatusFields[$this->status])){
                $fieldExists = false;
                foreach (TrackingSystemConstants::$inDirectStatusFields[$this->status] as $inDirectField) {
                    //if($logReqd) echo "\ninDirectField : " . json_encode($inDirectField);
                    if(!empty($data->$inDirectField )){
                        $fieldExists = true;
                        if($data->$inDirectField === $this->status){
                            $statusFlag = true;
                            break;
                        }else if($this->status === "notStarted" && $data->$inDirectField === ""){
                            $statusFlag = true;
                            break;
                        }
                      }
                }
                if(!$fieldExists && $this->status === "notStarted"){
                    $statusFlag = true;
                }
                if($logReqd) echo "\nfieldExists : " . json_encode($fieldExists) . ", statusFlag : " . json_encode($statusFlag) . ", status : " . $this->status;
            }
        }

        //echo "\nprojectName : " . $this->projectName . ", : status : " . $this->status . ", : data : " . json_encode($data);
        //echo '\nprojectName : ' . $this->projectName . ', : ' . $data['projectName'] . ' -> ' . ($data['projectName'] === $this->projectName  && $statusFlag);
        return $data->projectName === $this->projectName && $statusFlag;
        //return false;
    }

}