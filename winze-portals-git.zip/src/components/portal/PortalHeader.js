import React from 'react';
import AppBar from '@material-ui/core/AppBar';
import CssBaseline from '@material-ui/core/CssBaseline';
import {PortalTopNav} from "./PortalTopNav";
import {makeStyles} from "@material-ui/core/styles";

const drawerWidth = 200;
const useStyles = makeStyles((theme) => ({
    appBar: {
        [theme.breakpoints.up('sm')]: {
            width: `calc(100% - ${drawerWidth}px)`,
            marginLeft: drawerWidth,
        },
    }
}));

export const PortalHeader = () => {
    const classes = useStyles();

    return (
        <>
            <CssBaseline />
            <AppBar position="fixed" className={classes.appBar}>
                <PortalTopNav/>
            </AppBar>
        </>
    )
}