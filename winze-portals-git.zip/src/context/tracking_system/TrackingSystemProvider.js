import React from 'react'

const TrackingSystemStateContext = React.createContext()
const TrackingSystemDispatchContext = React.createContext()

function trackingSystemReducer(state, action) {
    switch (action.type) {
        case 'increment': {
            return {count: state.count + 1}
        }
        case 'decrement': {
            return {count: state.count - 1}
        }
        default: {
            throw new Error(`Unhandled action type: ${action.type}`)
        }
    }
}

function TrackingSystemProvider({children}) {
    const [state, dispatch] = React.useReducer(trackingSystemReducer, {count: 0})
    return (

        <TrackingSystemStateContext.Provider value={state}>
            <TrackingSystemDispatchContext.Provider value={dispatch}>
                {children}
            </TrackingSystemDispatchContext.Provider>
        </TrackingSystemStateContext.Provider>
    )
}

function useTrackingSystemState() {
    const context = React.useContext(TrackingSystemStateContext)
    if (context === undefined) {
        throw new Error('useTrackingSystemState must be used within a TrackingSystemProvider')
    }
    return context
}

function useTrackingSystemDispatch() {
    const context = React.useContext(TrackingSystemDispatchContext)
    if (context === undefined) {
        throw new Error('useTrackingSystemDispatch must be used within a TrackingSystemProvider')
    }
    return context
}

export {TrackingSystemProvider, useTrackingSystemState, useTrackingSystemDispatch}