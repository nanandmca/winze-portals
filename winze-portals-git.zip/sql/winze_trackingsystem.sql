-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.3.13-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table winze_tracking_system.db_service_company_mapping
CREATE TABLE IF NOT EXISTS `db_service_company_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `service_company_id` int(11) NOT NULL,
  `active_flag` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_service_company_id` (`company_id`,`service_company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table winze_tracking_system.db_service_company_mapping: ~3 rows (approximately)
/*!40000 ALTER TABLE `db_service_company_mapping` DISABLE KEYS */;
INSERT INTO `db_service_company_mapping` (`id`, `company_id`, `service_company_id`, `active_flag`) VALUES
	(1, 2, 1, 'Y'),
	(2, 3, 1, 'Y'),
	(3, 4, 1, 'Y');
/*!40000 ALTER TABLE `db_service_company_mapping` ENABLE KEYS */;

-- Dumping structure for table winze_tracking_system.db_service_users
CREATE TABLE IF NOT EXISTS `db_service_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `service_company_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `active_flag` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_service_company_id_user_id` (`company_id`,`service_company_id`,`user_id`),
  CONSTRAINT `FK2_SERVICE_USERS_SERVICE_COMPANY_ID` FOREIGN KEY (`company_id`, `service_company_id`) REFERENCES `db_service_company_mapping` (`company_id`, `service_company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table winze_tracking_system.db_service_users: ~5 rows (approximately)
/*!40000 ALTER TABLE `db_service_users` DISABLE KEYS */;
INSERT INTO `db_service_users` (`id`, `company_id`, `service_company_id`, `user_id`, `active_flag`) VALUES
	(1, 2, 1, 3, 'Y'),
	(2, 3, 1, 3, 'Y'),
	(3, 4, 1, 3, 'Y'),
	(5, 2, 1, 7, 'Y'),
	(6, 3, 1, 7, 'Y'),
	(7, 4, 1, 7, 'Y');
/*!40000 ALTER TABLE `db_service_users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
