import {getJwtToken} from '../../utils/security/SecurityUtils'
import {SESSION_EXPIRED} from '../../utils/portal/PortalAction';

export const checkSessionExpired = function (portalDispatch, errorResponse){
    if(errorResponse && errorResponse.header && errorResponse.status && errorResponse.status == 400){
        portalDispatch({type: SESSION_EXPIRED})
    }
}

export const populateErrorResponse = function (errorData, errorCode, errorMessage, portalDispatch){
    let status = 500;
    let errorResponseData = {};
    if (errorData && errorData.response) {
        errorResponseData = errorData.response.data;
        status = errorData.response.status;
    }
    console.log("populateErrorResponse -> portalDispatch status " + status);
    console.log("populateErrorResponse -> portalDispatch Fun " + portalDispatch);
    if(portalDispatch && status == 401){
        console.log("populateErrorResponse -> Before portalDispatch Call ");
        portalDispatch({type: SESSION_EXPIRED})
    }
    return {
        header:{
            success: false,
            errorCode: errorCode,
            errorMessage: errorMessage,
            status: status,
            data: errorResponseData
        }
    };
}

export const populateGetHeader = function (headerData, bearerTokenRequired){
    let header = {};
    let token = getJwtToken();
    header["Access-Control-Allow-Origin"] = "*";
    //header["Access-Control-Allow-Credentials"] = true;
    //header["Cookie"] = document.cookie;
    if(bearerTokenRequired){
        header["authorization"] = "Bearer " + token;
    }
    if(headerData){
        Object.keys(headerData).map(function(key) {
            return header[key] = headerData[key];
        });
    }
    console.log("populateGetHeader " + JSON.stringify(header));
    return header;
}

export const populatePostHeader = function (headerData, bearerTokenRequired){
    let header = populateGetHeader(headerData, bearerTokenRequired);
    header["Content-Type"] = "application/json";
    console.log("populatePostHeader " + JSON.stringify(header));
    return header;
}

export const populateSuccessResponse = function (responseData, code, message){
    return {
        header:{
            success: true,
            code: code,
            message: message
        },
        payload: responseData
    };
}

export const isValidServiceResponse = function (responseData){
    if(responseData && responseData.header && responseData.header.success){
        return true;
    }
    return false;
}

export const getSuccessResponseData = function (responseData){
    if(responseData && responseData.payload){
        return responseData.payload;
    }
    return {};
}

export const getFailureResponseData = function (responseData){
    console.log("getFailureResponseData -> responseData -> " + JSON.stringify(responseData));
    if(responseData && responseData.header){
        return responseData.header;
    }
    return {};
}