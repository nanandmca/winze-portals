
let consoleLog = true;
export const getNonObjectCacheValue = function (cacheKey){
    if(consoleLog) console.log("getNonObjectCacheValue " + cacheKey + " -> " + sessionStorage.getItem(cacheKey));
    return sessionStorage.getItem(cacheKey);
}

export const setNonObjectCacheValue = function (cacheKey, cacheObject){
    if(consoleLog) console.log("setNonObjectCacheValue " + cacheKey + " -> " + cacheObject);
    sessionStorage.setItem(cacheKey, cacheObject);
}

export const getCacheValue = function (cacheKey){
    if(consoleLog) console.log("getCacheValue cacheKey -> " + cacheKey + " -> ");
    if(consoleLog) console.log("getCacheValue " + cacheKey + " -> " + sessionStorage.getItem(cacheKey));
    if(sessionStorage.getItem(cacheKey)){
        return JSON.parse(sessionStorage.getItem(cacheKey));
    }
    return null;
}

export const setCacheValue = function (cacheKey, cacheObject){
    if(consoleLog) console.log("setCacheValue " + cacheKey + " -> " + cacheObject);
    if(cacheObject){
        sessionStorage.setItem(cacheKey, JSON.stringify(cacheObject));
    }else{
        sessionStorage.removeItem(cacheKey);
    }
}

export const removeCache = function (cacheKeyArr){
    console.log("removeCache -> removeKeyList " + cacheKeyArr);
    for (let cacheKey in cacheKeyArr) {
        sessionStorage.removeItem(cacheKeyArr[cacheKey]);
        console.log(cacheKeyArr[cacheKey] + " -> removeCache -> After Removing " + sessionStorage.getItem(cacheKeyArr[cacheKey]));
    }
}

export const removeAllCacheForApp = function (appName){
    removeCache(getAllKeysStartsWith(appName));
}

export const getAllKeysStartsWith = function (appName){
    let returnKeyList = [];
    if(appName != null){
        let keyList = Object.keys(sessionStorage);
        if(keyList != null && keyList.length > 0){
            for (const key in keyList) {
                if(key.startsWith(appName)){
                    returnKeyList.push(key);
                }
            }
        }
    }
    return returnKeyList;
}

