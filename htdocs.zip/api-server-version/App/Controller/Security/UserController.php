<?php
    namespace App\Controller\Security;

    use App\Utils\Common\AppConstants;
    use App\Utils\Security\SecurityConstants;
    use Exception;
    use App\Model\Security\UserModel;
    use App\Model\Security\TokenModel;
    use App\Controller;
    use Firebase\JWT\JWT;
    use App\RequestMiddleware;    

    /**
     * UserController - The UserController. This Controller makes use of a few Models for creating, updating, fetching and deleting Users.
     *
     * @author      Ilori Stephen A <stephenilori458@gmail.com>
     * @link        https://github.com/learningdollars/php-rest-api/App/Controller/UserController.php
     * @license     MIT
     */
    class UserController extends Controller {

        /**
         * createNewUser
         *
         * Creates a new User.
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
        */
        public function createNewUser($request, $response)
        {
            $Response = [];
            $sapi_type = php_sapi_name();     
            $Middleware = new RequestMiddleware();
            $Middleware = $Middleware::acceptsJson();   

            if (!$Middleware) {
                array_push($Response, [
                    'status' => 400,
                    'message' => 'Sorry, Only JSON Contents are allowed to access this Endpoint.',
                    'data' => []
                ]);

                $response->code(400)->json($Response);
                return;
            }

            $data = json_decode($request->body());                   
            // Do some validation...
            $validationObject = array(
                (Object) [
                    'validator' => 'required',
                    'data' => isset($data->firstName) ? $data->firstName : '',
                    'key' => 'First Name'
                ],
                (Object) [
                    'validator' => 'string',
                    'data' => isset($data->firstName) ? $data->firstName : '',
                    'key' => 'First Name'
                ],
                (Object) [
                    'validator' => 'required',
                    'data' => isset($data->lastName) ? $data->lastName : '',
                    'key' => 'Last Name',
                ],
                (Object) [
                    'validator' => 'string',
                    'data' => isset($data->lastName) ? $data->lastName : '',
                    'key' => 'Last Name',
                ],
                (Object) [
                    'validator' => 'emailExists',
                    'data' => isset($data->email) ? $data->email : '',
                    'key' => 'Email'
                ],
                (Object) [
                    'validator' => 'min:7',
                    'data' => isset($data->password) ? $data->password : '',
                    'key' => 'Password'
                ]
            );

            $validationBag = $this->validation($validationObject);
            if ($validationBag->status) {              
                $response->code(400)->json($validationBag);  
                return;
            }

            // Trim the response and create the account....
            $payload = array(
                'firstName' => htmlspecialchars(stripcslashes(strip_tags($data->firstName))),
                'lastName' => htmlspecialchars(stripcslashes(strip_tags($data->lastName))),
                'email' => stripcslashes(strip_tags($data->email)),
                'password' => password_hash($data->password, PASSWORD_BCRYPT),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            );

            try {
                $UserModel = new UserModel();
                $UserData = $UserModel->createUser($payload);
                if ($UserData['status']) {
                    
                    // Initialize JWT Token....
                    $tokenExp = date('Y-m-d H:i:s');  
                    $tokenSecret = $this->JWTSecret();
                    $tokenPayload = array(
                        'iat' => time(),
                        'iss' => 'PHP_MINI_REST_API', //!!Modify:: Modify this to come from a constant
                        "exp" => strtotime('+ 1 hours'),
                        "user_id" => $UserData['data']['user_id'],
                        "email" => $UserData['data']['email']
                    );
                    $Jwt = JWT::encode($tokenPayload, $tokenSecret);

                    // Save JWT Token...
                    $TokenModel = new TokenModel();
                    $TokenModel->createToken([
                        'user_id' => $UserData['data']['user_id'],
                        'jwt_token'=> $Jwt
                    ]);
                    $UserData['data']['token'] = $Jwt;

                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '201';
                    $responseHeader['message'] = '';
                    $Response['header'] = $responseHeader;

                    // Return Response............
                    $Response['status'] = 201;
                    $Response['message'] = '';
                    $Response['data'] = $UserData;

                    $response->code(201)->json($Response);
                    return;
                }

                $Response['status'] = 500;
                $Response['message'] = 'An unexpected error occurred and your account could not be created. Please, try again later.';
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];
                
                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * login
         *
         * Authenticates a New User.
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
        */
        public function login($request, $response)
        {
            $Response = [];
            $sapi_type = php_sapi_name();     
            $Middleware = new RequestMiddleware();
            $Middleware = $Middleware::acceptsJson();
            if (!$Middleware) {
                array_push($Response, [
                    'status' => 400,
                    'message' => 'Sorry, Only JSON Contents are allowed to access this Endpoint.',
                    'data' => []
                ]);

                $response->code(400)->json($Response);
                return;
            }

            $data = json_decode($request->body());                   
            // Do some validation...
            $validationObject = array(
                (Object) [
                    'validator' => 'required',
                    'data' => isset($data->email) ? $data->email : '',
                    'key' => 'Email'
                ],
                (Object) [
                    'validator' => 'required',
                    'data' => isset($data->password) ? $data->password : '',
                    'key' => 'Password'
                ],
                (Object) [
                    'validator' => 'min:7',
                    'data' => isset($data->password) ? $data->password : '',
                    'key' => 'Password'
                ]
            );

            $validationBag = $this->validation($validationObject);
            if ($validationBag->status) {              
                $response->code(400)->json($validationBag);  
                return;
            }

            // Trim the response and create the account....
            $payload = array(
                'email' => stripcslashes(strip_tags($data->email)),
                'password' => $data->password,
                'updated_at' => date('Y-m-d H:i:s')
            );

            try {
                $UserModel = new UserModel();
                $UserData = $UserModel->checkEmail($payload['email']);
                if ($UserData['status']) {
                    $userAudtLogPaylload = array(
                        "user_id" => $UserData['data']['id'],
                        "email" => $UserData['data']['email'],
                        'login_date_time' => date('Y-m-d H:i:s')
                    );
                    if (password_verify($payload['password'], $UserData['data']['password'])) {
                        $userAudtLogPaylload["login_status"] = "success";
                        $UserAuditLogData = $UserModel->storeUserLoginAudit($userAudtLogPaylload);
                        // Initialize JWT Token....
                        $tokenExp = date('Y-m-d H:i:s');  
                        $tokenSecret = $this->JWTSecret();
                        $tokenPayload = array(
                            'iat' => time(),
                            'iss' => 'PHP_MINI_REST_API', //!!Modify:: Modify this to come from a constant
                            "exp" => strtotime('+ 1 hours'),
                            "user_id" => $UserData['data']['id'],
                            "email" => $UserData['data']['email']
                        );
                        $Jwt = JWT::encode($tokenPayload, $tokenSecret);

                        // Save JWT Token...
                        $TokenModel = new TokenModel();
                        $TokenModel->createToken([
                            'user_id' => $UserData['data']['id'],
                            'jwt_token'=> $Jwt
                        ]);
                        $UserData['data']['token'] = $Jwt;
                        unset($UserData['data']['password']);

                        $this->sessionUtils->setAppSession(SecurityConstants::$cacheKey_AppName, SecurityConstants::$sessionKey_UserData, $UserData["data"]);

                        $userAccessData = $this->userAccessModel->getUserAccessDetails($UserData['data']['id']);
                        if($userAccessData['status']){
                            $this->sessionUtils->setAppSession(SecurityConstants::$cacheKey_AppName, SecurityConstants::$sessionKey_UserAccessData, $userAccessData["data"]);
                            //echo "session_id -> " . session_id();
                            //echo ", userAccessData From Session -> " . json_encode($this->sessionUtils->getAppSession(SecurityConstants::$cacheKey_AppName, "user_access_data"));
                        }
                        //echo "userAccessData -> " . json_encode($userAccessData);
                        // Return Response............
                        $responseHeader = [];
                        $responseHeader['success'] = true;
                        $responseHeader['code'] = '201';
                        $responseHeader['message'] = '';
                        $Response['header'] = $responseHeader;

                        $Response['status'] = 201;
                        $Response['message'] = '';
                        $Response['data'] = $UserData;
                        $Response['user_access_data'] = $userAccessData["data"];

                        $response->code(201)->json($Response);
                        return;
                    }
                    $userAudtLogPaylload["login_status"] = "invalid-password";
                    $UserAuditLogData = $UserModel->storeUserLoginAudit($userAudtLogPaylload);
                    $Response['status'] = 401;
                    $Response['message'] = 'Please, check your Email and Password and try again.';
                    $Response['data'] = [];
                    $response->code(401)->json($Response);
                    return;
                }
                $Response['status'] = 500;
                $Response['message'] = 'An unexpected error occurred and your action could not be completed. Please, try again later.';
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
               
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];
                
                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * changePassword
         *
         * changePassword
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function changePassword($request, $response)
        {
            //echo "Inside logout";
            if(!$this->tokenUtils->validateJwtToken(AppConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }
            $tokenData = $this->tokenUtils->getTokenData();
            //echo "tokenData : " . json_encode($tokenData);
            if(!isset($tokenData["user_id"])){
                $Response['status'] = 500;
                $Response['message'] = 'user id not available';
                $Response['data'] = [];
                $response->code(500)->json($Response);
                return;
            }
            $data = json_decode($request->body());
            // Do some validation...
            $validationObject = array(
                (Object) [
                    'validator' => 'required',
                    'data' => isset($data->email) ? $data->email : '',
                    'key' => 'Email'
                ],
                (Object) [
                    'validator' => 'required',
                    'data' => isset($data->oldPassword) ? $data->oldPassword : '',
                    'key' => 'Old Password'
                ],
                (Object) [
                    'validator' => 'min:7',
                    'data' => isset($data->oldPassword) ? $data->oldPassword : '',
                    'key' => 'Old Password'
                ],
                (Object) [
                    'validator' => 'required',
                    'data' => isset($data->newPassword) ? $data->newPassword : '',
                    'key' => 'New Password'
                ],
                (Object) [
                    'validator' => 'min:7',
                    'data' => isset($data->newPassword) ? $data->newPassword : '',
                    'key' => 'New Password'
                ]
            );

            $validationBag = $this->validation($validationObject);
            if ($validationBag->status) {
                $validationBag->status = false;
                $response->code(400)->json($validationBag);
                return;
            }

            // Trim the response and create the account....
            $payload = array(
                'email' => stripcslashes(strip_tags($data->email)),
                'oldPassword' => $data->oldPassword,
                'newPassword' => password_hash($data->newPassword, PASSWORD_BCRYPT),
                'updated_at' => date('Y-m-d H:i:s')
            );

            try {
                $UserModel = new UserModel();
                $UserData = $UserModel->checkEmail($payload['email']);
                if ($UserData['status']) {
                    if (password_verify($payload['oldPassword'], $UserData['data']['password'])) {
                        //$UserData['data']['id']
                        $payload["user_id"] = $UserData['data']['id'];
                        $UserData = $UserModel->updatePassword($payload);
                        if ($UserData['status']) {
                            $responseHeader = [];
                            $responseHeader['success'] = true;
                            $responseHeader['code'] = '200';
                            $responseHeader['message'] = 'Password Updated Successfully';
                            $Response['header'] = $responseHeader;

                            $Response['status'] = 200;
                            $Response['message'] = '';
                            $Response['data'] = [];

                            $response->code(200)->json($Response);
                            return;
                        }
                        //echo "userAccessData -> " . json_encode($userAccessData);
                        // Return Response............

                        $Response['status'] = 500;
                        $Response['message'] = 'An unexpected error occurred and your action could not be completed. Please, try again later.';
                        $Response['data'] = [];
                        $response->code(500)->json($Response);
                        return;
                    }
                    $Response['status'] = 401;
                    $Response['message'] = 'Please, check your Email and Password and try again.';
                    $Response['data'] = [];
                    $response->code(401)->json($Response);
                    return;
                }

                $Response['status'] = 500;
                $Response['message'] = 'An unexpected error occurred and your action could not be completed. Please, try again later.';
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;

            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }

        }

        /**
         * updatePassword
         *
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function updatePassword($request, $response)
        {

            $data = json_decode($request->body());
            // Do some validation...
            $validationObject = array(
                (Object) [
                    'validator' => 'required',
                    'data' => isset($data->email) ? $data->email : '',
                    'key' => 'Email'
                ],
                (Object) [
                    'validator' => 'required',
                    'data' => isset($data->password) ? $data->password : '',
                    'key' => 'Password'
                ],
                (Object) [
                    'validator' => 'min:7',
                    'data' => isset($data->password) ? $data->password : '',
                    'key' => 'Password'
                ]
            );

            $validationBag = $this->validation($validationObject);
            if ($validationBag->status) {
                $validationBag->status = false;
                $response->code(400)->json($validationBag);
                return;
            }

            // Trim the response and create the account....
            $payload = array(
                'email' => stripcslashes(strip_tags($data->email)),
                'newPassword' => password_hash($data->password, PASSWORD_BCRYPT),
                'updated_at' => date('Y-m-d H:i:s')
            );

            try {
                $UserModel = new UserModel();
                $UserData = $UserModel->checkEmail($payload['email']);
                if ($UserData['status']) {
                    $payload["user_id"] = $UserData['data']['id'];
                    $UserData = $UserModel->updatePassword($payload);
                    if ($UserData['status']) {
                        $responseHeader = [];
                        $responseHeader['success'] = true;
                        $responseHeader['code'] = '200';
                        $responseHeader['message'] = 'Password Updated Successfully';
                        $Response['header'] = $responseHeader;

                        $Response['status'] = 200;
                        $Response['message'] = '';
                        $Response['data'] = [];

                        $response->code(200)->json($Response);
                        return;
                    }
                    //echo "userAccessData -> " . json_encode($userAccessData);
                    // Return Response............

                    $Response['status'] = 500;
                    $Response['message'] = 'An unexpected error occurred and your action could not be completed. Please, try again later.';
                    $Response['data'] = [];
                    $response->code(500)->json($Response);
                    return;
                }

                $Response['status'] = 500;
                $Response['message'] = 'An unexpected error occurred and your action could not be completed. Please, try again later.';
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;

            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }

        }

        /**
         * logout
         *
         * Authenticates a New User.
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function logout($request, $response)
        {
            //echo "Inside logout";
            if(!$this->tokenUtils->validateJwtToken(AppConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }
            $tokenData = $this->tokenUtils->getTokenData();
            //echo "tokenData : " . json_encode($tokenData);
            if(!isset($tokenData["user_id"])){
                $Response['status'] = 500;
                $Response['message'] = 'user id not available';
                $Response['data'] = [];
                $response->code(500)->json($Response);
                return;
            }
            try {
                $TokenModel = new TokenModel();
                $ClearSessionData = $TokenModel->clearTokens($tokenData["user_id"]);
                if ($ClearSessionData['status']) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['header'] = $responseHeader;

                    $Response['status'] = 200;
                    $Response['message'] = 'Session Cleared';
                    $Response['data'] = [];
                    $response->code(201)->json($Response);
                    return;
                }
                $Response['status'] = 500;
                $Response['message'] = 'An unexpected error occurred and your session not cleared. Please, try again later.';
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];
                $response->code(500)->json($Response);
                return;
            }


        }

        /**
         * keepAlive
         *
         * Authenticates a New User.
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function keepAlive($request, $response)
        {
            //echo "Inside logout";
            if(!$this->tokenUtils->validateJwtToken(AppConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }
            $tokenData = $this->tokenUtils->getTokenData();
            //echo "tokenData : " . json_encode($tokenData);
            if(!isset($tokenData["user_id"])){
                $Response['status'] = 401;
                $Response['message'] = 'user id not available';
                $Response['data'] = [];
                $response->code(401)->json($Response);
                return;
            }

            $responseHeader = [];
            $responseHeader['success'] = true;
            $responseHeader['code'] = '200';
            $responseHeader['message'] = '';
            $Response['header'] = $responseHeader;

            $Response['status'] = 200;
            $Response['message'] = 'Keep Alive Success';
            $Response['data'] = [];
            $response->code(201)->json($Response);
            return;

        }

    }
?>
