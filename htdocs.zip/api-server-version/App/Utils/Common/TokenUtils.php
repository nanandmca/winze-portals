<?php

    namespace App\Utils\Common;


    use App\JwtMiddleware;
    use App\Utils\Common\SessionUtils;

    class TokenUtils
    {
        private $sessionUtils;
        function __construct () {
            $this->sessionUtils = new SessionUtils();
        }

        function getTokenData(){
            $JwtMiddleware = new JwtMiddleware();
            return $JwtMiddleware::getAndDecodeTokenData();
        }

        function isValidJwtToken($validateFlag){
            if ($validateFlag) {
                // Call the Middleware
                $JwtMiddleware = new JwtMiddleware();
                $jwtMiddleware = $JwtMiddleware::getAndDecodeToken();
                if (isset($jwtMiddleware) && $jwtMiddleware == false) {
                    return false;
                }
            }
            return true;
        }

        function validateJwtToken($validateFlag, $response){
            if (!self::isValidJwtToken($validateFlag)) {
                self::throwInvalidAuthenticationErrorResponse($response);
                return false;
            }else if(!$this->sessionUtils->isValidSession($response)){
                self::throwInvalidSessionErrorResponse($response);
                return false;
            }
            return true;
        }

        function throwInvalidAuthenticationErrorResponse($response){
            $response->code(401)->json([
                'status' => 401,
                'message' => 'Sorry, the authenticity of this token could not be verified.',
                'data' => []
            ]);
        }

        function throwInvalidSessionErrorResponse($response){
            $response->code(401)->json([
                'status' => 401,
                'message' => 'Sorry, Invalid Session.',
                'data' => []
            ]);
        }

    }

