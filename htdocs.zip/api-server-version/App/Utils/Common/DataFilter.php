<?php

namespace App\Utils\TrackingSystem;

class DataFilter
{
    private $filterCriteria;

    function __construct($filterCriteria) {
        $this->filterCriteria = $filterCriteria;
    }

    function getFilteredData($data) {
        $criteriaCount = count($this->filterCriteria);
        //echo "data -> " . json_encode($data);
        $matchCount = 0;
        foreach ($this->filterCriteria as $filterKey => $filterValue){
            if(!empty($data->$filterKey) && $data->$filterKey == $filterValue){
                $matchCount = $matchCount + 1;
            }
        }
        return $criteriaCount === $matchCount;
    }

}