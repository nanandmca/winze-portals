<?php

namespace App\Utils\TrackingSystem;

class RoomModifiedLogDataFilter
{
    private $period;

    function __construct($period) {
        $this->period = $period;
    }

    function getFilteredData($data) {
        $filterData = "";
        if($this->period === "Yesterday"){
            $filterData = date('d/m/Y', time() - (24 * 60 * 60));
        }else if($this->period === "Today"){
            $filterData = date('d/m/Y', time());
        }
        $filterFlag = false;
        if(!empty($data->modifiedDate) && $data->modifiedDate == $filterData){
            $filterFlag = true;
        }
        return $filterFlag;
    }

}