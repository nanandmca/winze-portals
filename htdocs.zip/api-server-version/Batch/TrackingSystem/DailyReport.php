<?php
namespace Batch\TrackingSystem;

use App\Controller;
use App\Model\TrackingSystem\ProjectModel;
use App\Utils\TrackingSystem\TrackingSystemConstants;

class DailyReport extends Controller {

    public static function sendDailyReport()
    {
        $Response = [];
        //echo "\nInside sendDailyReport\n";
        $ProjectModel = new ProjectModel();
        try {
            $data = Parent::$cacheUtils->getAppCache(TrackingSystemConstants::$cacheKey_AppName, TrackingSystemConstants::$cacheKey_RoomDetails);
            //echo "\nData From \n" . json_encode($data);
            if ($data == null) {
                $projects = $ProjectModel->fetchProjects();
                if ($projects['status']) {
                    $data = $projects['data'];
                    if($data !== null){
                        Parent::$cacheUtils->setAppCache(TrackingSystemConstants::$cacheKey_AppName, TrackingSystemConstants::$cacheKey_RoomDetails, $data);
                    }else{
                        $Response['status'] = false;
                        $Response['message'] = 'Empty/Error Response';
                    }
                }else{
                    $Response['status'] = false;
                    $Response['message'] = 'Error While Fetching';
                }
            }
            if($data !== null){
                //echo "\nData NOT  NULL \n";
                $overallStatusArr = $ProjectModel->populateOverallSummary($data);
                $Response['status'] = true;
                $Response['data'] = $overallStatusArr;

                $mailData = [
                    "template" => "daily_report.html",
                    "mail_type" => "html",
                    "email_from_name" => "Winze Technologies",
                    "email_from_id" => "arunn@winzetech.com",
                    "email_to" => "nanandmca@yahoo.com",
                    "CC"  => "vignesh@winzetech.com, arunn@winzetech.com",
                    "subject" => "Demo - Daily Overall Report.",
                    "template_data" => [
                        "{HEADER_DATA}" => "Header Details",
                        "{OVERALL_REPORT_DATA}" => "Overall Report Data",
                        "{FOOTER_DATA}" => "Footer Details"
                    ]
                ];

                Parent::$emailUtils->sendEmail(TrackingSystemConstants::$cacheKey_AppName, $mailData);
            }
        } catch (Exception $e) {
            $Response['status'] = false;
            $Response['message'] = 'Exception Occured';
            echo "\nError in sendDailyReport\n";
        }
        return $Response;
    }

}
?>