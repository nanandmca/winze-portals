-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.3.13-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table winze_login.db_applications
CREATE TABLE IF NOT EXISTS `db_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_code` varchar(10) NOT NULL,
  `app_name` varchar(100) NOT NULL,
  `app_description` varchar(1000) NOT NULL,
  `app_route` varchar(50) NOT NULL,
  `app_component_name` varchar(100) NOT NULL,
  `active_flag` varchar(5) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_code` (`app_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table winze_login.db_applications: ~3 rows (approximately)
/*!40000 ALTER TABLE `db_applications` DISABLE KEYS */;
INSERT INTO `db_applications` (`id`, `app_code`, `app_name`, `app_description`, `app_route`, `app_component_name`, `active_flag`) VALUES
	(1, 'pts', 'Project Tracking System', 'Project Tracking System Description, is helpful for construction company to track the daily status from DB', '/pts', 'TrackingSystemHome', 'Y'),
	(2, 'app1', 'Application One', 'Application One Description', '/app1', 'AppOneHome', 'Y'),
	(3, 'app2', 'Application Two', 'Application Two Description', '/app2', 'AppTwoHome', 'Y');
/*!40000 ALTER TABLE `db_applications` ENABLE KEYS */;

-- Dumping structure for table winze_login.db_company
CREATE TABLE IF NOT EXISTS `db_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_code` varchar(10) DEFAULT NULL,
  `company_name` varchar(50) DEFAULT NULL,
  `contact_user_id` int(11) DEFAULT NULL,
  `contact_name` varchar(100) DEFAULT NULL,
  `contact_email` varchar(60) DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `active_flag` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_code` (`company_code`),
  KEY `FK__USER_COMPANY_ID` (`contact_user_id`),
  CONSTRAINT `FK__USER_COMPANY_ID` FOREIGN KEY (`contact_user_id`) REFERENCES `db_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table winze_login.db_company: ~4 rows (approximately)
/*!40000 ALTER TABLE `db_company` DISABLE KEYS */;
INSERT INTO `db_company` (`id`, `company_code`, `company_name`, `contact_user_id`, `contact_name`, `contact_email`, `contact_phone`, `active_flag`) VALUES
	(1, 'winze', 'Winze Technologies', 7, NULL, NULL, NULL, 'Y'),
	(2, 'chn', 'Chennai Company', 6, NULL, NULL, NULL, 'Y'),
	(3, 'hira_queen', 'Hiranandani Queens Gate', 4, NULL, NULL, NULL, 'Y'),
	(4, 'hira_vdp', 'Hiranandani VDP', 5, NULL, NULL, NULL, 'Y');
/*!40000 ALTER TABLE `db_company` ENABLE KEYS */;

-- Dumping structure for table winze_login.db_company_applications
CREATE TABLE IF NOT EXISTS `db_company_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  `active_flag` varchar(5) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_app_id` (`company_id`,`app_id`),
  KEY `FK2_COMPPANY_APP_ID` (`app_id`),
  CONSTRAINT `FK1_APP_COMPANY_ID` FOREIGN KEY (`company_id`) REFERENCES `db_company` (`id`),
  CONSTRAINT `FK2_COMPPANY_APP_ID` FOREIGN KEY (`app_id`) REFERENCES `db_applications` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table winze_login.db_company_applications: ~6 rows (approximately)
/*!40000 ALTER TABLE `db_company_applications` DISABLE KEYS */;
INSERT INTO `db_company_applications` (`id`, `company_id`, `app_id`, `active_flag`) VALUES
	(1, 2, 1, 'Y'),
	(2, 1, 1, 'Y'),
	(3, 3, 1, 'Y'),
	(4, 4, 1, 'Y'),
	(5, 1, 2, 'Y'),
	(6, 1, 3, 'Y');
/*!40000 ALTER TABLE `db_company_applications` ENABLE KEYS */;

-- Dumping structure for table winze_login.db_company_services
CREATE TABLE IF NOT EXISTS `db_company_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `service_type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_service_type` (`company_id`,`service_type`),
  CONSTRAINT `FK__db_company` FOREIGN KEY (`company_id`) REFERENCES `db_company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COMMENT='service_type\r\n\r\nnetwork_services\r\nconstruction\r\n\r\n\r\n\r\n';

-- Dumping data for table winze_login.db_company_services: ~4 rows (approximately)
/*!40000 ALTER TABLE `db_company_services` DISABLE KEYS */;
INSERT INTO `db_company_services` (`id`, `company_id`, `service_type`) VALUES
	(1, 1, 'network_services'),
	(2, 2, 'construction'),
	(3, 3, 'construction'),
	(4, 4, 'construction');
/*!40000 ALTER TABLE `db_company_services` ENABLE KEYS */;

-- Dumping structure for table winze_login.db_company_users
CREATE TABLE IF NOT EXISTS `db_company_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `active_flag` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_user_id` (`company_id`,`user_id`),
  KEY `FK2_COMPANY_USER_USER_ID` (`user_id`),
  CONSTRAINT `FK1_COMPANY_USER_COMPANY_ID` FOREIGN KEY (`company_id`) REFERENCES `db_company` (`id`),
  CONSTRAINT `FK2_COMPANY_USER_USER_ID` FOREIGN KEY (`user_id`) REFERENCES `db_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table winze_login.db_company_users: ~5 rows (approximately)
/*!40000 ALTER TABLE `db_company_users` DISABLE KEYS */;
INSERT INTO `db_company_users` (`id`, `company_id`, `user_id`, `active_flag`) VALUES
	(1, 1, 7, 'Y'),
	(2, 2, 6, 'Y'),
	(3, 3, 4, 'Y'),
	(4, 4, 5, 'Y'),
	(5, 1, 3, 'Y');
/*!40000 ALTER TABLE `db_company_users` ENABLE KEYS */;

-- Dumping structure for table winze_login.db_service_company_users
CREATE TABLE IF NOT EXISTS `db_service_company_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `active_flag` varchar(5) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_id_user_id` (`company_id`,`user_id`),
  KEY `FK2_SERVICE_COMPANY_USER_ID` (`user_id`),
  CONSTRAINT `FK1_SERVICE_COMPANY_COMPANY_ID` FOREIGN KEY (`company_id`) REFERENCES `db_company` (`id`),
  CONSTRAINT `FK2_SERVICE_COMPANY_USER_ID` FOREIGN KEY (`user_id`) REFERENCES `db_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table winze_login.db_service_company_users: ~0 rows (approximately)
/*!40000 ALTER TABLE `db_service_company_users` DISABLE KEYS */;
INSERT INTO `db_service_company_users` (`id`, `company_id`, `user_id`, `active_flag`) VALUES
	(1, 1, 7, 'Y');
/*!40000 ALTER TABLE `db_service_company_users` ENABLE KEYS */;

-- Dumping structure for table winze_login.db_token
CREATE TABLE IF NOT EXISTS `db_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `jwt_token` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table winze_login.db_token: ~6 rows (approximately)
/*!40000 ALTER TABLE `db_token` DISABLE KEYS */;
INSERT INTO `db_token` (`id`, `user_id`, `jwt_token`) VALUES
	(1, 1, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE1OTM1OTcxMjIsImlzcyI6IlBIUF9NSU5JX1JFU1RfQVBJIiwiZXhwIjoxNTkzNjMxNjIwLCJ1c2VyX2lkIjoiMSJ9.p2BKoS9YE_2YV77KTpfALG7CVuwDkueLakVD3gWfMgY'),
	(49, 4, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2MDIzOTY4NjQsImlzcyI6IlBIUF9NSU5JX1JFU1RfQVBJIiwiZXhwIjoxNjAyNDAwNDY0LCJ1c2VyX2lkIjoiNCIsImVtYWlsIjoicXVlZW5zZ2F0ZUB5YWhvby5jb20ifQ.K9J1VgPTSjwrBPlR0OJibelTmqNOSfMV89Y9CTIKa10'),
	(50, 5, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2MDIzOTY4OTEsImlzcyI6IlBIUF9NSU5JX1JFU1RfQVBJIiwiZXhwIjoxNjAyNDAwNDkxLCJ1c2VyX2lkIjoiNSIsImVtYWlsIjoid2luemVwcm9qZWN0QHlhaG9vLmNvbSJ9.r_fNVXqR21ts4WXAmmIOIhM9UWKKTnjOlX6WbMzKYic'),
	(51, 6, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2MDIzOTY5OTIsImlzcyI6IlBIUF9NSU5JX1JFU1RfQVBJIiwiZXhwIjoxNjAyNDAwNTkyLCJ1c2VyX2lkIjoiNiIsImVtYWlsIjoiY2hlbm5haUB5YWhvby5jb20ifQ.5ns40ZR7KFP_w5S65aWURAD2-0Xd52AoNXiZuLVBJko'),
	(52, 7, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2MDI0MDEyMjgsImlzcyI6IlBIUF9NSU5JX1JFU1RfQVBJIiwiZXhwIjoxNjAyNDA0ODI4LCJ1c2VyX2lkIjoiNyIsImVtYWlsIjoiYXJ1bm5Ad2luemV0ZWNoLmNvbSJ9.1lKKPynpSrc4GEo0grNK_-4AObqsgzXXpgn-Mu0J3x8'),
	(213, 3, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2MDQxMjQ1NTYsImlzcyI6IlBIUF9NSU5JX1JFU1RfQVBJIiwiZXhwIjoxNjA0MTI4MTU2LCJ1c2VyX2lkIjoiMyIsImVtYWlsIjoibmFuYW5kbWNhQHlhaG9vLmNvbSJ9.VDYTqRcOt2LPaHVucl7rpqJykHmRh_wcmfsEA-qt8sk'),
	(214, 3, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2MDQxMjgzMzIsImlzcyI6IlBIUF9NSU5JX1JFU1RfQVBJIiwiZXhwIjoxNjA0MTMxOTMyLCJ1c2VyX2lkIjoiMyIsImVtYWlsIjoibmFuYW5kbWNhQHlhaG9vLmNvbSJ9.ujbzUswQ3LQN7KG7KM8Mob-G2GPp4MkD86vmGyHNuXM'),
	(215, 3, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE2MDQxMjgzNjcsImlzcyI6IlBIUF9NSU5JX1JFU1RfQVBJIiwiZXhwIjoxNjA0MTMxOTY3LCJ1c2VyX2lkIjoiMyIsImVtYWlsIjoibmFuYW5kbWNhQHlhaG9vLmNvbSJ9.4WxjmCuw_OFydUf1omLAAE44n9Ttbx7X9sOlH4Pml-Y');
/*!40000 ALTER TABLE `db_token` ENABLE KEYS */;

-- Dumping structure for table winze_login.db_users
CREATE TABLE IF NOT EXISTS `db_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` text NOT NULL,
  `lastName` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `active_flag` varchar(5) DEFAULT NULL,
  `individual_acc_flag` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table winze_login.db_users: ~7 rows (approximately)
/*!40000 ALTER TABLE `db_users` DISABLE KEYS */;
INSERT INTO `db_users` (`id`, `firstName`, `lastName`, `email`, `password`, `created_at`, `updated_at`, `active_flag`, `individual_acc_flag`) VALUES
	(1, 'Stephen', 'Ilori', 'stephenilori458@gmail.com', '$2y$10$mM/YuCSVgazrjXO75OR1.u83c7/9m9RFC6W8/AsaNbD4.0l/iodCG', '2020-07-01 17:52:02', '2020-07-01 17:52:02', NULL, NULL),
	(2, 'Stephen', 'Ilori', 'stephenilori658@gmail.com', '$2y$10$LDX7K7iU7X3FRZvAUVESFOSNEpU8zcWganhsBWx7qN6vZlhFz506S', '2020-07-01 18:10:44', '2020-07-01 18:10:44', NULL, NULL),
	(3, 'Anand', 'NarayanaVadivu', 'nanandmca@yahoo.com', '$2y$10$iKzDssqN9e1ZbgQAIZaVWOFz6DXcB93WYVEyQUofAqY3837hY.y6.', '2020-10-31 07:49:06', '2020-10-31 00:49:06', NULL, NULL),
	(4, 'Queens', 'Gate', 'queensgate@yahoo.com', '$2y$10$HKFgaGGz7vXuzNPbSNU1pevnjRWwFBRWZT.N911pVD.xfoLuequze', '2020-10-11 08:14:24', '2020-10-11 08:14:24', NULL, NULL),
	(5, 'Winze', 'Project', 'winzeproject@yahoo.com', '$2y$10$uA/PqzaZPROrxS9qrWYevOz6R40HxOIIdzZf1owdK0UmslzJsFiOK', '2020-10-11 08:14:51', '2020-10-11 08:14:51', NULL, NULL),
	(6, 'Chennai', 'project', 'chennai@yahoo.com', '$2y$10$USeMpMEihuxXitwbgtdjoOLz3YbN5qvTjPEubSQYwb46FV41HUewG', '2020-10-11 08:16:32', '2020-10-11 08:16:32', NULL, NULL),
	(7, 'Arun', 'N', 'arunn@winzetech.com', '$2y$10$cipK9x59AGDqqdbBaBLjUOYQGnYZRuffmctdOhDTfui9L0Ik7QqZK', '2020-10-11 09:27:08', '2020-10-11 09:27:08', NULL, NULL);
/*!40000 ALTER TABLE `db_users` ENABLE KEYS */;

-- Dumping structure for table winze_login.db_user_login_audit
CREATE TABLE IF NOT EXISTS `db_user_login_audit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(255) NOT NULL,
  `login_status` varchar(255) NOT NULL,
  `login_date_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table winze_login.db_user_login_audit: ~0 rows (approximately)
/*!40000 ALTER TABLE `db_user_login_audit` DISABLE KEYS */;
INSERT INTO `db_user_login_audit` (`id`, `user_email`, `login_status`, `login_date_time`) VALUES
	(1, 'nanandmca@yahoo.com', 'success', '2020-10-31 08:12:12'),
	(2, 'nanandmca@yahoo.com', 'invalid-password', '2020-10-31 08:12:30'),
	(3, 'nanandmca@yahoo.com', 'success', '2020-10-31 08:12:47');
/*!40000 ALTER TABLE `db_user_login_audit` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
