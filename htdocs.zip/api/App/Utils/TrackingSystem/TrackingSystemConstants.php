<?php


namespace App\Utils\TrackingSystem;


class TrackingSystemConstants
{
    public static $inDirectStatusFields = [
        "pending" => ["VDP-in-ExtentionConfigured"
                        , "VDP-in-IP-Configured"
                        , "VDP-in-Testing"
                        , "VDP-out-PatchCordPrivided"
                        , "VDP-out-ExtentionConfigured"
                        , "VDP-out-IP-Configured"
                        , "VDP-out-BracketInstalled"
                        , "VDP-out-Testing"],
        "completed" => ["VDP-in-ExtentionConfigured"
                        , "VDP-in-IP-Configured"
                        , "VDP-in-Testing"
                        , "VDP-out-PatchCordPrivided"
                        , "VDP-out-ExtentionConfigured"
                        , "VDP-out-IP-Configured"
                        , "VDP-out-BracketInstalled"
                        , "VDP-out-Testing"],
        "onProgress" => ["VDP-in-ExtentionConfigured"
                        , "VDP-in-IP-Configured"
                        , "VDP-in-Testing"
                        , "VDP-out-PatchCordPrivided"
                        , "VDP-out-ExtentionConfigured"
                        , "VDP-out-IP-Configured"
                        , "VDP-out-BracketInstalled"
                        , "VDP-out-Testing"],
        "dependency" => ["VDP-in-ExtentionConfigured"
                        , "VDP-in-IP-Configured"
                        , "VDP-in-Testing"
                        , "VDP-out-PatchCordPrivided"
                        , "VDP-out-ExtentionConfigured"
                        , "VDP-out-IP-Configured"
                        , "VDP-out-BracketInstalled"
                        , "VDP-out-Testing"]
        ,"notStarted" => ["VDP-in-ExtentionConfigured"
            , "VDP-in-IP-Configured"
            , "VDP-in-Testing"
            , "VDP-out-PatchCordPrivided"
            , "VDP-out-ExtentionConfigured"
            , "VDP-out-IP-Configured"
            , "VDP-out-BracketInstalled"
            , "VDP-out-Testing"]
    ];

    public static $inDirectStatusFieldsForCompany = [
        "4" => [
            "pending" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"],
            "completed" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"],
            "onProgress" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"],
            "dependency" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"]
            ,"notStarted" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"]
        ],
        "3" => [
            "pending" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"],
            "completed" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"],
            "onProgress" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"],
            "dependency" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"]
            ,"notStarted" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"]
        ],
        "2" => [
            "pending" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"],
            "completed" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"],
            "onProgress" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"],
            "dependency" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"]
            ,"notStarted" => ["VDP-in-ExtentionConfigured"
                , "VDP-in-IP-Configured"
                , "VDP-in-Testing"
                , "VDP-out-PatchCordPrivided"
                , "VDP-out-ExtentionConfigured"
                , "VDP-out-IP-Configured"
                , "VDP-out-BracketInstalled"
                , "VDP-out-Testing"]
        ]

    ];

    public static $codeDescriptionList = [
        "processStatus" => [
            "notStarted" => "Not Started",
            "onProgress" => "On Progress",
            "pending"  => "Pending",
            "dependency" => "Dependency",
            "completed" => "Completed"
        ],
        "completionStatus" => [
            "Yes" => "Yes",
            "No" => "No"
        ]
    ];

    public static $templateForCompany = [
        "4" => [
            "dashboard" => [
                "OverallSummary" => "Y",
                "OverallSummaryType" => "",
                "RoomLogs" => "Y",
                "ServerLogs" => "N",
            ],
            "menuType" => "P",
            "serverUpdateScreenSize" => "",
            "statusScreenSize" => "",
            "statusViewType" => "InOutView",
            "statusUpdateType" => "InOutView",
            "serverUpdateType" => "InOutView",
            "wingNamePrefix" => "Wing ",
            "menuStructureType" => "P", // W, P->W, C->P->W
            "serverUpdate" => "Y",
            "securityRooms" => "N",
            "serverFieldGroupList" => [
                "IPBX" => [
                    "label" => "Server-IPBX",
                    "groupType" => "2Col"
                ]
            ],
            "serverFieldList" => [
                [
                    "fieldName" => "Server-IPBX-PatchCordProvided",
                    "fieldType" => "select",
                    "fieldLabel" => "Patch Cord Provided",
                    "fieldGroup" => "IPBX",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "Server-IPBX SIP-Configuration",
                    "fieldType" => "select",
                    "fieldLabel" => "SIP Configuration",
                    "fieldGroup" => "IPBX",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "Server-IPBX-IP-Configured",
                    "fieldType" => "select",
                    "fieldLabel" => "IP Configured",
                    "fieldGroup" => "IPBX",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "Server-Trunk-Configuration",
                    "fieldType" => "select",
                    "fieldLabel" => "Trunk Configuration",
                    "fieldGroup" => "IPBX",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "Server-IPBX-Rack-Fixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Rack Fixing",
                    "fieldGroup" => "IPBX",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "Server-IPBX-MAC",
                    "fieldType" => "text",
                    "fieldLabel" => "MAC",
                    "fieldGroup" => "IPBX"
                ],
                [
                    "fieldName" => "remark",
                    "fieldType" => "text",
                    "fieldLabel" => "Remarks",
                    "fieldGroup" => "IPBX"
                ]
            ],
            "fieldGroupList" => [
                "top" => [
                    "label" => "Occupied / Allotted Status",
                    "groupType" => "4Col"
                ],
                "status" => [
                    "label" => "Task Status",
                    "groupType" => "InOutCols",
                    "rowLabels" => ["MAC", "Extention No", "IP", "Patch Cord Provided", "Extention Configured", "IP Configured", "Bracket Installed", "Testing"],
                    "groupList" => ["in", "out"],
                    "in" => [
                        "label" => "VDP In",
                        "groupType" => "2Col"
                    ],
                    "out" => [
                        "label" => "VDP Out",
                        "groupType" => "2Col"
                    ]
                ],
                "completion" => [
                    "label" => "Completion Status / Remarks",
                    "groupType" => "2Col"
                ]
            ],
            "fieldList" => [
                [
                    "fieldName" => "occupied",
                    "fieldType" => "select",
                    "fieldLabel" => "Occupied",
                    "fieldGroup" => "top",
                    "optionList" => "completionStatus",
                    "workType" => ["3BHK", "2BHK"],
                    "criteriaList" => [
                        [
                            "projectName" => ""
                        ],
                        [
                            "projectName" => "",
                            "wing" => ""
                        ]
                    ]
                ],
                [
                    "fieldName" => "alloted",
                    "fieldType" => "select",
                    "fieldLabel" => "Alloted",
                    "fieldGroup" => "top",
                    "optionList" => "completionStatus",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-in-MAC",
                    "fieldType" => "text",
                    "fieldLabel" => "VDP In MAC",
                    "rowLabel" => "MAC",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "in",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-in-ExtentionNo",
                    "fieldType" => "text",
                    "fieldLabel" => "VDP In ExtentionNo",
                    "rowLabel" => "Extention No",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "in",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-in-IP",
                    "fieldType" => "text",
                    "fieldLabel" => "VDP In IP",
                    "rowLabel" => "IP",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "in",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-in-PatchCordProvided",
                    "fieldType" => "select",
                    "fieldLabel" => "VDP In PatchCordProvided",
                    "rowLabel" => "Patch Cord Provided",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "in",
                    "optionList" => "completionStatus",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-in-ExtentionConfigured",
                    "fieldType" => "select",
                    "fieldLabel" => "VDP In ExtentionConfigured",
                    "rowLabel" => "Extention Configured",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "in",
                    "optionList" => "processStatus",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-in-IP-Configured",
                    "fieldType" => "select",
                    "fieldLabel" => "VDP In IP-Configured",
                    "rowLabel" => "IP Configured",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "in",
                    "optionList" => "processStatus",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-in-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "VDP In Testing",
                    "rowLabel" => "Testing",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "in",
                    "optionList" => "processStatus",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-out-MAC",
                    "fieldType" => "text",
                    "fieldLabel" => "VDP Out MAC",
                    "rowLabel" => "MAC",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "out",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-out-ExtentionNo",
                    "fieldType" => "text",
                    "fieldLabel" => "VDP Out ExtentionNo",
                    "rowLabel" => "Extention No",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "out",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-out-IP",
                    "fieldType" => "text",
                    "fieldLabel" => "VDP Out IP",
                    "rowLabel" => "IP",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "out",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-out-PatchCordPrivided",
                    "fieldType" => "select",
                    "fieldLabel" => "VDP Out PatchCordPrivided",
                    "rowLabel" => "Patch Cord Provided",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "out",
                    "optionList" => "completionStatus",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-out-ExtentionConfigured",
                    "fieldType" => "select",
                    "fieldLabel" => "VDP Out ExtentionConfigured",
                    "rowLabel" => "Extention Configured",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "out",
                    "optionList" => "processStatus",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-out-IP-Configured",
                    "fieldType" => "select",
                    "fieldLabel" => "VDP Out IP Configured",
                    "rowLabel" => "IP Configured",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "out",
                    "optionList" => "processStatus",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-out-BracketInstalled",
                    "fieldType" => "select",
                    "fieldLabel" => "VDP Out BracketInstalled",
                    "rowLabel" => "Bracket Installed",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "out",
                    "optionList" => "processStatus",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-out-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "VDP Out Testing",
                    "rowLabel" => "Testing",
                    "fieldGroup" => "status",
                    "secondaryGroup" => "out",
                    "optionList" => "processStatus",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "VDP-out-HandOver",
                    "fieldType" => "select",
                    "fieldLabel" => "VDP Out HandOver",
                    "fieldGroup" => "completion",
                    "optionList" => "completionStatus",
                    "workType" => ["3BHK", "2BHK"]
                ],
                [
                    "fieldName" => "remark",
                    "fieldType" => "textarea",
                    "fieldLabel" => "Remarks",
                    "fieldGroup" => "completion",
                    "actionList" => ["UpdateStatus"],
                    "workType" => ["3BHK", "2BHK"]
                ]
            ]
        ],
        "3" => [
            "dashboard" => [
                "OverallSummary" => "Y",
                "OverallSummaryType" => "",
                "RoomLogs" => "Y",
                "ServerLogs" => "N",
            ],
            "alternateFieldNames" => [
                "flatNo" => "roomNo"
            ],
            "menuType" => "W",
            "statusScreenSize" => "fullscreen",
            "statusViewType" => "InOutView",
            "statusUpdateType" => "InOutView",
            "wingNamePrefix" => "Wing ",
            "menuStructureType" => "P", // W, P->W, C->P->W
            "server" => "Y",
            "securityRooms" => "Y",
            "fieldGroupList" => [
                "all" => [
                    "label" => "Status Update",
                    "groupType" => "InOutCols",
                    "rowLabels" => ["Entrance Video Phone", "Living Room Video Door Room", "Living Room Voice", "Living Room Data", "Living Room 2 Voice",
                                    "Living Room TV (1)", "Living Room TV - RG Cable", "Living Room T (2)", "Bed Room - 1 Data", "Bed Room - 1 Voice", "Bed Room - 1 TV",
                                    "Bed Room - 2 Data", "Bed Room - 2 Voice", "Bed Room - 2 TV", "Master Bed Room Data", "Master Bed Room Voice", "Master Bed Room TV", "WiFi"],
                    "groupList" => ["Notes", "CableLaying", "Ferrules", "IO_Punching", "Plate_Fixing", "Numbering", "Testing", "Cable_Length"],
                    "Notes" => [
                        "label" => "Notes",
                        "groupType" => "2Col",
                        "actionList" => ["ViewStatus"]
                    ],
                    "CableLaying" => [
                        "label" => "Cable Laying",
                        "groupType" => "2Col"
                    ],
                    "Ferrules" => [
                        "label" => "Ferrules",
                        "groupType" => "2Col"
                    ],
                    "IO_Punching" => [
                        "label" => "I/O Punching",
                        "groupType" => "2Col"
                    ],
                    "Plate_Fixing" => [
                        "label" => "Plate Fixing",
                        "groupType" => "2Col"
                    ],
                    "Numbering" => [
                        "label" => "Numbering",
                        "groupType" => "2Col"
                    ],
                    "Testing" => [
                        "label" => "Testing",
                        "groupType" => "2Col"
                    ],
                    "Cable_Length" => [
                        "label" => "Cable Length",
                        "groupType" => "2Col"
                    ]
                ]
            ],
            "fieldList" => [
                [
                    "fieldName" => "EN-VDP-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Entrance Video Phone",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Entrance Video Phone",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "EN-VDP-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Entrance Video Phone",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Entrance Video Phone"
                ],
                [
                    "fieldName" => "EN-VDP-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Entrance Video Phone",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Entrance Video Phone",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "EN-VDP-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Entrance Video Phone",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Entrance Video Phone",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "EN-VDP-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Entrance Video Phone",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Entrance Video Phone",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "EN-VDP-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Entrance Video Phone",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Entrance Video Phone",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "EN-VDP-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Entrance Video Phone",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Entrance Video Phone",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "EN-VDP-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Entrance Video Phone",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Entrance Video Phone",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-VDP-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room Video Door Room",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Living Room Video Door Room"
                ],
                [
                    "fieldName" => "LV-VDP-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Video Door Room",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Living Room Video Door Room",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-VDP-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Video Door Room",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Living Room Video Door Room",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-VDP-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Video Door Room",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Living Room Video Door Room",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-VDP-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Video Door Room",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Living Room Video Door Room",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-VDP-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Video Door Room",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Living Room Video Door Room",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-VDP-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Video Door Room",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Living Room Video Door Room",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-VDP-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room Video Door Room",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Living Room Video Door Room",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Voice-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Living Room Voice"
                ],
                [
                    "fieldName" => "LV-Voice-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Living Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Voice-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Living Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Voice-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Living Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Voice-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Living Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Voice-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Living Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Voice-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Living Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Voice-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Living Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Data-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Living Room Data"
                ],
                [
                    "fieldName" => "LV-Data-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Living Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Data-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Living Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Data-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Living Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Data-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Living Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Data-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Living Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Data-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Living Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-Data-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Living Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-Voice-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Living Room 2 Voice"
                ],
                [
                    "fieldName" => "LV2-Voice-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Living Room 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-Voice-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Living Room 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-Voice-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Living Room 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-Voice-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Living Room 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-Voice-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Living Room 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-Voice-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Living Room 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-Voice-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Living Room 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV1-TV-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room TV (1)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Living Room TV (1)"
                ],
                [
                    "fieldName" => "LV1-TV-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room TV (1)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Living Room TV (1)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV1-TV-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room TV (1)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Living Room TV (1)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV1-TV-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room TV (1)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Living Room TV (1)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV1-TV-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room TV (1)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Living Room TV (1)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV1-TV-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room TV (1)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Living Room TV (1)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV1-TV-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room TV (1)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Living Room TV (1)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV1-TV-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room TV (1)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Living Room TV (1)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-TV-RG-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room TV - RG Cable",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Living Room TV - RG Cable"
                ],
                [
                    "fieldName" => "LV-TV-RG-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room TV - RG Cable",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Living Room TV - RG Cable",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-TV-RG-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room TV - RG Cable",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Living Room TV - RG Cable",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-TV-RG-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room TV - RG Cable",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Living Room TV - RG Cable",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-TV-RG-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room TV - RG Cable",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Living Room TV - RG Cable",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-TV-RG-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room TV - RG Cable",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Living Room TV - RG Cable",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-TV-RG-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room TV - RG Cable",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Living Room TV - RG Cable",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV-TV-RG-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room TV - RG Cable",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Living Room TV - RG Cable",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-TV-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room T (2)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Living Room T (2)"
                ],
                [
                    "fieldName" => "LV2-TV-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room T (2)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Living Room T (2)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-TV-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room T (2)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Living Room T (2)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-TV-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room T (2)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Living Room T (2)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-TV-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room T (2)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Living Room T (2)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-TV-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room T (2)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Living Room T (2)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-TV-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Living Room T (2)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Living Room T (2)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "LV2-TV-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Living Room T (2)",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Living Room T (2)",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Data-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Bed Room - 1 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Bed Room - 1 Data"
                ],
                [
                    "fieldName" => "BR1-Data-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Bed Room - 1 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Data-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Bed Room - 1 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Data-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Bed Room - 1 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Data-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Bed Room - 1 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Data-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Bed Room - 1 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Data-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Bed Room - 1 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Data-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Bed Room - 1 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Bed Room - 1 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Voice-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Bed Room - 1 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Bed Room - 1 Voice"
                ],
                [
                    "fieldName" => "BR1-Voice-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Bed Room - 1 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Voice-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Bed Room - 1 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Voice-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Bed Room - 1 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Voice-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Bed Room - 1 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Voice-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Bed Room - 1 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Voice-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Bed Room - 1 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-Voice-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Bed Room - 1 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Bed Room - 1 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-TV-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Bed Room - 1 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Bed Room - 1 TV"
                ],
                [
                    "fieldName" => "BR1-TV-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Bed Room - 1 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-TV-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Bed Room - 1 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-TV-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Bed Room - 1 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-TV-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Bed Room - 1 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-TV-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Bed Room - 1 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-TV-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 1 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Bed Room - 1 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR1-TV-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Bed Room - 1 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Bed Room - 1 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Data-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Bed Room - 2 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Bed Room - 2 Data"
                ],
                [
                    "fieldName" => "BR2-Data-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Bed Room - 2 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Data-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Bed Room - 2 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Data-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Bed Room - 2 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Data-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Bed Room - 2 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Data-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Bed Room - 2 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Data-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Bed Room - 2 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Data-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Bed Room - 2 Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Bed Room - 2 Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Voice-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Bed Room - 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Bed Room - 2 Voice"
                ],
                [
                    "fieldName" => "BR2-Voice-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Bed Room - 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Voice-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Bed Room - 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Voice-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Bed Room - 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Voice-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Bed Room - 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Voice-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Bed Room - 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Voice-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Bed Room - 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-Voice-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Bed Room - 2 Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Bed Room - 2 Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-TV-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Bed Room - 2 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Bed Room - 2 TV"
                ],
                [
                    "fieldName" => "BR2-TV-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Bed Room - 2 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-TV-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Bed Room - 2 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-TV-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Bed Room - 2 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-TV-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Bed Room - 2 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-TV-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Bed Room - 2 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-TV-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Bed Room - 2 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Bed Room - 2 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "BR2-TV-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Bed Room - 2 TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Bed Room - 2 TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Data-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Master Bed Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Master Bed Room Data"
                ],
                [
                    "fieldName" => "MR-Data-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Master Bed Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Data-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Master Bed Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Data-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Master Bed Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Data-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Master Bed Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Data-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Master Bed Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Data-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Master Bed Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Data-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Master Bed Room Data",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Master Bed Room Data",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Voice-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Master Bed Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Master Bed Room Voice"
                ],
                [
                    "fieldName" => "MR-Voice-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Master Bed Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Voice-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Master Bed Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Voice-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Master Bed Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Voice-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Master Bed Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Voice-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Master Bed Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Voice-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Master Bed Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-Voice-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Master Bed Room Voice",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Master Bed Room Voice",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-TV-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "Master Bed Room TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "Master Bed Room TV"
                ],
                [
                    "fieldName" => "MR-TV-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "Master Bed Room TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-TV-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "Master Bed Room TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-TV-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "Master Bed Room TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-TV-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "Master Bed Room TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-TV-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "Master Bed Room TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-TV-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "Master Bed Room TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "Master Bed Room TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "MR-TV-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "Master Bed Room TV",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "Master Bed Room TV",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "WIFI-Notes",
                    "fieldType" => "text",
                    "fieldLabel" => "WIFI",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Notes",
                    "rowLabel" => "WiFi"
                ],
                [
                    "fieldName" => "WIFI-CableLaying",
                    "fieldType" => "select",
                    "fieldLabel" => "WiFi",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "CableLaying",
                    "rowLabel" => "WiFi",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "WIFI-Ferrules",
                    "fieldType" => "select",
                    "fieldLabel" => "WiFi",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Ferrules",
                    "rowLabel" => "WiFi",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "WIFI-I/O-Punching",
                    "fieldType" => "select",
                    "fieldLabel" => "WiFi",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "IO_Punching",
                    "rowLabel" => "WiFi",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "WIFI-Face-PlateFixing",
                    "fieldType" => "select",
                    "fieldLabel" => "WiFi",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Plate_Fixing",
                    "rowLabel" => "WiFi",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "WIFI-Numbering",
                    "fieldType" => "select",
                    "fieldLabel" => "WiFi",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Numbering",
                    "rowLabel" => "WiFi",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "WIFI-Testing",
                    "fieldType" => "select",
                    "fieldLabel" => "WiFi",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Testing",
                    "rowLabel" => "WiFi",
                    "optionList" => "processStatus"
                ],
                [
                    "fieldName" => "WIFI-CL-Length",
                    "fieldType" => "text",
                    "fieldLabel" => "WiFi",
                    "fieldGroup" => "all",
                    "secondaryGroup" => "Cable_Length",
                    "rowLabel" => "WiFi",
                    "optionList" => "processStatus"
                ]
            ]
        ],
        "2" => [
            "dashboard" => [
                "OverallSummary" => "Y",
                "OverallSummaryType" => "",
                "RoomLogs" => "Y",
                "ServerLogs" => "Y",
            ],
            "alternateFieldNames" => [
                "Workstation" => "roomNo"
            ],
            "menuType" => "P",
            "statusViewType" => "4Col",
            "statusUpdateType" => "4Col",
            "wingNamePrefix" => "Wing ",
            "menuStructureType" => "P", // W, P->W, C->P->W
            "server" => "Y",
            "securityRooms" => "Y",
            "floorColumnNotNeeded" => "Y",
            "optionList" => [
                "status" => [
                    "occupied" => "Occupied",
                    "notoccupied" => "Not Occupied"
                ]
            ],
            "fieldList" => [
                [
                    "fieldName" => "fieldNameOne",
                    "fieldType" => "text",
                    "fieldLabel" => "Field One",
                    "workType" => ["3BHK", "2BHK"],
                    "criteriaList" => [
                        [
                            "projectName" => ""
                        ],
                        [
                            "projectName" => "",
                            "wing" => ""
                        ]
                    ]
                ],
                [
                    "fieldName" => "fieldNameTwo",
                    "fieldType" => "select",
                    "fieldLabel" => "Field Two",
                    "option" => "status",
                    "workType" => ["3BHK", "2BHK"]
                ]
            ]
        ]
    ];

    public static $app_Id = "1";
    public static $app_code = "pts";
    public static $app_route = "/pts";
    public static $service_type_network_services = "network_services";

    public static $directStatusList = ["occupied", "notOccupied"];
    public static $inDirectStatusList = ["pending", "completed", "onProgress", "dependency", "notStarted"];
    public static $jwtTokenValidationFlag = true;
    public static $cacheKey_RoomDetails = 'roomDetails';
    public static $cacheKey_RoomModifiedLogs = 'roomModifiedLogs';
    public static $cacheKey_SecurityRoomDetails = 'securityRooms';
    public static $cacheKey_Server = 'server';
    public static $cacheKey_ServerLogs = 'serverLogs';
    public static $cacheKey_AppName = 'pts';

    public static $collectionName_rooms = "rooms";
    public static $collectionName_roomModifiedLogs = "roomLogs";
    public static $columnName_projectName = "projectName";

    public static $filter_getStatusCount = "getStatusCount";
    public static $filter_getFilteredData = "getFilteredData";

    public static $overallStatus_All = "All";

    public static function allCacheKeys(){
        return [self::$cacheKey_RoomDetails, self::$cacheKey_RoomModifiedLogs, self::$cacheKey_SecurityRoomDetails, self::$cacheKey_Server, self::$cacheKey_ServerLogs];
    }

    public static function overallStatusList(){
        return array_merge(self::$directStatusList, self::$inDirectStatusList);
    }

}