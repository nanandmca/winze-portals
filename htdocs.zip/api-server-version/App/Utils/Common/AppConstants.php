<?php

    namespace App\Utils\Common;

    use Symfony\Component\Cache\Adapter\FilesystemAdapter;

    class AppConstants
    {

        public static $cache_path = DIRECTORY_SEPARATOR . 'cache' . DIRECTORY_SEPARATOR;
        public static $email_template_path = DIRECTORY_SEPARATOR . 'email_template' . DIRECTORY_SEPARATOR;

        public static $EMAIL_TEMPLATE_NOT_FOUND = 'EMAIL_TEMPLATE_NOT_FOUND';
        public static $jwtTokenValidationFlag = false;

        public static $filter_getFilteredData = "getFilteredData";

    }

