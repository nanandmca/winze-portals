import React from 'react'

const AppOneStateContext = React.createContext()
const AppOneDispatchContext = React.createContext()

function appOneReducer(state, action) {
    switch (action.type) {
        case 'increment': {
            return {count: state.count + 1}
        }
        case 'decrement': {
            return {count: state.count - 1}
        }
        default: {
            throw new Error(`Unhandled action type: ${action.type}`)
        }
    }
}

function AppOneProvider({children}) {
    const [state, dispatch] = React.useReducer(appOneReducer, {count: 0})
    return (

        <AppOneStateContext.Provider value={state}>
            <AppOneDispatchContext.Provider value={dispatch}>
                {children}
            </AppOneDispatchContext.Provider>
        </AppOneStateContext.Provider>
    )
}

function useAppOneState() {
    const context = React.useContext(AppOneStateContext)
    if (context === undefined) {
        throw new Error('useAppOneState must be used within a AppOneProvider')
    }
    return context
}

function useAppOneDispatch() {
    const context = React.useContext(AppOneDispatchContext)
    if (context === undefined) {
        throw new Error('useAppOneDispatch must be used within a AppOneProvider')
    }
    return context
}

export {AppOneProvider, useAppOneState, useAppOneDispatch}