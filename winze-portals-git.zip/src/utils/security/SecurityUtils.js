import {Card} from "semantic-ui-react";
import React from "react";

let consoleLog = false;
const JWT_TOKEN = "jwtToken";
const USER_AUTH = "userAuth";
const USER_ACCESS_DATA = "userAccessData";

export const checkLoggedIn = function (){
    if(consoleLog) console.log("sessionStorage.getItem(JWT_TOKEN) " + sessionStorage.getItem(JWT_TOKEN))
    return !(sessionStorage.getItem(JWT_TOKEN) === null);
}

export const getJwtToken = function (){
    return sessionStorage.getItem(JWT_TOKEN);
}

export const getUserAuthData = function (){
    return sessionStorage.getItem(USER_AUTH);
}

export const getUserAccessData = function (){
    return sessionStorage.getItem(USER_ACCESS_DATA);
}

export const storeJwtToken = function (jwtToken){
    sessionStorage.setItem(JWT_TOKEN, jwtToken);
}

export const storeUserAuthData = function (userAuthData){
    if(userAuthData && userAuthData.data && userAuthData.data.status && userAuthData.data.data){
        console.log('userAuthData.data.data.token -> ' + userAuthData.data.data.token);
        storeJwtToken(userAuthData.data.data.token);
        console.log('checkLoggedIn() -> ' + checkLoggedIn());
        sessionStorage.setItem(USER_AUTH, {
                                            "id": userAuthData.data.data.id,
                                            "firstName": userAuthData.data.data.firstName,
                                            "lastName": userAuthData.data.data.lastName,
                                            "email": userAuthData.data.data.email,
                                            "token": userAuthData.data.data.token
                                        });
        console.log('getUserAuthData() -> ' + JSON.stringify(getUserAuthData()));
        return true;
    }
    return false;
}

export const storeUserAccessData = function (userAccessData){
    //console.log('storeUserAccessData userAccessData -> ' + JSON.stringify(userAccessData));
    if(userAccessData && userAccessData.user_access_data){
        //console.log('typeof userAccessData.user_access_data  -> ' + (typeof userAccessData.user_access_data));
        //console.log('userAccessData.user_access_data -> ' + JSON.stringify(userAccessData.user_access_data));
        console.log('checkLoggedIn() -> ' + checkLoggedIn());
        sessionStorage.setItem(USER_ACCESS_DATA, JSON.stringify(userAccessData.user_access_data));
        console.log('getUserAccessData() -> ' + JSON.parse(getUserAccessData()));
        return true;
    }
    return false;
}

export const getUserApplicationList = function (){
    let applicationList = []
    let userAccessData = getUserAccessData();
    userAccessData = (userAccessData) ? JSON.parse(userAccessData) : null;
    console.log('userAccessData() -> ' + userAccessData);
    //console.log('userAccessData() -> ' + Object.keys(userAccessData));
    console.log('userAccessData.apps -> ' + userAccessData.apps);
    if(userAccessData && userAccessData.apps && userAccessData.apps.length > 0){
        applicationList = userAccessData.apps.map((app) => { return {
                                                                        app_id: app.id,
                                                                        name: app.app_code,
                                                                        href: "javascript:void()",
                                                                        route: app.app_route,
                                                                        header: app.app_name,
                                                                        description: app.app_description,
                                                                        component: app.app_component_name
                                                                    };
                                                            });
    }
    /*applicationList = [
        {
            name: "app1",
            href: "javascript:void()",
            route: "/app1",
            header: "App One",
            description: "App One Description",
            component: "AppOneHome"
        },
            {
                name: "app2",
                href: "javascript:void()",
                route: "/app2",
                header: "App Two",
                description: "App Two Description",
                component: "AppTwoHome"
            },
            {
                name: "pts",
                href: "javascript:void()",
                route: "/pts",
                header: "Project Tracking System",
                description: "Project Tracking System Description, is helpful for construction comapny to track the daily status",
                component: "TrackingSystemHome"
            }
        ]*/
    return applicationList;
}