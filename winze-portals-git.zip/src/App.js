import React, {Fragment, useEffect} from 'react';
import { PortalHome } from './components/portal/PortalHome';
import {Copyright} from './components/common/Copyright'
import {BrowserRouter, Route, Switch} from "react-router-dom";
import { usePortalState, usePortalDispatch } from "./context/portal/PortalProvider";
import {Login} from "./components/security/Login";
import {checkLoggedIn, getUserApplicationList} from './utils/security/SecurityUtils'
import {LOGIN} from "./utils/portal/PortalAction";
import {Backdrop, CircularProgress} from "@material-ui/core";
import {makeStyles} from "@material-ui/core/styles";
import Logout from "./components/security/Logout";

const useStyles = makeStyles((theme) => ({
    backdrop: {
        zIndex: theme.zIndex.drawer + 1,
        color: '#fff',
    }
}));

function App() {
    const classes = useStyles();
    const {isLoggedIn, apps} = usePortalState();
    const dispatch = usePortalDispatch();
    const [open, setOpen] = React.useState(true);

    useEffect(() => {
        if(checkLoggedIn()){
            dispatch({
                type: LOGIN,
                payload: {
                    apps: getUserApplicationList()
                }
            })
        }
        setOpen(false);
    }, []);

  return (
      <>
          {console.log("Inside App " + isLoggedIn)}
          {
              (isLoggedIn) ?
                  <>
                      <BrowserRouter>
                          <Switch>
                              <Route path="/logout" component={Logout} exact />
                              <Route path="*" component={PortalHome} exact/>
                          </Switch>
                      </BrowserRouter>
                      <Copyright/>
                  </>
              :
                  <Login/>
          }
          <Backdrop className={classes.backdrop} open={open}>
              <CircularProgress color="inherit" />
          </Backdrop>
      </>
  );
}
export default App;