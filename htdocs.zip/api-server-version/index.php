<?php

    /**
      * @author Ilori Stephen A
    **/
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");

    require_once __DIR__ . '/vendor/autoload.php';
    use Dotenv\Dotenv;
    //use App\Utils\Common\CacheUtils;

    $dotenv = new DotEnv(__DIR__, '.env');
    $dotenv->load();

    require_once __DIR__ . '/App/routes/api.php';

    /*$cache = new CacheUtils(dirname(__FILE__).'\\cache\\', 600);
    $key = 'mykey';

    $value = $cache->get($key);
    if ($value == null) {
        $value = 'new value';
        $cache->set($key, $value);
        echo 'created ' . $value;
    } else {
        echo 'got ' . $value;
    }
    $cache->remove($key);
	*/
	//echo "Test"
?>
