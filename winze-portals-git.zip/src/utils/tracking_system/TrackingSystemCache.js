import {getCacheValue, setCacheValue, removeCache} from "../common/CacheUtils";

let appName = "trackingSystem";
let cacheKey_OverAllSummary = "overAllSummary";
let cacheKey_projectDetails_All = "projectDetails_All";
let cacheKey_projectDetails = "projectDetails";
let cacheKey_projectAccess = "projectAccess";
let cacheKey_roomDetails_All = "roomDetails_All";
let cacheKey_roomDetails = "roomDetails";
let cacheKey_serverDetails = "serverDetails";
let cacheKey_securityRoomDetails_All = "securityRoomDetails_All";
let cacheKey_securityRoomDetails = "securityRoomDetails";
let cacheKey_dashboardAuditLogDetails = "dashboardAuditLogDetails";
let cacheKey_dashboardServerAuditLogDetails = "dashboardServerAuditLogDetails";
let allCacheKeys = [cacheKey_projectAccess, cacheKey_OverAllSummary, cacheKey_projectDetails_All, cacheKey_roomDetails_All, cacheKey_securityRoomDetails_All];
let allRoomUpdateKeys = [cacheKey_OverAllSummary, cacheKey_roomDetails, cacheKey_projectDetails];

export const appendAppNameToKey = function (keyName){
    return appName + "." + keyName;
}

export const appendAppNameAndCompanyIdToKey = function (companyId, keyName){
    return appName + "." + companyId + "." + keyName;
}

export const getOverAllSummary = function (companyId){
    return getCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_OverAllSummary));
}

export const setOverAllSummary = function (companyId, overAllSummaryObject){
    setCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_OverAllSummary), overAllSummaryObject);
}

export const getAllProjectDetails = function (companyId){
    return getCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_projectDetails_All));
}

export const setAllProjectDetails = function (companyId, projectDetailsObject){
    setCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_projectDetails_All), projectDetailsObject);
}

export const getProjectDetails = function (companyId, projectName, wing){
    return getCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_projectDetails + "_" + projectName) + ((wing) ? ("_" + wing) : "") );
}

export const setProjectDetails = function (companyId, projectName, wing, projectDetailsObject){
     setCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_projectDetails + "_" + projectName)  + ((wing) ? ("_" + wing) : "") , projectDetailsObject);
}

export const getProjectAccess = function (){
    return getCacheValue(appendAppNameToKey(cacheKey_projectAccess));
}

export const setProjectAccess = function (projectDetailsObject){
    setCacheValue(appendAppNameToKey(cacheKey_projectAccess), projectDetailsObject);
}

export const getAllRoomDetails = function (companyId){
    return getCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_roomDetails_All));
}

export const setAllRoomDetails = function (companyId, projectDetailsObject){
    setCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_roomDetails_All), projectDetailsObject);
}

export const getRoomDetailsForProject = function (companyId, projectName){
    return getCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_roomDetails + "_" + projectName));
}

export const setRoomDetailsForProject = function (companyId, projectName, projectDetailsObject){
    console.log("setRoomDetailsForProject -> " + projectName);
    setCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_roomDetails + "_" + projectName), projectDetailsObject);
}

export const getServerDetailsForProject = function (companyId, projectName){
    return getCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_serverDetails + "_" + projectName));
}

export const setServerDetailsForProject = function (companyId, projectName, projectDetailsObject){
    console.log("setServerDetailsForProject -> " + projectName);
    setCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_serverDetails + "_" + projectName), projectDetailsObject);
}

export const getAllSecurityRoomDetails = function (companyId){
    return getCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_securityRoomDetails_All));
}

export const setAllSecurityRoomDetails = function (companyId, projectDetailsObject){
    setCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_securityRoomDetails_All), projectDetailsObject);
}

export const getSecurityRoomDetailsForProject = function (companyId, projectName){
    return getCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_securityRoomDetails + "_" + projectName));
}

export const setSecurityRoomDetailsForProject = function (companyId, projectName, projectDetailsObject){
    setCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_securityRoomDetails + "_" + projectName), projectDetailsObject);
}

export const getServerAuditLogForDashBoard = function (companyId, period){
    return getCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_dashboardServerAuditLogDetails + "_" + period));
}

export const setServerAuditLogForDashBoard = function (companyId, period, serverAuditLogDetailsObject){
    setCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_dashboardServerAuditLogDetails + "_" + period), serverAuditLogDetailsObject);
}

export const getAuditLogForDashBoard = function (companyId, period){
    return getCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_dashboardAuditLogDetails + "_" + period));
}

export const setAuditLogForDashBoard = function (companyId, period, auditLogDetailsObject){
    setCacheValue(appendAppNameAndCompanyIdToKey(companyId, cacheKey_dashboardAuditLogDetails + "_" + period), auditLogDetailsObject);
}

export const resetCacheForStatusUpdate = function (companyId, projectName){
    console.log("removeKeyList companyId -> " + companyId);
    console.log("removeKeyList projectName -> " + projectName);
    let cacheKeyArr = [
                            appendAppNameAndCompanyIdToKey(companyId, cacheKey_OverAllSummary),
                            appendAppNameAndCompanyIdToKey(companyId, cacheKey_dashboardAuditLogDetails + "_" + "Yesterday"),
                            appendAppNameAndCompanyIdToKey(companyId, cacheKey_dashboardAuditLogDetails + "_" + "Today"),
                            appendAppNameAndCompanyIdToKey(companyId, cacheKey_projectDetails + "_" + projectName),
                            appendAppNameAndCompanyIdToKey(companyId, cacheKey_roomDetails + "_" + projectName)
                        ];
    console.log("removeKeyList cacheKeyArr -> " + cacheKeyArr);
    removeCache(cacheKeyArr);
}

export const resetCacheForServerUpdate = function (companyId, projectName){
    let cacheKeyArr = [
        appendAppNameAndCompanyIdToKey(companyId, cacheKey_dashboardServerAuditLogDetails + "_" + "Yesterday"),
        appendAppNameAndCompanyIdToKey(companyId, cacheKey_dashboardServerAuditLogDetails + "_" + "Today"),
        appendAppNameAndCompanyIdToKey(companyId, cacheKey_serverDetails + "_" + projectName)
    ];
    removeCache(cacheKeyArr);
}

export const removeFromCache = function (companyId, cacheKeyArr){
    let removeKeyList = [];
    for (const cacheKey in cacheKeyArr) {
        if(cacheKey.startsWith(appName)){
            removeKeyList.push(appendAppNameAndCompanyIdToKey(companyId, cacheKey));
        }
    }
    console.log("removeKeyList " + removeKeyList);
    removeCache(removeKeyList);
}

export const resetCache = function (companyId){
    let removeKeyList = [];
    for (const cacheKey in allCacheKeys) {
        if(cacheKey.startsWith(appName)){
            removeKeyList.push(appendAppNameAndCompanyIdToKey(companyId, cacheKey));
        }
    }
    removeCache(removeKeyList);
}
