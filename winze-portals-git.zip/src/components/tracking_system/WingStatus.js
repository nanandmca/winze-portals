import React from 'react';
import { useTrackingSystemState, useTrackingSystemDispatch } from "../../context/tracking_system/TrackingSystemProvider";
import {INCREMENT} from './../../utils/app2/AppTwoAction'
import {Link} from "react-router-dom";

export const WingStatus = (props) => {
    const {count} = useTrackingSystemState();
    const dispatch = useTrackingSystemDispatch();

    console.log("props " + JSON.stringify(props.location.linkParam));

    const doIncrement = () => {
        dispatch({
            type : INCREMENT
        });
    }

    return (
        <div>
            {console.log("Inside Project View screen")}
            {
                (props.location.linkParam)
                    ?
                    <div>
                        <h5>{props.location.linkParam.companyId}</h5>
                        <h5>{props.location.linkParam.companyName}</h5>
                        <h5>{props.location.linkParam.projectName}</h5>
                        <h5>{props.location.linkParam.wing}</h5>
                        {/**<div className="flex-grow text-right px-4 py-2 m-2">
                         {
                                (count) ?
                                    <h6>Tracking System Count : {count}</h6>
                                    :
                                    <></>
                            }
                         <button onClick={() => doIncrement()} className="bg-green-400 hover:bg-green-500 text-white font-semibold py-2 px-4 rounded inline-flex items-center">
                         <span className="pl-2">Action</span>
                         </button>
                         <Link to={"/"}>Home</Link>
                         </div>**/}
                    </div>
                    :
                    <div>Invalid access</div>
            }
        </div>
    )
}