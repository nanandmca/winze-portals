
export const populatedChangeLog = (log) => {
    if((typeof log) == "object"){
        let fieldName = "";
        let newValue = "";
        let oldValue = "";
        if(log.fieldName){
            fieldName = log.fieldName;
        }else if(log.option){
            fieldName = log.option;
        }
        if(log.oldValue){
            oldValue = log.oldValue;
        }else if(log.oldData){
            oldValue = log.oldData;
        }
        if(log.newValue){
            newValue = log.newValue;
        }else if(log.newData){
            newValue = log.newData;
        }
        return fieldName + ": Changed from " + oldValue + " to " + newValue;
    }
    return log;
};