<?php

    namespace App\Model\Security;

    use App\Model\Security\SecurityModel;

    /**
     * UserModel - This Model is consumed basically by the UserController and is also consumed by other controllers and Middlewares...
     *
     * @author      Ilori Stephen A <stephenilori458@gmail.com>
     * @link        https://github.com/learningdollars/php-rest-api/App/Model/UserModel.php
     * @license     MIT
     */
    class UserAccessModel extends SecurityModel {

        public function getActiveCompanyDetails($email)
        {
            $Response = [];
            $Response["id"] = "3";
            $Response["code"] = "C01";
            $Response["companyName"] = "Hiranandani";
            $Response["contact_email"] = "contact@hiranandani.com";
            $Response["contact_phone"] = "95657657667";
            $Response["active"] = "Y";
            return $Response;

            /*
             * SELECT distinct  users.id user_id, company.company_id company_id  from db_users users, db_company_users company
WHERE company.active_flag = 'Y' AND company.user_id = users.id   AND users.id = 3;

SELECT * from db_company_services WHERE company_id = 1;

SELECT app.* FROM db_applications app, db_company_applications company_app
WHERE app.active_flag = 'Y' AND app.id = company_app.app_id AND company_app.active_flag = 'Y' AND company_app.company_id = 1;

SELECT * FROM db_service_company_mapping service_company WHERE service_company.active_flag = 'Y' AND service_company.service_company_id = 1;

SELECT * FROM db_service_users service_users WHERE service_users.active_flag = 'Y' AND service_users.service_company_id = 1;

SELECT service_users.* FROM db_service_company_mapping service_company, db_service_users service_users
WHERE service_users.company_id = service_company.company_id AND service_users.service_company_id = service_company.service_company_id
AND service_users.user_id = 7 AND service_users.active_flag = 'Y'
AND service_company.active_flag = 'Y' AND service_company.service_company_id = 1;

             */
            $Sql = "SELECT * FROM `db_users` WHERE email = :email";
            $this->query($Sql);
            // Bind Params...
            $this->bindParams('email', $email);
            $emailData = $this->fetch();
            if (empty($emailData)) {
                $Response = array(
                    'status' => false,
                    'data' => []
                );
                return $Response;
            }

            $Response = array(
                'status' => true,
                'data' => $emailData
            );
            return $Response;
        }

        public function getUserAccessDetails($user_id)
        {
            $Sql = "SELECT company.* from db_users users, db_company_users company_user, db_company company WHERE company.id = company_user.company_id  AND company.active_flag = 'Y' AND company_user.active_flag = 'Y' AND company_user.user_id = users.id   AND users.id = :user_id";
            $this->query($Sql);
            // Bind Params...
            $responseData = [];
            $this->bindParams('user_id', $user_id);
            $companyData = $this->fetch();
            if (empty($companyData) || count($companyData) == 0) {
                $Response = array(
                    'status' => false,
                    'data' => []
                );
                return $Response;
            }
            $responseData["company"] = $companyData;
            //echo "companyData --> " . json_encode($companyData);
            $Sql = "SELECT * from db_company_services WHERE company_id = :company_id";
            $this->query($Sql);
            $this->bindParams('company_id', $companyData["id"]);
            $companyServicesData = $this->fetchAll();
            if (empty($companyServicesData)) {
                $Response = array(
                    'status' => false,
                    'data' => []
                );
                return $Response;
            }
            $responseData["company-services"] = $companyServicesData;
            $Sql = "SELECT app.* FROM db_applications app, db_company_applications company_app WHERE app.active_flag = 'Y' AND app.id = company_app.app_id AND company_app.active_flag = 'Y' AND company_app.company_id = :company_id";
            $this->query($Sql);
            $this->bindParams('company_id', $companyData["id"]);
            $appData = $this->fetchAll();
            if (empty($appData)) {
                $Response = array(
                    'status' => false,
                    'data' => []
                );
                return $Response;
            }
            $responseData["apps"] = $appData;

            $Response = array(
                'status' => true,
                'data' => $responseData
            );
            return $Response;
        }

        public function getCompanyDetails($company_id)
        {
            $Sql = "SELECT * from db_company where id = :company_id";
            $this->query($Sql);
            // Bind Params...
            $responseData = [];
            $this->bindParams('company_id', $company_id);
            $companyData = $this->fetch();
            if (empty($companyData) || count($companyData) == 0) {
                $Response = array(
                    'status' => false,
                    'data' => []
                );
                return $Response;
            }
            $Response = array(
                'status' => true,
                'data' => $companyData
            );
            return $Response;
        }

        public static function isIndividualCustomerDetails($email)
        {
            $Response = [];
            $Response["id"] = "2";
            $Response["code"] = "C01";
            $Response["name"] = "Hiranandani";
            $Response["email"] = "contact@hiranandani.com";
            $Response["phone"] = "95657657667";
            $Response["active"] = "Y";
            return $Response;
        }

    }
?>
