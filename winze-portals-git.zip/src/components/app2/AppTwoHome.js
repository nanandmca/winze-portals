import React, {useEffect} from 'react';
import {AppTwoDashBoard} from "./AppTwoDashBoard";
import {ADD_LEFT_MENU, UPDATE_TOP_HEADING} from "../../utils/portal/PortalAction";
import {usePortalDispatch, usePortalState} from "../../context/portal/PortalProvider";

export const AppTwoHome = () => {
    const {leftMenuList} = usePortalState();
    const portalDispatch = usePortalDispatch();

    useEffect(() => {
        console.log("useEffect -> " + leftMenuList)
        if(!leftMenuList){
            portalDispatch({
                type: ADD_LEFT_MENU,
                payload: []
            })
        }
        portalDispatch({
            type: UPDATE_TOP_HEADING,
            payload: "Application Two"
        })
    }, []);

    return (

        <div>
            <div className="flex items-center mt-24 mb-10">
                <div className="flex-grow text-left px-4 py-2 m-2">
                    <h5 className="text-gray-900 font-bold text-xl">App Two Home</h5>
                </div>
                <AppTwoDashBoard/>
            </div>
        </div>
    )
}