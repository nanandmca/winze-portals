<?php

    namespace App\Model\TrackingSystem;

    use App\Utils\TrackingSystem\TrackingSystemConstants;
    use Dotenv\Dotenv;
    use App\Model;
    use mysql_xdevapi\Exception;
    use Kreait\Firebase\Factory;
    use Google\Cloud\Firestore\FirestoreClient;

class TrackingSystemModel extends Model {

        public $firestoreDB = [];
        public $roomsCollectionName = [];
        public $roomModifedLogsCollectionName = [];
        public $securityRoomsCollectionName = [];
        public $serverCollectionName = [];
        public $serverLogsCollectionName = [];
        public $companyId = "";

        public function __construct($companyId)
        {
            $this->companyId = $companyId;

            $dotenv = new DotEnv(__DIR__, '../../../.env');
            $dotenv->load();
            //echo "APP_ENV : " . getenv("APP_ENV");
            $dotenv = new DotEnv(__DIR__, '../../../.env.trackingsystem.' . getenv("APP_ENV"));
            $dotenv->load();
            //echo "SAMPLES_DB_HOST : " . getenv("SAMPLES_DB_HOST");
            if(getenv("FIRESTORE_DB_FLAG") !== false && getenv("FIRESTORE_DB_FLAG") == "Y"){
                if(getenv("FIREBASE_KEY_JSON") !== false){
                    $fireBaseKeyJson = getenv("FIREBASE_KEY_JSON");
                    $lines = explode("~", $fireBaseKeyJson);
                    $keys = explode(',', $lines[0]);
                    $vals = explode(',', $lines[1]);
                    $collectionNames = explode(',', $lines[2]);
                    $modifiedLogscollectionNames = explode(',', $lines[3]);
                    $projectIds = explode(',', $lines[4]);
                    $securityRoooms = explode(',', $lines[5]);
                    $servers = explode(',', $lines[6]);
                    $serverLogs = explode(',', $lines[7]);
                    for($i = 0; $i < count($keys); $i++) {
                        $this->roomsCollectionName[$keys[$i]]  = $collectionNames[$i];
                        $this->roomModifedLogsCollectionName[$keys[$i]]  = $modifiedLogscollectionNames[$i];
                        $this->securityRoomsCollectionName[$keys[$i]]  = $securityRoooms[$i];
                        $this->serverCollectionName[$keys[$i]]  = $servers[$i];
                        $this->serverLogsCollectionName[$keys[$i]]  = $serverLogs[$i];
                        try{
                            $factory = (new Factory)->withServiceAccount(__DIR__. '/../../../secret/' . $vals[$i]);
                            $firestore = $factory->createFirestore();
                            //$docdata = $factory->createFirestore()->database()->collection("rooms")->document("041Vz6C1aIyNjXEGosZU")->snapshot()->data();
                            //echo "docdata" . json_encode($docdata);
                            $this->firestoreDB[$keys[$i]]  = $firestore->database();
                            //echo "Assigned " . $vals[$i];

                            /*$firestoreClient = new FirestoreClient([
                                                                    'projectId' => $projectIds[$i],
                                                                    'keyFilePath' =>  __DIR__. '/../../../secret/' . $vals[$i]
                                                                        ]);*/
                            /*
                            $collectionReference = $firestoreClient->collection("rooms");
                            $documentReference = $collectionReference->document("041Vz6C1aIyNjXEGosZU");
                            $snapshot = $documentReference->snapshot()->data();
                            echo "snapshot" . json_encode($snapshot);*/
                        }catch (Exception $exception){
                            //echo "Error " . $keys[$i];
                        }
                    }
                }
            }
            parent::__construct(getenv("TRACKING_SYSTEM_DB_HOST"), getenv("TRACKING_SYSTEM_DB_PORT"), getenv("TRACKING_SYSTEM_DB_DATABASE"), getenv("TRACKING_SYSTEM_DB_USERNAME"), getenv("TRACKING_SYSTEM_DB_PASSWORD"));
        }

        public function getFirestoreDB()
        {
            return isset($this->firestoreDB[self::getCompanyId()]) ? $this->firestoreDB[self::getCompanyId()] : null;
        }

        public function getCompanyId()
        {
            //if($this->companyId == null) return "3";
            return $this->companyId;
        }

        public function getRoomsCollectionName()
        {
            if(isset($this->roomsCollectionName[self::getCompanyId()])){
                return $this->roomsCollectionName[self::getCompanyId()];
            }else{
                return TrackingSystemConstants::$collectionName_rooms;
            }
        }

        public function getRoomModifiedLogCollectionName()
        {
            if(isset($this->roomModifedLogsCollectionName[self::getCompanyId()])){
                return $this->roomModifedLogsCollectionName[self::getCompanyId()];
            }else{
                return TrackingSystemConstants::$collectionName_roomModifiedLogs;
            }
        }

        public function getSecurityRoomsCollectionName()
        {
            if(isset($this->securityRoomsCollectionName[self::getCompanyId()])){
                return $this->securityRoomsCollectionName[self::getCompanyId()];
            }else{
                return TrackingSystemConstants::$cacheKey_SecurityRoomDetails;
            }
        }

        public function getServerCollectionName()
        {
            if(isset($this->serverCollectionName[self::getCompanyId()])){
                return $this->serverCollectionName[self::getCompanyId()];
            }else{
                return TrackingSystemConstants::$cacheKey_Server;
            }
        }

        public function getServerLogsCollectionName()
        {
            if(isset($this->serverLogsCollectionName[self::getCompanyId()])){
                return $this->serverLogsCollectionName[self::getCompanyId()];
            }else{
                return TrackingSystemConstants::$cacheKey_ServerLogs;
            }
        }

}

?>
