<?php

require 'vendor/autoload.php';

use Kreait\Firebase\Factory;
use Google\Cloud\Firestore\FirestoreClient;
use App\Utils\Common\CacheUtils;
use App\Utils\TrackingSystem\OverallStatusFilter;

$factory = (new Factory)->withServiceAccount(__DIR__.'/secret/winzeproject-1c725d1e6890.json');
$firestore = $factory->createFirestore();
//$firestore = new FirestoreClient();

$database = $firestore->database();

//$collectionReference = $firestore->collection('rooms');
//$documentReference = $collectionReference->document($userId);
//$snapshot = $documentReference->snapshot();
//$snapshot = $collectionReference->snapshot();
$hours = 24;
$minutes = 60;
$minutes_in_hour = 60;
$cache = new CacheUtils(dirname(__FILE__).'\\cache\\', $hours * $minutes_in_hour * $minutes); // 60 = 1 minute
$key = 'roomDetails';

/*
$data = $cache->get($key);
if ($data == null) {
    //$rooms = $database->collection("rooms")->where("projectName", "=", "Chancery");
    $rooms = $database->collection("rooms");
    $docs = $rooms->documents();
    $data = array();
    foreach ($docs as $doc) {
        $data[] = $doc->data();
        //echo '\n<BR>doc : ' . gettype($doc->data());
    }
    //echo '\n<BR>Type : ' . json_encode($data);
    $cache->set($key, $data);
    echo '\n<BR>created ' . $data;
} else {
    echo '\n<BR>got from cache ';
}
*/
/*foreach ($data as $doc){
    echo '\n<BRprojectName : ' . $doc['projectName'];
    echo ', floorNo : ' . $doc['floorNo'];
    echo ', roomNo : ' . $doc['roomNo'];
    echo ', wing : ' . $doc['wing'];
    echo "\n<BR>";
}*/
$overallStatusList = ["occupied", "notOccupied", "pending", "completed", "onProgress", "dependency", "notStarted"];
$data = [];
//echo  "\n<BR>array length : " . count($data);
$projectNameArr = array_column($data, 'projectName');
//echo  "unique array length : " . json_encode($projectNameArr);
$distinctProjectNames = array_unique($projectNameArr);
$overallStatusArr = array();
foreach ($overallStatusList as $statusKey) {
    $projectDataArr = array();
    $allCount = 0;
    foreach ($distinctProjectNames as $projectName) {
        $filtered = array_filter($data, array(new OverallStatusFilter($projectName, $statusKey), 'getStatusCount'));
        //echo  "\n<BR>projectName: " . $projectName . ",  statusKey" . $statusKey. ", filtered : " .  count($filtered);
        $projectDataArr[$projectName] = count($filtered);
        $allCount = $allCount + $projectDataArr[$projectName];
    }
    $projectDataArr['All'] = $allCount;
    $overallStatusArr[$statusKey] = $projectDataArr;
}
echo  "\n<BR>overallStatusArr: " . json_encode($overallStatusArr);
//echo  "\n<BR>distinctProjectNames: " . json_encode($distinctProjectNames);
//echo  "\n<BR>unique array length : " . count(array_unique($projectNameArr));
//echo "\n<BR>Hello World - End";
