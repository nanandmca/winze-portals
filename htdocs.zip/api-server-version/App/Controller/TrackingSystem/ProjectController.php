<?php
    namespace App\Controller\TrackingSystem;

    use App\Controller;
    use App\Model\TrackingSystem\ProjectModel;
    use App\RequestMiddleware;
    use App\Utils\Security\SecurityConstants;
    use App\Utils\TrackingSystem\TrackingSystemConstants;

    /**
     * ProductController - The ProductController. This Controller makes use of a few Models for creating, updating, fetching and deleting Products.
     *
     * @author      Ilori Stephen A <stephenilori458@gmail.com>
     * @link        https://github.com/learningdollars/php-rest-api/App/Controller/ProductController.php
     * @license     MIT
     */
    class ProjectController extends Controller
    {

        private function getLoggedInCompanyId(){ //Customer ID
            if($this->commonUtils->getCompanyIdFromHeader() != null){
                return $this->commonUtils->getCompanyIdFromHeader();
            }
            $companyData = $this->securityUtils->getCustomerData();
            //echo  "getLoggedInCompanyId -> " . json_encode($companyData);
            if(SecurityConstants::$sessionValidation_Required == false){
                if($companyData && isset($companyData["id"])){
                    return $companyData["id"];
                }
            }else{
                if($companyData && isset($companyData->id)){
                    return $companyData->id;
                }
            }
            return null;
        }

        private function cacheKeyForCustomerForCompany($company_id){
            if($company_id != null){
                return TrackingSystemConstants::$cacheKey_AppName . '.' . $company_id;
            }
            return TrackingSystemConstants::$cacheKey_AppName;
        }

        private function cacheKeyForCustomer(){
            return $this->cacheKeyForCustomerForCompany($this->getLoggedInCompanyId());
        }

        public function loadProjectsDataForCompany($company_id)
        {
            $returnData = [];
            $ResponseData = [];
            $responseHeader = [];
            $data = $this->cacheUtils->getAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_RoomDetails);
            //echo $company_id . " -> data : " . json_encode($data);
            if ($data == null) {
                $ProjectModel = new ProjectModel($company_id);
                $projects = $ProjectModel->fetchProjects();
                if ($projects['status']) {
                    //echo "data :  ";
                    $data = $projects['data'];
                    $this->cacheUtils->setAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_RoomDetails, $data);
                }else{
                    //echo "data :  ELSE";
                    $responseHeader['success'] = false;
                    $responseHeader['code'] = $projects['code'];
                    $responseHeader['message'] = $projects['message'];
                    $ResponseData['status'] = $projects['code'];
                    $ResponseData['header'] = $responseHeader;
                    $ResponseData['data'] = [];
                    //echo "data :  ELSE" . json_encode($ResponseData);
                    $returnData["ResponseData"] = $ResponseData;
                    return $returnData;
                }
            }
            $returnData["data"] = $this->cacheUtils->getAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_RoomDetails);
            return $returnData;
        }

        public function loadProjectsData()
        {
            return $this->loadProjectsDataForCompany($this->getLoggedInCompanyId());
        }

        public function loadModifiedLogData()
        {
            return $this->loadModifiedLogDataForCompany($this->getLoggedInCompanyId());
        }

        public function loadModifiedLogDataForCompany($company_id)
        {
            $returnData = [];
            $ResponseData = [];
            $responseHeader = [];
            $data = $this->cacheUtils->getAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_RoomModifiedLogs);
            //echo "data : " . json_encode($data);
            if ($data == null) {
                $ProjectModel = new ProjectModel($company_id);
                $projects = $ProjectModel->fetchRoomModifiedLogs();
                if ($projects['status']) {
                    $data = $projects['data'];
                    $this->cacheUtils->setAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_RoomModifiedLogs, $data);
                }else{
                    $responseHeader['success'] = false;
                    $responseHeader['code'] = $projects['code'];
                    $responseHeader['message'] = $projects['message'];
                    $ResponseData['status'] = $projects['code'];
                    $ResponseData['header'] = $responseHeader;
                    $ResponseData['data'] = [];
                    $returnData["ResponseData"] = $ResponseData;
                    return $returnData;
                }
            }
            $returnData["data"] = $this->cacheUtils->getAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_RoomModifiedLogs);
            return $returnData;
        }

        public function loadSecurityRoomsData()
        {
            return $this->loadSecurityRoomsDataForCompany($this->getLoggedInCompanyId());
        }

        public function loadSecurityRoomsDataForCompany($company_id)
        {
            $returnData = [];
            $ResponseData = [];
            $responseHeader = [];
            $data = $this->cacheUtils->getAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_SecurityRoomDetails);
            //echo "data : " . json_encode($data);
            if ($data == null) {
                $ProjectModel = new ProjectModel($company_id);
                $projects = $ProjectModel->fetchSecurityRooms();
                if ($projects['status']) {
                    $data = $projects['data'];
                    $this->cacheUtils->setAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_SecurityRoomDetails, $data);
                }else{
                    $responseHeader['success'] = false;
                    $responseHeader['code'] = $projects['code'];
                    $responseHeader['message'] = $projects['message'];
                    $ResponseData['status'] = $projects['code'];
                    $ResponseData['header'] = $responseHeader;
                    $ResponseData['data'] = [];
                    $returnData["ResponseData"] = $ResponseData;
                    return $returnData;
                }
            }
            $returnData["data"] = $this->cacheUtils->getAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_SecurityRoomDetails);
            return $returnData;
        }

        public function loadServerData()
        {
            return $this->loadServerDataForCompany($this->getLoggedInCompanyId());
        }

        public function loadServerDataForCompany($company_id)
        {
            $returnData = [];
            $ResponseData = [];
            $responseHeader = [];
            $data = $this->cacheUtils->getAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_Server);
            //echo "data : " . json_encode($data);
            if ($data == null) {
                $ProjectModel = new ProjectModel($company_id);
                $projects = $ProjectModel->fetchServers();
                if ($projects['status']) {
                    $data = $projects['data'];
                    $this->cacheUtils->setAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_Server, $data);
                }else{
                    $responseHeader['success'] = false;
                    $responseHeader['code'] = $projects['code'];
                    $responseHeader['message'] = $projects['message'];
                    $ResponseData['status'] = $projects['code'];
                    $ResponseData['header'] = $responseHeader;
                    $ResponseData['data'] = [];
                    $returnData["ResponseData"] = $ResponseData;
                    return $returnData;
                }
            }
            $returnData["data"] = $this->cacheUtils->getAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_Server);
            return $returnData;
        }

        public function loadServerLogsData()
        {
            return $this->loadServerLogsDataForCompany($this->getLoggedInCompanyId());
        }

        public function loadServerLogsDataForCompany($company_id)
        {
            $returnData = [];
            $ResponseData = [];
            $responseHeader = [];
            $data = $this->cacheUtils->getAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_ServerLogs);
            //echo "data : " . json_encode($data);
            if ($data == null) {
                $ProjectModel = new ProjectModel($company_id);
                $projects = $ProjectModel->fetchServerLogs();
                if ($projects['status']) {
                    $data = $projects['data'];
                    $this->cacheUtils->setAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_ServerLogs, $data);
                }else{
                    $responseHeader['success'] = false;
                    $responseHeader['code'] = $projects['code'];
                    $responseHeader['message'] = $projects['message'];
                    $ResponseData['status'] = $projects['code'];
                    $ResponseData['header'] = $responseHeader;
                    $ResponseData['data'] = [];
                    $returnData["ResponseData"] = $ResponseData;
                    return $returnData;
                }
            }
            $returnData["data"] = $this->cacheUtils->getAppCache($this->cacheKeyForCustomerForCompany($company_id), TrackingSystemConstants::$cacheKey_ServerLogs);
            return $returnData;
        }

        /**
         * fetchUserAccess
         *
         * Fetches an Array of Over All Summary....
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function fetchUserAccess($request, $response)
        {

            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            $UserSessionData = $this->sessionUtils->getAppSession(SecurityConstants::$cacheKey_AppName, SecurityConstants::$sessionKey_UserData);
            $UserAccessSessionData =  $this->sessionUtils->getAppSession(SecurityConstants::$cacheKey_AppName, SecurityConstants::$sessionKey_UserAccessData);

            //echo "UserSessionData -> " . json_encode($UserSessionData);
            //echo "UserAccessSessionData -> " . json_encode($UserAccessSessionData);

            $validation_result = [];
            $validation_result["status"] = true;
            $validation_result["message"] = "Validation Failed";

            $ProjectAccessRequestData = [];
            if($UserSessionData){
                $UserSessionData = (array)$UserSessionData;
                $ProjectAccessRequestData["id"] = $UserSessionData["id"];
                $ProjectAccessRequestData["email"] = $UserSessionData["email"];
            }else{
                // TODO - Comment
                $tokenData = $this->tokenUtils->getTokenData();
                $ProjectAccessRequestData["id"] = $tokenData["user_id"];
                $ProjectAccessRequestData["email"] = $tokenData['email'];
                //$validation_result["status"] = false;
                //$validation_result["message"] = "Invalid User Session";
            }

            if(!$UserAccessSessionData){
                $userAccessData = $this->userAccessModel->getUserAccessDetails($ProjectAccessRequestData["id"]);
                if($userAccessData['status']){
                    $this->sessionUtils->setAppSession(SecurityConstants::$cacheKey_AppName, SecurityConstants::$sessionKey_UserAccessData, $userAccessData["data"]);
                    $UserAccessSessionData =  $this->sessionUtils->getAppSession(SecurityConstants::$cacheKey_AppName, SecurityConstants::$sessionKey_UserAccessData);
                }
            }

            //echo "UserAccessSessionData -> " . json_encode($UserAccessSessionData);

            $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());
            if($UserAccessSessionData){
                $UserAccessSessionData = (array)$UserAccessSessionData;
                $ProjectAccessRequestData["company"] = $UserAccessSessionData["company"];
                $ProjectAccessRequestData["company-services"] = $UserAccessSessionData["company-services"];
                $filterData =  [];
                $filterData["service_type"] = TrackingSystemConstants::$service_type_network_services;
                $filteredAppData = $ProjectModel->filterData($UserAccessSessionData["company-services"], $filterData);
                if($filteredAppData && count($filteredAppData) > 0){
                    $ProjectAccessRequestData["service_company_user"] = "Y";
                }else{
                    $ProjectAccessRequestData["service_company_user"] = "N";
                }
                //echo "ProjectAccessRequestData -> " . json_encode($ProjectAccessRequestData);
                $apps = $UserAccessSessionData["apps"];
                //echo "apps -> " . count($apps);
                if($apps && count($apps) > 0){
                    $filterData =  [];
                    $filterData["app_code"] = TrackingSystemConstants::$app_code;
                    $filteredAppData = $ProjectModel->filterData($apps, $filterData);
                    //echo "apps -> " . json_encode($apps);
                    //echo "filterData -> " . json_encode($filterData);
                    //echo "filteredAppData -> " . json_encode($filteredAppData);
                    if(!$filteredAppData){
                        $validation_result["status"] = false;
                        $validation_result["message"] = "Invalid App Access";
                    }
                }else{
                    $validation_result["status"] = false;
                    $validation_result["message"] = "Invalid App Access";
                }
            }else{
                $validation_result["status"] = false;
                $validation_result["message"] = "Invalid User Session";
            }

            if(!$validation_result["status"]){
                $Response['status'] = 500;
                $Response['message'] = $validation_result["message"];
                $Response['data'] = [];
                $response->code(500)->json($Response);
                return;
            }

            $company_id_arr = [];
            //echo "service_company_user -> " . $ProjectAccessRequestData["service_company_user"] ;
            if($ProjectAccessRequestData["service_company_user"] == "Y"){
                //echo "company -> " . json_encode($ProjectAccessRequestData["company"]);
                $CompanyListData = $ProjectModel->getCompanyListForServiceUser($ProjectAccessRequestData["id"]);
                if($CompanyListData["status"]){
                    //echo "CompanyListData -> " . json_encode($CompanyListData["data"]);
                    $company_id_arr = array_merge($company_id_arr, array_column($CompanyListData["data"], 'company_id'));
                }else{
                    $Response['status'] = 500;
                    $Response['message'] = "No Company Found";
                    $Response['data'] = [];
                    $response->code(500)->json($Response);
                    return;
                }
            }else{
                //echo "company -> " . json_encode($ProjectAccessRequestData["company"]);
                array_push($company_id_arr, $ProjectAccessRequestData["company"]->id);
            }
            //echo "company_id_arr -> " . json_encode($company_id_arr);

            $UserAccessData = [];
            $UserAccessData["service_company_user"] = $ProjectAccessRequestData["service_company_user"];
            $UserAccessData["login_company_id"] = $this->getLoggedInCompanyId();
            $UserAccessData["company_list"] = $company_id_arr;
            $UserAccessData["project_access_data"] = [];
            foreach ($company_id_arr as $company_id) {
                //echo "company_id -> " . $company_id;
                $company_data = [];
                if(isset(TrackingSystemConstants::$templateForCompany[$company_id])){
                    $company_data = TrackingSystemConstants::$templateForCompany[$company_id];
                }
                $ProjectModel = new ProjectModel($company_id);
                $company_project_data = $this->loadProjectsDataForCompany($company_id);
                $unique_project_data = array_unique(array_column($company_project_data["data"], "projectName"));
                $project_data = [];
                foreach ($unique_project_data as $project_id) {
                    $project = [];
                    $project["projectName"] = $project_id;
                    $filterData =  [];
                    $filterData["projectName"] = $project_id;
                    $filteredAppData = $ProjectModel->filterData($company_project_data["data"], $filterData);
                    //echo "filteredAppData -> " . json_encode($filteredAppData);
                    $unique_wing_data = array_unique(array_column($filteredAppData, "wing"));
                    $project["wings"] = array_values($unique_wing_data);
                    $project_data[] = $project;
                }
                $company_data["projects"] = $project_data;
                $company_detail = $this->userAccessModel->getCompanyDetails($company_id);
                $company_data["company_id"] = $company_id;
                if($company_detail["status"]){
                    $company_data["company_name"] = $company_detail["data"]["company_name"];
                }
                //echo $company_id . "  -> " . json_encode(array_unique($distinct_project_data));
                //echo $company_id . "  -> " . json_encode($company_project_data["data"]);
                //echo $company_id . "  -> " . json_encode($this->commonUtils->filterArrayByKeys($company_project_data, ["projectName", "wing", "wingName"]));
                //echo $company_id . "  -> " . json_encode(array_column($company_project_data["data"], "projectName", "wing"));
                $UserAccessData["project_access_data"][] = $company_data;
            }
            $UserAccessData["codeDescriptionList"] = TrackingSystemConstants::$codeDescriptionList;

            $Response = [];
            $responseHeader = [];
            $responseHeader['success'] = true;
            $responseHeader['code'] = '200';
            $responseHeader['message'] = '';
            $Response['status'] = 200;
            $Response['header'] = $responseHeader;
            $Response['data'] = $UserAccessData;

            $response->code(200)->json($Response);
            return;

        }

        /**
         * fetchProjects
         *
         * Fetches an Array of Over All Summary....
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function fetchProjects($request, $response)
        {

            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                $Response = [];
                $data_loaded= $this->loadProjectsData();
                //echo "Response  " . json_encode($Response);
                if(isset($data_loaded["ResponseData"])){
                    //echo "Response  " . json_encode($Response);
                    $Response = $data_loaded["ResponseData"];
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];
                /*$data = $this->cacheUtils->getAppCache($this->cacheKeyForCustomer(), TrackingSystemConstants::$cacheKey_RoomDetails);
                //echo "data : " . json_encode($data);
                if ($data == null) {
                    $ProjectModel = new ProjectModel();
                    $projects = $ProjectModel->fetchProjects();
                    if ($projects['status']) {
                        $data = $projects['data'];
                        $this->cacheUtils->setAppCache($this->cacheKeyForCustomer(), TrackingSystemConstants::$cacheKey_RoomDetails, $data);
                    }else{
                        $responseHeader['code'] = $projects['code'];
                        $responseHeader['message'] = $projects['message'];
                        $Response['status'] = $projects['code'];
                        $Response['header'] = $responseHeader;
                        $Response['data'] = [];
                        $response->code($projects['code'])->json($Response);
                        return;
                    }
                }
                */
                if ($data != null && count($data) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $data;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '400';
                $responseHeader['message'] = 'An unexpected error occurred and your product could not be retrieved. Please, try again later.';
                $Response['status'] = 400;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * fetchProjectsByProjectName
         *
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function fetchProjectsByProjectName($request, $response)
        {
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                $Response = [];
                $data_loaded= $this->loadProjectsData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());
                $filterData =  [];
                $filterData["projectName"] = $request->projectName;
                $filteredProjectData = $ProjectModel->filterData($data, $filterData);
                if (count($filteredProjectData) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $filteredProjectData;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '400';
                $responseHeader['message'] = 'An unexpected error occurred and your product could not be retrieved. Please, try again later.';
                $Response['status'] = 400;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * fetchProjectsByProjectName
         *
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function fetchProjectsByProjectNameAndWing($request, $response)
        {
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                $Response = [];
                $data_loaded= $this->loadProjectsData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());

                $filterData =  [];
                $filterData["projectName"] = $request->projectName;
                $filterData["wing"] = $request->wing;
                $filteredProjectData = $ProjectModel->filterData($data, $filterData);
                if (count($filteredProjectData) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $filteredProjectData;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '400';
                $responseHeader['message'] = 'An unexpected error occurred and your product could not be retrieved. Please, try again later.';
                $Response['status'] = 400;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * fetchProjectsByProjectName
         *
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function fetchProjectsByProjectNameAndWingAndFloor($request, $response)
        {
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                $Response = [];
                $data_loaded= $this->loadProjectsData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());

                $filterData =  [];
                $filterData["projectName"] = $request->projectName;
                $filterData["wing"] = $request->wing;
                $filterData["floorNo"] = $request->floorNo;
                $filteredProjectData = $ProjectModel->filterData($data, $filterData);
                if (count($filteredProjectData) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $filteredProjectData;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '400';
                $responseHeader['message'] = 'An unexpected error occurred and your product could not be retrieved. Please, try again later.';
                $Response['status'] = 400;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * overAllSummary
         *
         * Fetches an Array of Over All Summary....
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function overallSummary($request, $response)
        {
            //echo "overallSummary ";
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }
            //echo "After validateJwtToken ";
            try {
                $Response = [];
                $data_loaded= $this->loadProjectsData();
                //echo "data_loaded " . json_encode($data_loaded);
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                /*$data = $this->cacheUtils->getAppCache($this->cacheKeyForCustomer(), TrackingSystemConstants::$cacheKey_RoomDetails);
                //echo "data : " . json_encode($data);
                $Response = [];
                $ProjectModel = new ProjectModel();
                if ($data == null) {
                    $projects = $ProjectModel->fetchProjects();
                    if ($projects['status']) {
                        $data = $projects['data'];
                        $this->cacheUtils->setAppCache($this->cacheKeyForCustomer(), TrackingSystemConstants::$cacheKey_RoomDetails, $data);
                    }else{
                        $responseHeader['code'] = $projects['code'];
                        $responseHeader['message'] = $projects['message'];
                        $Response['status'] = $projects['code'];
                        $Response['header'] = $responseHeader;
                        $Response['data'] = [];
                        $response->code($projects['code'])->json($Response);
                        return;
                    }
                }*/

                $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());
                $overallStatusArr = $ProjectModel->populateOverallSummary($data);
                if (count($overallStatusArr) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $overallStatusArr;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '400';
                $responseHeader['message'] = 'An unexpected error occurred and your product could not be retrieved. Please, try again later.';
                $Response['status'] = 400;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * modifiedLogs
         *
         * Fetches an Array of Over All Summary....
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function modifiedLogs($request, $response)
        {
            //echo  "modifiedLogs";
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                /*$data = $this->cacheUtils->getAppCache($this->cacheKeyForCustomer(), TrackingSystemConstants::$cacheKey_RoomModifiedLogs);
                //echo "data : " . json_encode($data);
                $Response = [];
                if ($data == null) {
                    $ProjectModel = new ProjectModel();
                    $projects = $ProjectModel->fetchRoomModifiedLogs();
                    if ($projects['status']) {
                        $data = $projects['data'];
                        $this->cacheUtils->setAppCache($this->cacheKeyForCustomer(), TrackingSystemConstants::$cacheKey_RoomModifiedLogs, $data);
                    }else{
                        $responseHeader['code'] = $projects['code'];
                        $responseHeader['message'] = $projects['message'];
                        $Response['status'] = $projects['code'];
                        $Response['header'] = $responseHeader;
                        $Response['data'] = [];
                        $response->code($projects['code'])->json($Response);
                        return;
                    }
                }*/

                $Response = [];
                $data_loaded= $this->loadModifiedLogData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                if (count($data) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $data;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '400';
                $responseHeader['message'] = 'An unexpected error occurred and your product could not be retrieved. Please, try again later.';
                $Response['status'] = 400;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * modifiedLogsForProject
         *
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function modifiedLogsForProject($request, $response)
        {
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                /*$data = $this->cacheUtils->getAppCache($this->cacheKeyForCustomer(), TrackingSystemConstants::$cacheKey_RoomModifiedLogs);
                //echo "data : " . json_encode($data);
                $Response = [];
                $ProjectModel = new ProjectModel();
                if ($data == null) {
                    $projects = $ProjectModel->fetchRoomModifiedLogs();
                    if ($projects['status']) {
                        $data = $projects['data'];
                        $this->cacheUtils->setAppCache($this->cacheKeyForCustomer(), TrackingSystemConstants::$cacheKey_RoomModifiedLogs, $data);
                    }else{
                        $responseHeader['code'] = $projects['code'];
                        $responseHeader['message'] = $projects['message'];
                        $Response['status'] = $projects['code'];
                        $Response['header'] = $responseHeader;
                        $Response['data'] = [];
                        $response->code($projects['code'])->json($Response);
                        return;
                    }
                }*/

                $Response = [];
                $data_loaded= $this->loadModifiedLogData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());
                $filterData =  [];
                $filterData["projectName"] = $request->projectName;
                $filteredProjectData = $ProjectModel->filterData($data, $filterData);
                if (count($filteredProjectData) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $filteredProjectData;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '200';
                $responseHeader['message'] = 'No modified logs data found. Please, try again later.';
                $Response['status'] = 200;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * modifiedLogsByPeriod
         *
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function modifiedLogsByPeriod($request, $response)
        {
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                /*$data = $this->cacheUtils->getAppCache($this->cacheKeyForCustomer(), TrackingSystemConstants::$cacheKey_RoomModifiedLogs);
                //echo "data : " . json_encode($data);
                $Response = [];
                $ProjectModel = new ProjectModel();
                if ($data == null) {
                    $projects = $ProjectModel->fetchRoomModifiedLogs();
                    if ($projects['status']) {
                        $data = $projects['data'];
                        $this->cacheUtils->setAppCache($this->cacheKeyForCustomer(), TrackingSystemConstants::$cacheKey_RoomModifiedLogs, $data);
                    }else{
                        $responseHeader['code'] = $projects['code'];
                        $responseHeader['message'] = $projects['message'];
                        $Response['status'] = $projects['code'];
                        $Response['header'] = $responseHeader;
                        $Response['data'] = [];
                        $response->code($projects['code'])->json($Response);
                        return;
                    }
                }*/

                $Response = [];
                $data_loaded= $this->loadModifiedLogData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());
                $filteredProjectData = $ProjectModel->filterRoomModifiedLogsData($data, $request->period);
                if (count($filteredProjectData) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $filteredProjectData;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '200';
                $responseHeader['message'] = 'No modified logs data found. Please, try again later.';
                $Response['status'] = 200;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }


        /**
         * securityRooms
         *
         * Fetches an Array of Over All Summary....
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function securityRooms($request, $response)
        {
            //echo  "modifiedLogs";
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                $Response = [];
                $data_loaded= $this->loadSecurityRoomsData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                if (count($data) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $data;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '400';
                $responseHeader['message'] = 'An unexpected error occurred and your product could not be retrieved. Please, try again later.';
                $Response['status'] = 400;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * securityRoomsForProject
         *
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function securityRoomsForProject($request, $response)
        {
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                $Response = [];
                $data_loaded= $this->loadSecurityRoomsData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());
                $filterData =  [];
                $filterData["projectName"] = $request->projectName;
                $filteredProjectData = $ProjectModel->filterData($data, $filterData);
                if (count($filteredProjectData) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $filteredProjectData;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '200';
                $responseHeader['message'] = 'No modified logs data found. Please, try again later.';
                $Response['status'] = 200;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * serverRooms
         *
         * Fetches an Array of Over All Summary....
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function serverRooms($request, $response)
        {
            //echo  "modifiedLogs";
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                $Response = [];
                $data_loaded= $this->loadServerData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                if (count($data) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $data;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '400';
                $responseHeader['message'] = 'An unexpected error occurred and your product could not be retrieved. Please, try again later.';
                $Response['status'] = 400;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * securityRoomsForProject
         *
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function serverRoomsForProject($request, $response)
        {
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                $Response = [];
                $data_loaded= $this->loadServerData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());
                $filterData =  [];
                $filterData["projectName"] = $request->projectName;
                $filteredProjectData = $ProjectModel->filterData($data, $filterData);
                if (count($filteredProjectData) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $filteredProjectData;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '200';
                $responseHeader['message'] = 'No modified logs data found. Please, try again later.';
                $Response['status'] = 200;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * serverRoomsLogs
         *
         * Fetches an Array of Over All Summary....
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function serverRoomsLogs($request, $response)
        {
            //echo  "modifiedLogs";
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                $Response = [];
                $data_loaded= $this->loadServerLogsData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                if (count($data) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $data;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '400';
                $responseHeader['message'] = 'An unexpected error occurred and your product could not be retrieved. Please, try again later.';
                $Response['status'] = 400;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * serverRoomsLogsByPeriod
         *
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function serverRoomsLogsByPeriod($request, $response)
        {
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                $Response = [];
                $data_loaded= $this->loadServerLogsData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());
                $filteredProjectData = $ProjectModel->filterRoomModifiedLogsData($data, $request->period);
                if (count($filteredProjectData) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $filteredProjectData;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '200';
                $responseHeader['message'] = 'No server room logs data found. Please, try again later.';
                $Response['status'] = 200;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * serverRoomsLogsForProject
         *
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function serverRoomsLogsForProject($request, $response)
        {
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                $Response = [];
                $data_loaded= $this->loadServerLogsData();
                if(isset($data_loaded["ResponseData"])){
                    $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                    return;
                }
                $data = $data_loaded["data"];

                $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());
                $filterData =  [];
                $filterData["projectName"] = $request->projectName;
                $filteredProjectData = $ProjectModel->filterData($data, $filterData);
                if (count($filteredProjectData) > 0) {
                    $responseHeader = [];
                    $responseHeader['success'] = true;
                    $responseHeader['code'] = '200';
                    $responseHeader['message'] = '';
                    $Response['status'] = 200;
                    $Response['header'] = $responseHeader;
                    $Response['data'] = $filteredProjectData;

                    $response->code(200)->json($Response);
                    return;
                }
                $responseHeader = [];
                $responseHeader['success'] = false;
                $responseHeader['code'] = '200';
                $responseHeader['message'] = 'No server room logs data found. Please, try again later.';
                $Response['status'] = 200;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(400)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        /**
         * updateStatus
         *
         * Update Status
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function updateStatus($request, $response)
        {
            $Response = [];
            $Middleware = new RequestMiddleware();
            $Middleware = $Middleware::acceptsJson();

            if (!$Middleware) {
                array_push($Response, [
                    'status' => 400,
                    'message' => 'Sorry, Only JSON Contents are allowed to access this Endpoint.',
                    'data' => []
                ]);

                $response->code(400)->json($Response);
                return;
            }
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }


            $data = json_decode($request->body());
            // Do some validation...
            $validationObject = array(
                (Object) [
                    'validator' => 'required',
                    'data' => isset($data->documentId) ? $data->documentId : '',
                    'key' => 'Document ID'
                ],
                (Object) [
                    'validator' => 'required',
                    'datatype' => 'array',
                    'data' => isset($data->modifiedData) ? $data->modifiedData : [],
                    'key' => 'Modified Data'
                ]
            );

            $validationBag = $this->validation($validationObject);
            if ($validationBag->status) {
                $response->code(400)->json($validationBag);
                return;
            }

            $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());

            $data_loaded= $this->loadProjectsData();
            if(isset($data_loaded["ResponseData"])){
                $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                return;
            }
            $project_data = $data_loaded["data"];
            $filterData =  [];
            $filterData["id"] = $data->documentId;
            $filteredProjectData = $ProjectModel->filterData($project_data, $filterData);
            //echo"filteredProjectData -> " . json_encode($filteredProjectData);
            //echo"count -> " . count($filteredProjectData);
            if (count($filteredProjectData) > 0) {
                /*$responseHeader = [];
                $responseHeader['code'] = '200';
                $responseHeader['message'] = '';
                $Response['status'] = 200;
                $Response['header'] = $responseHeader;
                $Response['data'] = $filteredProjectData;

                $response->code(200)->json($Response);
                return;*/

                try {

                    if ($data->documentId) {
                        $updateResponse = $ProjectModel->updateStatus($data->documentId, $data->modifiedData, $filteredProjectData, $this->tokenUtils->getTokenData());
                        // Return Response............
                        $responseHeader = [];
                        $responseHeader['success'] = true;
                        $responseHeader['code'] = '200';
                        $responseHeader['message'] = 'Updated Successfully';
                        $Response['status'] = 200;
                        $Response['header'] = $responseHeader;
                        $Response['data'] = ["roomLogRef" => isset($updateResponse['roomLogRef']) ? $updateResponse['roomLogRef'] : ''];
                        $response->code(200)->json($Response);
                        return;
                    }

                    $Response['status'] = 500;
                    $Response['message'] = 'An unexpected error occurred and your account could not be created. Please, try again later.';
                    $Response['data'] = [];

                    $response->code(500)->json($Response);
                    return;
                } catch (Exception $e) {
                    $Response['status'] = 500;
                    $Response['message'] = $e->getMessage();
                    $Response['data'] = [];

                    $response->code(500)->json($Response);
                    return;
                }
            }else{
                $responseHeader = [];
                $responseHeader['success'] = true;
                $responseHeader['code'] = '200';
                $responseHeader['message'] = 'Document not found for the Document ID';
                $Response['status'] = 701;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];
                $response->code(500)->json($Response);
                return;
            }

        }

        /**
         * updateStatus
         *
         * Update Status
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function updateServer($request, $response)
        {
            $Response = [];
            $Middleware = new RequestMiddleware();
            $Middleware = $Middleware::acceptsJson();

            if (!$Middleware) {
                array_push($Response, [
                    'status' => 400,
                    'message' => 'Sorry, Only JSON Contents are allowed to access this Endpoint.',
                    'data' => []
                ]);

                $response->code(400)->json($Response);
                return;
            }
            if(!$this->tokenUtils->validateJwtToken(TrackingSystemConstants::$jwtTokenValidationFlag, $response)) {
                return;
            }


            $data = json_decode($request->body());
            // Do some validation...
            $validationObject = array(
                (Object) [
                    'validator' => 'required',
                    'data' => isset($data->documentId) ? $data->documentId : '',
                    'key' => 'Document ID'
                ],
                (Object) [
                    'validator' => 'required',
                    'datatype' => 'array',
                    'data' => isset($data->modifiedData) ? $data->modifiedData : [],
                    'key' => 'Modified Data'
                ]
            );

            $validationBag = $this->validation($validationObject);
            if ($validationBag->status) {
                $response->code(400)->json($validationBag);
                return;
            }

            $ProjectModel = new ProjectModel($this->getLoggedInCompanyId());

            $data_loaded= $this->loadServerData();
            if(isset($data_loaded["ResponseData"])){
                $response->code($data_loaded["ResponseData"]['header']['code'])->json($data_loaded["ResponseData"]);
                return;
            }
            $project_data = $data_loaded["data"];
            $filterData =  [];
            $filterData["id"] = $data->documentId;
            $filteredProjectData = $ProjectModel->filterData($project_data, $filterData);
            //echo"filteredProjectData -> " . json_encode($filteredProjectData);
            //echo"count -> " . count($filteredProjectData);
            if (count($filteredProjectData) > 0) {
                /*$responseHeader = [];
                $responseHeader['code'] = '200';
                $responseHeader['message'] = '';
                $Response['status'] = 200;
                $Response['header'] = $responseHeader;
                $Response['data'] = $filteredProjectData;

                $response->code(200)->json($Response);
                return;*/

                try {

                    if ($data->documentId) {
                        $updateResponse = $ProjectModel->updateServer($data->documentId, $data->modifiedData, $filteredProjectData, $this->tokenUtils->getTokenData());
                        // Return Response............
                        $responseHeader = [];
                        $responseHeader['success'] = true;
                        $responseHeader['code'] = '200';
                        $responseHeader['message'] = 'Updated Successfully';
                        $Response['status'] = 200;
                        $Response['header'] = $responseHeader;
                        $Response['data'] = ["roomLogRef" => isset($updateResponse['roomLogRef']) ? $updateResponse['roomLogRef'] : ''];
                        $response->code(200)->json($Response);
                        return;
                    }

                    $Response['status'] = 500;
                    $Response['message'] = 'An unexpected error occurred and your account could not be created. Please, try again later.';
                    $Response['data'] = [];

                    $response->code(500)->json($Response);
                    return;
                } catch (Exception $e) {
                    $Response['status'] = 500;
                    $Response['message'] = $e->getMessage();
                    $Response['data'] = [];

                    $response->code(500)->json($Response);
                    return;
                }
            }else{
                $responseHeader = [];
                $responseHeader['success'] = true;
                $responseHeader['code'] = '200';
                $responseHeader['message'] = 'Document not found for the Document ID';
                $Response['status'] = 701;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];
                $response->code(500)->json($Response);
                return;
            }

        }

        /**
         * cleanCache
         *
         * Clean Cache - Project Data
         *
         * @param mixed $request $response Contains the Request and Respons Object from the router.
         * @return mixed Anonymous
         */
        public function cleanCache($request, $response)
        {
            //echo "\ncleanCache\n";
            $this->cleanAppCacheAll($this->cacheKeyForCustomer(), TrackingSystemConstants::$jwtTokenValidationFlag, TrackingSystemConstants::allCacheKeys(), $request, $response);
            return;
            /*if(!$this->tokenUtils->validateJwtToken($this->$jwtTokenValidationFlag, $response)) {
                return;
            }

            try {
                $data = $this->cacheUtils->removeAllAppCache($this->$cacheKey_AppName, $this->getAllCacheKeys());
                $responseHeader = [];
                $responseHeader['code'] = '200';
                $responseHeader['message'] = 'Cache Cleaned';
                $Response['status'] = 200;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(200)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }*/
        }

        public function cleanCacheByKey($request, $response)
        {
            if(isset($request->id)){
                $this->cleanAppCacheKey($this->cacheKeyForCustomer(), TrackingSystemConstants::$jwtTokenValidationFlag, $request->id, $request, $response);
            }else{
                $Response['status'] = 500;
                $Response['message'] = "Key Not Found";
                $Response['data'] = [];
                $response->code(500)->json($Response);
            }
            return;
        }

    }
?>