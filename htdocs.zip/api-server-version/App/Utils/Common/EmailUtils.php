<?php

    namespace App\Utils\Common;
    use Symfony\Component\Cache\Adapter\FilesystemAdapter;
    use App\Utils\Common\AppConstants;

    class EmailUtils
    {
        protected $path = null;

        function __construct ($path) {
            $this->path = $path;
        }

        function sendEmail($appName, $mailData) {
            //echo "\nsendEmail -> mailData" . json_encode($mailData);
            $message = $this->getTemplate($appName, $mailData["template"]);
            if($message !== AppConstants::$EMAIL_TEMPLATE_NOT_FOUND){
                $message = self::populateMessageInTemplateHtml($message, $mailData);
                $mail_headers = "From:". $mailData["email_from_name"] . "<" . $mailData["email_from_id"] . ">\r\n";
                $mail_headers .= "MIME-Version: 1.0\r\n";
                $mail_headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
                if($mailData["CC"]){
                    $mail_headers .= "CC:". $mailData["CC"] . "\r\n";
                }
                echo "\nsendEmail -> mail_headers" . $mail_headers;
                echo "\nsendEmail -> email_to" . $mailData["email_to"];
                echo "\nsendEmail -> subject" . $mailData["subject"];
                $mailStatus =  mail($mailData["email_to"], $mailData["subject"], $message, $mail_headers);
                if($mailStatus){
                    echo "\nsendEmail -> SUCCESS";
                }else{
                    echo "\nsendEmail -> FAILURE";
                }
            }else{
                echo "\nsendEmail -> Template -> EMAIL_TEMPLATE_NOT_FOUND";
            }
            echo "\n";
        }

        private function getTemplate( $appName, $templateFile) {
            //echo "\nsendEmail -> getTemplate -> appName -> " . $appName;
            $file = $this->path . $appName . DIRECTORY_SEPARATOR . $templateFile;
            //echo "\nsendEmail -> getTemplate -> file -> " . $file;
            if(file_exists($file)){
                return file_get_contents($file);
            }else{
                return AppConstants::$EMAIL_TEMPLATE_NOT_FOUND;
            }
        }

        private function populateMessageInTemplateHtml($message, $mailData) {
            if($mailData["template_data"]){
                foreach (array_keys($mailData["template_data"]) as $key){
                    $message = str_replace($key, $mailData["template_data"][$key], $message);
                }
            }
            return $message;
        }

    }

