import React, { useState, useEffect } from 'react';
import { Header, Table, Rating } from 'semantic-ui-react'
import {getFailureResponseData, getSuccessResponseData, isValidServiceResponse} from "../../service/common/ServiceUtils";
import {overallSummary} from "../../service/tracking_system/ApiService";
import {START_LOADING, STOP_LOADING} from "../../utils/portal/PortalAction";
import {usePortalDispatch} from "../../context/portal/PortalProvider";
import {getOverAllSummary, setOverAllSummary} from "../../utils/tracking_system/TrackingSystemCache";

export const OverallSummary = (props) => {
    const portalDispatch = usePortalDispatch();
    const [overallSummaryData, setOverallSummaryData] = useState([]);
    const [overallSummaryServiceCallInProgress, setOverallSummaryServiceCallInProgress] = useState(false);
    const [overallSummaryServiceCallStatus, setOverallSummaryServiceCallStatus] = useState("");

    const overallSummaryServiceSuccess = function(successResponse){
        console.log('overallSummaryServiceSuccess : ' + JSON.stringify(successResponse));
        if(isValidServiceResponse(successResponse)){
            let overallSummaryResponse = getSuccessResponseData(successResponse);
            console.log('overallSummaryResponse : ' + JSON.stringify(overallSummaryResponse));
            setOverAllSummary(props.company.company_id, overallSummaryResponse.data);
            loadOverAllSummaryData(overallSummaryResponse.data);
        }
        setOverallSummaryServiceCallInProgress(false);
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const loadOverAllSummaryData = function(overallSummaryData){
        setOverallSummaryServiceCallStatus("SUCCESS");
        setOverallSummaryData(overallSummaryData);
    }

    const overallSummaryServiceFailure = function(failureResponse){
        console.log('overallSummaryServiceFailure : ' + JSON.stringify(failureResponse));
        let failureData = getFailureResponseData(failureResponse);
        console.log('failureData : ' + JSON.stringify(failureData));
        setOverallSummaryServiceCallInProgress(false);
        setOverallSummaryServiceCallStatus("FAILURE");
        portalDispatch({
            type: STOP_LOADING
        })
    }

    useEffect(() => {
        console.log('overallSummary_js : useEffect ');
        if(getOverAllSummary(props.company.company_id)){
            console.log('overallSummary_js : getOverAllSummary IS not empty ');
            loadOverAllSummaryData(getOverAllSummary(props.company.company_id));
        }else{
            console.log('overallSummary_js : getOverAllSummary IS empty ' + overallSummaryServiceCallInProgress);
            if(!overallSummaryServiceCallInProgress){
                portalDispatch({
                    type: START_LOADING
                })
                setOverallSummaryServiceCallInProgress(true);
                overallSummary({headers:{companyId : props.company.company_id}}, overallSummaryServiceSuccess, overallSummaryServiceFailure, portalDispatch);
            }
        }
    }, []);

    const overAllStatusDesc = {
        "occupied" : "Occupied",
        "notOccupied" : "Not Occupied",
        "pending"  : "Pending",
        "completed" : "Completed",
        "onProgress" : "On Progress",
        "dependency" : "Dependency",
        "notStarted" : "Not Started"
    };

    return (
        <div>
            {console.log("Inside OverallSummary screen")}
            <div className="flex items-center mt-24 mb-10">
                {(overallSummaryServiceCallStatus == "SUCCESS" && overallSummaryData  && overallSummaryData != null)
                    ?
                    <Table celled padded>
                        <Table.Header>
                            <Table.Row>
                                <Table.HeaderCell singleLine textAlign='center'>Status</Table.HeaderCell>
                                {
                                    Object.keys(overallSummaryData).map((projectName) => (
                                        <Table.HeaderCell textAlign='center'>{projectName}</Table.HeaderCell>
                                    ))
                                }
                            </Table.Row>
                        </Table.Header>

                        <Table.Body>
                            {Object.keys(overallSummaryData["All"] ? overallSummaryData["All"] : {}).map((status) => (
                                <Table.Row>
                                    <Table.Cell>
                                        <Header as='h5' textAlign='center'>
                                            {overAllStatusDesc[status]}
                                        </Header>
                                    </Table.Cell>
                                        {
                                            Object.keys(overallSummaryData).map((projectName) => (
                                                <Table.Cell singleLine textAlign='center'>{overallSummaryData[projectName][status]}</Table.Cell>
                                            ))
                                        }
                                </Table.Row>
                            ))}
                        </Table.Body>
                    </Table>
                    :
                    <h4>Error in Service...</h4>
                }
            </div>
        </div>
    )
}