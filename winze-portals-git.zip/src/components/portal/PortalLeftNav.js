import React from 'react';
import Divider from '@material-ui/core/Divider';
import Drawer from '@material-ui/core/Drawer';
import Hidden from '@material-ui/core/Hidden';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import BusinessIcon from '@material-ui/icons/Business';
import HomeIcon from '@material-ui/icons/Home';
import Toolbar from "@material-ui/core/Toolbar";
import Button from "@material-ui/core/Button";
import {usePortalState} from '../../context/portal/PortalProvider'
import logo from './../../images/portal/logo.png'
import {Link} from "react-router-dom";
import {CustomizedListItem} from "./CustomizedListItem";

const useStyles = makeStyles((theme) => ({
    logo: {
        width: '200px',
        padding: '1px',
        background: "white",
        borderRadius: "1px"
    }
}));

export const PortalLeftNav = (props) => {
    const { window } = props;
    const classes = useStyles();
    const theme = useTheme();
    const [mobileOpen, setMobileOpen] = React.useState(false);
    const {leftMenuList} = usePortalState();

    const handleDrawerToggle = () => {
        setMobileOpen(!mobileOpen);
    };

    const getMenuIcon = (iconKey) => {
        if(iconKey === "home"){
            return <HomeIcon/>;
        }else if(iconKey === "biz"){
            return <BusinessIcon/>;
        }
        return <BusinessIcon/>;
    };

    const getDivider = (dividerFlag) => {
        if(dividerFlag){
            return <Divider/>;
        }
        return <></>;
    };

    let leftMenuListDrawer = (leftMenuList && leftMenuList.length > 0) ? leftMenuList.map(function(leftMenu){
        return <CustomizedListItem menuItem={leftMenu} level={0}/>;
    }) : <></>

    const leftMenuDrawer = (
        <div>
            <Button target="_blank" color="inherit" href="http://www.winzetech.com/">
                <Toolbar>
                    <img src={logo} alt="logo" className={classes.logo} />
                    {/*<span style={{fontSize: '24px'}}>Glass</span>*/}
                </Toolbar>
            </Button>
            {(leftMenuList && leftMenuList.length > 0) ?
                <>
                    <Divider/>
                    <List>
                        {leftMenuListDrawer}
                    </List>
                    <Divider/>
                </>
                :
                <></>
            }
        </div>
    );

    const container = window !== undefined ? () => window().document.body : undefined;

    return (
        <nav className={classes.drawer} aria-label="mailbox folders" id="navLeft">
            {/* The implementation can be swapped with js to avoid SEO duplication of links. */}
            <Hidden smUp implementation="css">
                <Drawer
                    container={container}
                    variant="temporary"
                    anchor={theme.direction === 'rtl' ? 'right' : 'left'}
                    open={mobileOpen}
                    onClose={handleDrawerToggle}
                    classes={{
                        paper: classes.drawerPaper,
                    }}
                    ModalProps={{
                        keepMounted: true, // Better open performance on mobile.
                    }} >
                    {leftMenuDrawer}
                </Drawer>
            </Hidden>
            <Hidden xsDown implementation="css">
                <Drawer
                    classes={{
                        paper: classes.drawerPaper,
                    }}
                    variant="permanent"
                    open >
                    {leftMenuDrawer}
                </Drawer>
            </Hidden>
        </nav>
    )
}