<?php

    /**
      * @author Ilori Stephen A
    **/
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");

    require_once __DIR__ . '/vendor/autoload.php';
    use Dotenv\Dotenv;
	use Batch\TrackingSystem\DailyReport;

    //use App\Utils\Common\CacheUtils;

    $dotenv = new DotEnv(__DIR__);
    $dotenv->load();


    $dailyReport = new DailyReport();
	//echo "\nsendDailyReport -> Test\n";
	$responseData = $dailyReport::sendDailyReport();
	//echo "\nsendDailyReport -> Tes -> Endt\n" . json_encode($responseData);
    echo json_encode($responseData);

?>
