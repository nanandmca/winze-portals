<?php

    namespace App\Model\Security;

    use App\Model\Security\SecurityModel;

    /**
     * UserModel - This Model is consumed basically by the UserController and is also consumed by other controllers and Middlewares...
     *
     * @author      Ilori Stephen A <stephenilori458@gmail.com>
     * @link        https://github.com/learningdollars/php-rest-api/App/Model/UserModel.php
     * @license     MIT
     */
    class UserModel extends SecurityModel {

         /**
         * createUser
         *
         * creates a new User
         *
         * @param array $payload  Contains all the fields that will be created.
         * @return array Anonymous
         */
        public function createUser($payload)
        {
            $Sql = "INSERT INTO `db_users` (firstName, lastName, email, password, created_at, updated_at) VALUES (:firstName, :lastName, :email, :password, :created_at, :updated_at)";
            $this->query($Sql);
            // Bind Params...
            $this->bindParams('firstName', $payload['firstName']);
            $this->bindParams('lastName', $payload['lastName']);
            $this->bindParams('email', $payload['email']);
            $this->bindParams('password', $payload['password']);
            $this->bindParams('created_at', $payload['created_at']);
            $this->bindParams('updated_at', $payload['updated_at']);

            $newUser = $this->execute();
            if ($newUser) {
                $user_id = $this->lastInsertedId();
                $payload['user_id'] = $user_id;
                $Response = array(
                    'status' => true,
                    'data' => $payload
                );
                return $Response;
            }

            $Response = array(
                'status' => false,
                'data' => []
            );
            return $Response;
        }

        /**
         * createUser
         *
         * creates a new User
         *
         * @param array $payload  Contains all the fields that will be created.
         * @return array Anonymous
         */
        public function storeUserLoginAudit($payload)
        {
            $Sql = "INSERT INTO `db_user_login_audit` (user_email, login_status, login_date_time) VALUES (:user_email, :login_status, :login_date_time)";
            $this->query($Sql);
            // Bind Params...
            $this->bindParams('user_email', $payload['email']);
            $this->bindParams('login_status', $payload['login_status']);
            $this->bindParams('login_date_time', $payload['login_date_time']);

            $newUser = $this->execute();
            if ($newUser) {
                $user_id = $this->lastInsertedId();
                $payload['user_id'] = $user_id;
                $Response = array(
                    'status' => true,
                    'data' => $payload
                );
                return $Response;
            }

            $Response = array(
                'status' => false,
                'data' => []
            );
            return $Response;
        }

        /**
         * updatePassword
         *
         * updatePassword
         *
         * @param array $payload  Contains all the fields that will be created.
         * @return array Anonymous
         */
        public function updatePassword($payload)
        {
            $Sql = "UPDATE `db_users` SET password = :password, updated_at = :updated_at where id = :user_id";
            $this->query($Sql);
            // Bind Params...
            $this->bindParams('password', $payload['newPassword']);
            $this->bindParams('updated_at', $payload['updated_at']);
            $this->bindParams('user_id', $payload['user_id']);

            $newUser = $this->execute();
            if ($newUser) {
                $Response = array(
                    'status' => true,
                    'data' => []
                );
                return $Response;
            }

            $Response = array(
                'status' => false,
                'data' => []
            );
            return $Response;
        }


         /**
         * fetchUserById
         *
         * fetches a user by it's Id
         *
         * @param int $Id  The Id of the row to be fetched...
         * @return array Anonymous
         */
        public function fetchUserById($Id)
        {
            $Sql = "SELECT id, firstName, lastName, email, created_at, updated_at FROM `db_users` WHERE id = :id";
            $this->query($Sql);
            // Bind Params...
            $this->bindParams('id', $Id);
            $Data = $this->fetch();

            if (!empty($Data)) {
                return array(
                    'status' => true,
                    'data' => $Data
                );
            }

            return array(
                'status' => false,
                'data' => []
            );
        }

        /**
         * checkEmail
         *
         * fetches a user by it's email
         *
         * @param string $email  The email of the row to be fetched...
         * @return array Anonymous
         */
        public function checkEmail($email)
        {
            $Sql = "SELECT * FROM `db_users` WHERE email = :email";
            $this->query($Sql);
            // Bind Params...
            $this->bindParams('email', $email);
            $emailData = $this->fetch();
            if (empty($emailData)) {
                $Response = array(
                    'status' => false,
                    'data' => []
                );
                return $Response;
            }

            $Response = array(
                'status' => true,
                'data' => $emailData
            );
            return $Response;
        }
    }
?>
