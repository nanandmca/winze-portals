<?php

    namespace App\Utils\Common;
    use Symfony\Component\Cache\Adapter\FilesystemAdapter;

    class CacheUtils
    {
        protected $path = null;
        protected $duration = null;

        function __construct ( $path, $duration = 60) {
            $this->path = $path;
            $this->duration = $duration;
        }

        function getAppCache( $appName, $id ) {
            return self::get( $appName . '.' . $id);
        }

        private function get( $id ) {
            $file = $this->path . $id . '.cache';
            //echo "\nfile : " . $file;
            //echo "\n<BR>time : " . time();
            //echo "\n<BR>filemtime : " . filemtime($file);
            //echo "\n<BR>timetaken : " . (time() - filemtime($file));
            //echo "\n<BR>duration : " . $this->duration;
            if (file_exists($file) && time() - filemtime($file) < $this->duration) {
                //echo "\n Inside File Available \n" . unserialize(file_get_contents($file));
                return json_decode(unserialize(file_get_contents($file)));
            } else {
                //echo "\n Inside File NOT Available \n";
                return null;
            }
        }

        function setAppCache( $appName, $id, $obj) {
            self::set( $appName . '.' . $id, $obj);
        }

        private function set( $id, $obj) {
            $file = $this->path . $id . '.cache';
            if(!file_exists($this->path)){
                //echo "Directory Not Exists";
                mkdir($this->path);
            }
            file_put_contents($file, serialize(json_encode($obj)));
        }

        function removeAllAppCache( $appName, $idList ) {
            foreach ($idList as $id){
                self::remove( $appName . '.' . $id);
            }
        }

        function removeAppCache( $appName, $id ) {
            self::remove( $appName . '.' . $id);
        }

        private function remove( $id ) {
            $file = $this->path . $id . '.cache';
            if(file_exists($file)){
                //echo "File Exists - Remove";
                unlink($file);
            }
        }

    }

