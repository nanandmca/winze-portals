<?php

    namespace App\Utils\Common;

    use App\Utils\Security\SecurityConstants;

    class CommonUtils
    {

        public function filterArrayByKeys(array $input, array $column_keys)
        {
            $result      = array();
            $column_keys = array_flip($column_keys); // getting keys as values
            foreach ($input as $key => $val) {
                // getting only those key value pairs, which matches $column_keys
                $result[$key] = array_intersect_key($val, $column_keys);
            }
            return $result;
        }

        public function getCompanyIdFromHeader()
        {
            /**
            foreach (getallheaders() as $name => $value) {
            echo "$name: $value\n";
            }
            foreach($_SERVER as $key_name => $key_value) {
            echo "$key_name: $key_value\n";
            }**/
            //echo "TEST_HEADER : ". $_SERVER['TEST_HEADER'];
            if (isset($_SERVER['companyId']))
            {
                return $_SERVER['companyId'];
            }else if (isset($_SERVER['HTTP_COMPANYID']))
            {
                return $_SERVER['HTTP_COMPANYID'];
            }else if (isset($_SERVER['REDIRECT_HTTP_COMPANYID']))
            {
                return $_SERVER['REDIRECT_HTTP_COMPANYID'];
            }
            //echo "ELSE HTTP_AUTHORIZATION : ";
            return null;
        }

    }

