<?php

    namespace App\Model\Samples;

    use Dotenv\Dotenv;
    use App\Model;

    class SamplesModel extends Model {

        public function __construct()
        {
            //echo "APP_ENV : " . getenv("APP_ENV");
            $dotenv = new DotEnv(__DIR__, '../../../.env');
            $dotenv->load();

            $dotenv = new DotEnv(__DIR__, '../../../.env.samples.' . getenv("APP_ENV"));
            $dotenv->load();
            //echo "SAMPLES_DB_HOST : " . getenv("SAMPLES_DB_HOST");

            parent::__construct(getenv("SAMPLES_DB_HOST"), getenv("SAMPLES_DB_PORT"), getenv("SAMPLES_DB_DATABASE"), getenv("SAMPLES_DB_USERNAME"), getenv("SAMPLES_DB_PASSWORD"));
        }

    }

?>
