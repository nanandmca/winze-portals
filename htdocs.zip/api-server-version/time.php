<?php 
//require("adodb-time.inc.php"); 

echo 'http://'. $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];

$datestring = "2063-12-24"; // string normally from mySQL 

echo( "Original: $datestring<br>" );

?>