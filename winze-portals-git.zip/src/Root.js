import React from 'react';
import { PortalProvider } from './context/portal/PortalProvider';
import App from './App';

function Root() {
  return (
      <>
          <PortalProvider>
              <App/>
          </PortalProvider>
      </>
  );
}
export default Root;