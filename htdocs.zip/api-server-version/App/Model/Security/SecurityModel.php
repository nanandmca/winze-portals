<?php

    namespace App\Model\Security;

    use Dotenv\Dotenv;
    use App\Model;

    class SecurityModel extends Model {

        public function __construct()
        {
            //echo "APP_ENV : " . getenv("APP_ENV");

            $dotenv = new DotEnv(__DIR__, '../../../.env');
            $dotenv->load();

            $dotenv = new DotEnv(__DIR__, '../../../.env.login.' . getenv("APP_ENV"));
            $dotenv->load();
            //echo "SECURITY_DB_HOST : " . getenv("SECURITY_DB_HOST");

            parent::__construct(getenv("SECURITY_DB_HOST"), getenv("SECURITY_DB_PORT"), getenv("SECURITY_DB_DATABASE"), getenv("SECURITY_DB_USERNAME"), getenv("SECURITY_DB_PASSWORD"));
        }

    }
?>
