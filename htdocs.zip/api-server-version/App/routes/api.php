<?php

    namespace App;

    use App\Controller\Security\UserController;
    use App\Controller\Samples\CatalogController;
    use App\Controller\Samples\ProductController;
    use App\Controller\TrackingSystem\ProjectController;

    $Klein = new \Klein\Klein();
    //printf("Inside");
    //echo "Klein insoide";
    header('Content-Type: application/json');
    /******************** User Routes || Authentication Routes **********************/
    $Klein->respond('POST', '/api/v1/user', [ new UserController(), 'createNewUser' ]);
    $Klein->respond('POST', '/api/v1/user-auth', [ new UserController(), 'login' ]);
    $Klein->respond('POST', '/api/v1/change-password', [ new UserController(), 'changePassword' ]);
    $Klein->respond('POST', '/api/v1/update-password', [ new UserController(), 'updatePassword' ]);
    $Klein->respond('POST', '/api/v1/clear-session', [ new UserController(), 'logout' ]);
    $Klein->respond('GET', '/api/v1/keep-alive', [ new UserController(), 'keepAlive' ]);

    /******************** Catalog Routes **********************/
    $Klein->respond('POST', '/api/v1/catalog', [ new CatalogController(), 'createNewCatalog' ]);
    $Klein->respond(['PATCH', 'PUT'], '/api/v1/catalog/[:id]', [ new CatalogController(),  'updateCatalog']);
    $Klein->respond(['GET', 'HEAD'], '/api/v1/fetch-catalog-by-id/[:id]', [ new CatalogController(), 'fetchCatalogById' ]);
    $Klein->respond(['GET', 'HEAD'], '/api/v1/fetch-catalog-by-name/[:name]', [ new CatalogController(), 'fetchCatalogByName' ]);
    $Klein->respond(['GET', 'HEAD'], '/api/v1/catalogs', [ new CatalogController(), 'fetchCatalogs' ]);
    $Klein->respond('DELETE', '/api/v1/del-catalog/[:id]', [ new CatalogController(), 'deleteCatalog' ]);

    /******************** Product Routes  **********************/
    $Klein->respond('POST', '/api/v1/product', [ new ProductController(), 'createProduct' ]);
    $Klein->respond('POST', '/api/v1/product/[:id]', [ new ProductController(), 'updateProduct' ]);
    $Klein->respond('GET', '/api/v1/fetch/[:id]', [ new ProductController(), 'getProductById' ]);
    $Klein->respond('GET', '/api/v1/products', [ new ProductController(), 'fetchProducts' ]);
    $Klein->respond('DELETE', '/api/v1/delete-product/[:id]', [ new ProductController(), 'deleteProduct' ]);

    /******************** Project Routes  **********************/
    $Klein->respond('GET', '/api/v1/projects-access', [ new ProjectController(), 'fetchUserAccess' ]);
    $Klein->respond('GET', '/api/v1/projects', [ new ProjectController(), 'fetchProjects' ]);
    $Klein->respond('GET', '/api/v1/projects/[:projectName]', [ new ProjectController(), 'fetchProjectsByProjectName' ]);
    $Klein->respond('GET', '/api/v1/projects/[:projectName]/[:wing]', [ new ProjectController(), 'fetchProjectsByProjectNameAndWing' ]);
    $Klein->respond('GET', '/api/v1/projects/[:projectName]/[:wing]/[:floorNo]', [ new ProjectController(), 'fetchProjectsByProjectNameAndWingAndFloor' ]);

    $Klein->respond('GET', '/api/v1/project/overallSummary', [ new ProjectController(), 'overallSummary' ]);

    $Klein->respond('GET', '/api/v1/project/modifiedLogs', [ new ProjectController(), 'modifiedLogs' ]);
    $Klein->respond('GET', '/api/v1/project/modifiedLogs/[:period]', [ new ProjectController(), 'modifiedLogsByPeriod' ]);
    $Klein->respond('GET', '/api/v1/project/modifiedLogsForProject/[:projectName]', [ new ProjectController(), 'modifiedLogsForProject' ]);

    $Klein->respond('POST', '/api/v1/project/updateStatus', [ new ProjectController(), 'updateStatus' ]);

    $Klein->respond('GET', '/api/v1/project/cleanCache', [ new ProjectController(), 'cleanCache' ]);
    $Klein->respond('GET', '/api/v1/project/cleanCache/[:id]', [ new ProjectController(), 'cleanCacheByKey' ]);

    $Klein->respond('GET', '/api/v1/project/securityRooms', [ new ProjectController(), 'securityRooms' ]);
    $Klein->respond('GET', '/api/v1/project/securityRooms/[:projectName]', [ new ProjectController(), 'securityRoomsForProject' ]);

    $Klein->respond('GET', '/api/v1/project/serverRooms', [ new ProjectController(), 'serverRooms' ]);
    $Klein->respond('GET', '/api/v1/project/serverRooms/[:projectName]', [ new ProjectController(), 'serverRoomsForProject' ]);
    $Klein->respond('GET', '/api/v1/project/serverRoomsLogs', [ new ProjectController(), 'serverRoomsLogs' ]);
    $Klein->respond('GET', '/api/v1/project/serverRoomsLogs/[:period]', [ new ProjectController(), 'serverRoomsLogsByPeriod' ]);
    $Klein->respond('GET', '/api/v1/project/serverRoomsLogsForProject/[:projectName]', [ new ProjectController(), 'serverRoomsLogsForProject' ]);

    $Klein->respond('POST', '/api/v1/project/updateServer', [ new ProjectController(), 'updateServer' ]);

    // Dispatch all routes....
    $Klein->dispatch();
    //echo "Klein dispatch";
?>
