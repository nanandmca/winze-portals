<?php

    namespace App\Utils\Common;

    use App\Utils\Security\SecurityConstants;

    class SessionUtils
    {

        function getAppSession( $appName, $id ) {
            return self::get( $appName . '.' . $id);
        }

        private function get( $id ) {
            if (isset($_SESSION[$id])) {
                return json_decode(unserialize($_SESSION[$id]));
            }else{
                return null;
            }
        }

        function setAppSession( $appName, $id, $obj) {
            self::set( $appName . '.' . $id, $obj);
        }

        private function set( $id, $obj) {
            $_SESSION[$id] = serialize(json_encode($obj));
        }

        function clearAll( $appName, $idList ) {
            $_SESSION = array();
        }

        function removeAppSession( $appName, $id ) {
            self::remove( $appName . '.' . $id);
        }

        private function remove( $id ) {
            if (isset($_SESSION[$id])) {
                unset($_SESSION[$id]);
            }
        }

        function isValidSession( $response ) {
            if(SecurityConstants::$sessionValidation_Required == false){
                return true;
            }
            //echo '<pre> isValidSession : ' . print_r($_SESSION, TRUE) . '</pre>';
            if(self::getAppSession(SecurityConstants::$cacheKey_AppName, "user_access_data") == null){
                $response->code(401)->json([
                    'status' => 401,
                    'message' => 'Sorry, Invalid Session.',
                    'data' => []
                ]);
                return false;
            }
            return true;
        }
    }

