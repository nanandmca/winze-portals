import axios from 'axios';

import {overallSummaryUrl, modifiedLogsUrl, modifiedLogsForProjectUrl, projectsUrl, securityRoomsUrl, updateStatusUrl, serverLogsForProjectUrl, serverLogsUrl, serverUrl, updateServerUrl, projectAccessUrl, cleanCacheUrl} from '../../utils/tracking_system/ApiUrl';
import {populateErrorResponse, populateSuccessResponse, populatePostHeader} from '../common/ServiceUtils';

let serviceErrorCode = "SERVICE_ERROR";
let serviceCallError = "Error in service call.";

export const overallSummary = function (userAuthData, successCallBack, failureCallBack, portalDispatch){
    return axios.get(overallSummaryUrl, {headers : populatePostHeader(userAuthData.headers, true)})
                    .then((response) => response.data)
                    .then((responseJson) => {
                        successCallBack(populateSuccessResponse(responseJson));
                    })
                    .catch((errorData) => {
                        console.error(errorData);
                        failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError, portalDispatch));
                    });
}

export const modifiedLogs = function (period, userAuthData, successCallBack, failureCallBack, portalDispatch){
    let modifiedLogsUrlSuffix = "";
    if(period != null){
        modifiedLogsUrlSuffix = "/" + period;
    }
    console.log("modifiedLogs portalDispatch " + portalDispatch);
    return axios.get(modifiedLogsUrl + modifiedLogsUrlSuffix, { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            successCallBack(populateSuccessResponse(responseJson));
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError, portalDispatch));
        });
}

export const modifiedLogsForProject = function (userAuthData, successCallBack, failureCallBack, portalDispatch, projectName){
    let modifiedLogsUrlSuffix = "";
    if(projectName != null){
        modifiedLogsUrlSuffix = "/" + projectName;
    }
    console.log('modifiedLogsForProjectUrl -->  ' + modifiedLogsForProjectUrl + modifiedLogsUrlSuffix)
    return axios.get(modifiedLogsForProjectUrl + modifiedLogsUrlSuffix, { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            successCallBack(populateSuccessResponse(responseJson), projectName);
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError, portalDispatch));
        });
}

export const projectDetails = function (userAuthData, successCallBack, failureCallBack, portalDispatch, projectName, wing, floor){
    let projectDetailsURLSuffix = "";
    if(projectName != null){
        projectDetailsURLSuffix = "/" + projectName;
    }
    if(wing != null){
        projectDetailsURLSuffix += "/" + wing;
    }
    if(floor != null){
        projectDetailsURLSuffix += "/" + floor;
    }
    console.log("projectDetails -> projectName : " + projectName);
    console.log("projectDetails -> wing : " + wing);
    console.log("projectDetails -> URL : " + projectsUrl + projectDetailsURLSuffix);
    return axios.get(projectsUrl + projectDetailsURLSuffix, { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            console.log("successCallBack " + projectName)
            successCallBack(populateSuccessResponse(responseJson), projectName, wing, floor);
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError, portalDispatch));
        });
}

export const securityRoomDetails = function (userAuthData, successCallBack, failureCallBack, portalDispatch, projectName){
    let modifiedSecurityRoomDetailsSuffix = "";
    if(projectName != null){
        modifiedSecurityRoomDetailsSuffix = "/" + projectName;
    }
    return axios.get(securityRoomsUrl + modifiedSecurityRoomDetailsSuffix, { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            successCallBack(populateSuccessResponse(responseJson), projectName);
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError, portalDispatch));
        });
}

export const updateStatus = function (userAuthData, successCallBack, failureCallBack, portalDispatch, previous, current, documentId){
    return axios.post(updateStatusUrl, userAuthData.data, { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            successCallBack(populateSuccessResponse(responseJson), previous, current, documentId);
            cleanCache(userAuthData);
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError, portalDispatch));
        });
}

export const serverDetails = function (userAuthData, successCallBack, failureCallBack, portalDispatch, projectName){
    let serverUrlSuffix = "";
    if(projectName != null){
        serverUrlSuffix = "/" + projectName;
    }
    return axios.get(serverUrl + serverUrlSuffix, { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            console.log("successCallBack " + projectName)
            successCallBack(populateSuccessResponse(responseJson), projectName);
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError, portalDispatch));
        });
}

export const serverLogDetailsForProject = function (userAuthData, successCallBack, failureCallBack, portalDispatch, projectName){
    let serverLogsUrlSuffix = "";
    if(projectName != null){
        serverLogsUrlSuffix = "/" + projectName;
    }
    return axios.get(serverLogsForProjectUrl + serverLogsUrlSuffix, { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            console.log("successCallBack " + projectName)
            successCallBack(populateSuccessResponse(responseJson), projectName);
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError, portalDispatch));
        });
}

export const serverLogDetails = function (period, userAuthData, successCallBack, failureCallBack, portalDispatch, projectName){
    let serverLogsUrlSuffix = "";
    if(period != null){
        serverLogsUrlSuffix = "/" + period;
    }
    return axios.get(serverLogsUrl + serverLogsUrlSuffix, { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            console.log("successCallBack " + projectName)
            successCallBack(populateSuccessResponse(responseJson), projectName);
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError, portalDispatch));
        });
}

export const updateServer = function (userAuthData, successCallBack, failureCallBack, portalDispatch, previous, current, documentId){
    return axios.post(updateServerUrl, userAuthData.data, { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            successCallBack(populateSuccessResponse(responseJson), previous, current, documentId);
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError, portalDispatch));
        });
}

export const projectAccess = function (userAuthData, successCallBack, failureCallBack, portalDispatch){
    return axios.get(projectAccessUrl , { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            console.log("successCallBack ")
            successCallBack(populateSuccessResponse(responseJson));
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError, portalDispatch));
        });
}

export const cleanCache = function (userAuthData){
    return axios.get(cleanCacheUrl, {headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => responseJson)
        .catch((errorData) => errorData);
}