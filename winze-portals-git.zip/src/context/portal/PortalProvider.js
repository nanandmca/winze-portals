import React from 'react'
import {LOGIN, LOGOUT, ADD_LEFT_MENU, UPDATE_TOP_HEADING, INCREMENT_DASHBORD_VIEW_COUNT, UPDATE_LOADING, START_LOADING, STOP_LOADING, SESSION_EXPIRED } from './../../utils/portal/PortalAction';

const PortalStateContext = React.createContext({loading: 0})
const PortalDispatchContext = React.createContext()

function portalReducer(state, action) {
    switch (action.type) {
        case LOGIN: {
            console.log("Inside login");
            return {...state, isLoggedIn: true, apps : action.payload.apps, portalSessionExpired: false}
        }
        case LOGOUT: {
            return {...state, isLoggedIn: false}
        }
        case INCREMENT_DASHBORD_VIEW_COUNT: {
            //console.log("state.dashBoardViewCount " + state.dashBoardViewCount);
            //console.log("(state.dashBoardViewCount === \"undefined\") " + (state.dashBoardViewCount == undefined));
            //console.log("((state.dashBoardViewCount === \"undefined\") ? 0 : state.dashBoardViewCount) " + ((state.dashBoardViewCount == undefined) ? 0 : state.dashBoardViewCount));
            return {...state, dashBoardViewCount: ((state.dashBoardViewCount == undefined) ? 0 : state.dashBoardViewCount) + 1}
        }
        case ADD_LEFT_MENU: {
            return {...state, leftMenuList: action.payload}
        }
        case UPDATE_TOP_HEADING: {
            return {...state, topHeading: action.payload}
        }
        case UPDATE_LOADING: {
            return {...state, loading: action.payload}
        }
        case START_LOADING: {
            console.log("Inside props START_LOADING -> " + state.loading);
            if(state.loading == undefined){
                return {...state, loading: 1}
            }
            return {...state, loading: state.loading + 1}
        }
        case STOP_LOADING: {
            console.log("Inside props STOP_LOADING -> " + state.loading);
            return {...state, loading: state.loading - 1}
        }
        case SESSION_EXPIRED: {
            console.log("portalDispatch Inside props SESSION_EXPIRED -> " + state.portalSessionExpired);
            return {...state, portalSessionExpired: true}
        }
        default: {
            throw new Error(`Unhandled action type: ${action.type}`)
        }
    }
}

function PortalProvider({children}) {
    const [state, dispatch] = React.useReducer(portalReducer, {count: 0})
    return (

        <PortalStateContext.Provider value={state}>
            <PortalDispatchContext.Provider value={dispatch}>
                {children}
            </PortalDispatchContext.Provider>
        </PortalStateContext.Provider>
    )
}

function usePortalState() {
    const context = React.useContext(PortalStateContext)
    if (context === undefined) {
        throw new Error('usePortalState must be used within a PortalProvider')
    }
    return context
}

function usePortalDispatch() {
    const context = React.useContext(PortalDispatchContext)
    if (context === undefined) {
        throw new Error('usePortalDispatch must be used within a PortalProvider')
    }
    return context
}

export {PortalProvider, usePortalState, usePortalDispatch}