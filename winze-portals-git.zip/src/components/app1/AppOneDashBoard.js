import React, {useEffect} from 'react';
import { useAppOneState, useAppOneDispatch } from "../../context/app1/AppOneProvider";
import {INCREMENT} from './../../utils/app1/AppOneAction'
import {Link} from "react-router-dom";

export const AppOneDashBoard = (props) => {
    const {count} = useAppOneState();
    const dispatch = useAppOneDispatch();

    const doIncrement = () => {
        //props.startLoading();
        dispatch({
            type : INCREMENT
        });
    }
    console.log("AppOneDashBoard::props -> " + Object.keys(props));
    //console.log("props -> " + props.startLoading())

    return (
        <div>
            {console.log("Inside AppOneDashBoard")}
            <div className="flex items-center mt-24 mb-10">
                <div className="flex-grow text-right px-4 py-2 m-2">
                    {
                        (count) ?
                            <h6>App One Count : {count}</h6>
                            :
                            <></>
                    }
                    <br/><button onClick={() => doIncrement()} className="bg-green-400 hover:bg-green-500 text-white font-semibold py-2 px-4 rounded inline-flex items-center">
                        <span className="pl-2">Action</span>
                    </button><br/><br/>
                    <Link to={"/"}>Home</Link><br/><br/>
                    <Link to={"/app1/actionlist"}>Action List</Link><br/>
                    <Link to={"/app1/actionlist1"}>Action List One</Link><br/><br/>
                </div>
            </div>
        </div>
    )
}