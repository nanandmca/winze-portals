let securityDomainUrl = "http://projects.winzetech.com";

try{
    let tempSecurityDomain = eval("window.securityServiceDomain");
    if(tempSecurityDomain != undefined){
        securityDomainUrl = tempSecurityDomain;
    }
}catch (err){
    console.log("Error while retrieve domain URL");
}

export const userAuthUrl = securityDomainUrl + "/api/v1/user-auth";
export const keepAliveUrl = securityDomainUrl + "/api/v1/keepAlive";
export const changePasswordUrl = securityDomainUrl + "/api/v1change-password";
export const clearSessionUrl = securityDomainUrl + "/api/v1/clear-session";
