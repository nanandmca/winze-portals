import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import {getFailureResponseData, getSuccessResponseData, isValidServiceResponse} from "../../service/common/ServiceUtils";
import {modifiedLogs, serverLogDetails} from "../../service/tracking_system/ApiService";
import {START_LOADING, STOP_LOADING} from "../../utils/portal/PortalAction";
import {usePortalDispatch} from "../../context/portal/PortalProvider";
import {populatedChangeLog} from './../../utils/tracking_system/TrackingSystemUtils';
import {
    getAuditLogForDashBoard,
    getServerAuditLogForDashBoard,
    setAuditLogForDashBoard, setServerAuditLogForDashBoard
} from "../../utils/tracking_system/TrackingSystemCache";


function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box p={3}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper,
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    },
}));

export const ProjectLogs = (props) => {
    const classes = useStyles();
    const [value, setValue] = React.useState(0);
    const portalDispatch = usePortalDispatch();
    const [todaysLogs, setTodaysLogs] = useState([]);
    const [yesterdaysLogs, setYesterdaysLogs] = useState([]);
    const [yesterdayAuditLogsServiceInProgress, setYesterdayAuditLogsServiceInProgress] = useState(false);
    const [todayAuditLogsServiceInProgress, setTodayAuditLogsServiceInProgress] = useState(false);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    const loadYesterdayAuditLogData = function(auditLogData){
        setYesterdaysLogs(auditLogData);
    }

    const loadTodayAuditLogData = function(auditLogData){
        setTodaysLogs(auditLogData);
    }

    const yesterdayAuditLogsServiceSuccess = function(successResponse){
        console.log('yesterdayAuditLogsServiceSuccess : ' + JSON.stringify(successResponse));
        if(isValidServiceResponse(successResponse)){
            let yesterdayAuditLogsResponse = getSuccessResponseData(successResponse);
            console.log('yesterdayAuditLogsResponse : ' + JSON.stringify(yesterdayAuditLogsResponse));
            if(props.logsType == "R"){
                setAuditLogForDashBoard(props.company.company_id, "Yesterday", yesterdayAuditLogsResponse.data);
            }else if(props.logsType == "S"){
                setServerAuditLogForDashBoard(props.company.company_id, "Yesterday", yesterdayAuditLogsResponse.data);
            }
            loadYesterdayAuditLogData(yesterdayAuditLogsResponse.data);
        }
        setYesterdayAuditLogsServiceInProgress(false);
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const yesterdayAuditLogsServiceFailure = function(failureResponse){
        console.log('yesterdayAuditLogsServiceFailure : ' + JSON.stringify(failureResponse));
        let failureData = getFailureResponseData(failureResponse);
        console.log('failureData : ' + JSON.stringify(failureData));
        setYesterdayAuditLogsServiceInProgress(false);
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const todayAuditLogsServiceSuccess = function(successResponse){
        console.log('todayAuditLogsServiceSuccess : ' + JSON.stringify(successResponse));
        if(isValidServiceResponse(successResponse)){
            let todayAuditLogsResponse = getSuccessResponseData(successResponse);
            console.log('todayAuditLogsResponse : ' + JSON.stringify(todayAuditLogsResponse));
            if(props.logsType == "R"){
                setAuditLogForDashBoard(props.company.company_id, "Today", todayAuditLogsResponse.data);
            }else if(props.logsType == "S"){
                setServerAuditLogForDashBoard(props.company.company_id, "Today", todayAuditLogsResponse.data);
            }
            loadTodayAuditLogData(todayAuditLogsResponse.data);
        }
        setTodayAuditLogsServiceInProgress(false);
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const todayAuditLogsServiceFailure = function(failureResponse){
        console.log('todayAuditLogsServiceFailure : ' + JSON.stringify(failureResponse));
        let failureData = getFailureResponseData(failureResponse);
        console.log('failureData : ' + JSON.stringify(failureData));
        setTodayAuditLogsServiceInProgress(false);
        portalDispatch({
            type: STOP_LOADING
        })
    }

    //getAuditLogForDashBoard
    useEffect(() => {
        let auditLogYesterdayData;
        let auditLogTodayData;
        if(props.logsType == "R"){
            auditLogYesterdayData = getAuditLogForDashBoard(props.company.company_id, "Yesterday");
            auditLogTodayData = getAuditLogForDashBoard(props.company.company_id, "Today");
        }else if(props.logsType == "S"){
            auditLogYesterdayData = getServerAuditLogForDashBoard(props.company.company_id, "Yesterday");
            auditLogTodayData = getServerAuditLogForDashBoard(props.company.company_id, "Today");
        }
        if(auditLogYesterdayData){
            loadYesterdayAuditLogData(auditLogYesterdayData);
        }else{
            if(!yesterdayAuditLogsServiceInProgress) {
                portalDispatch({
                    type: START_LOADING
                })
                setYesterdayAuditLogsServiceInProgress(true);
                if(props.logsType == "R"){
                    modifiedLogs("Yesterday", {headers:{companyId : props.company.company_id}}, yesterdayAuditLogsServiceSuccess, yesterdayAuditLogsServiceFailure, portalDispatch);
                }else if(props.logsType == "S"){
                    serverLogDetails("Yesterday", {headers:{companyId : props.company.company_id}}, yesterdayAuditLogsServiceSuccess, yesterdayAuditLogsServiceFailure, portalDispatch);
                }
            }
        }
        if(auditLogTodayData){
            loadTodayAuditLogData(auditLogTodayData);
        }else{
            if(!todayAuditLogsServiceInProgress) {
                portalDispatch({
                    type: START_LOADING
                })
                setTodayAuditLogsServiceInProgress(true);
                if(props.logsType == "R"){
                    modifiedLogs("Today", {headers:{companyId : props.company.company_id}}, todayAuditLogsServiceSuccess, todayAuditLogsServiceFailure, portalDispatch);
                }else if(props.logsType == "S"){
                    serverLogDetails("Today", {headers:{companyId : props.company.company_id}}, todayAuditLogsServiceSuccess, todayAuditLogsServiceFailure, portalDispatch);
                }
            }
        }
    }, []);

    return (
        <div className={classes.root}>
            <br/>
            <Typography variant='h6' style={{fontWeight: 'bold', padding: '5px 0 5px 0'}}>{"R" == props.logsType ? "Audit Logs" : ("S" == props.logsType ? "Server Audit Logs" : "")}</Typography>
            <AppBar position="static">
                <Tabs value={value} onChange={handleChange} aria-label="simple tabs example">
                    <Tab label="Today" {...a11yProps(0)} />
                    <Tab label="Yesterday" {...a11yProps(1)} />
                </Tabs>
            </AppBar>
            <TabPanel value={value} index={0}>
                {
                    (todaysLogs && todaysLogs.length > 0)
                        ?
                            todaysLogs.map((log, i) => {
                                console.log("Today : " + JSON.stringify(log));
                                return (
                                    <Grid container spacing={3}>
                                        <Grid item xs={6}>
                                            <p>{log.modifiedDate} - {log.time} - {log.projectName} - Floor: {log.floorNo} - Room Number: {log.roomNo}</p>
                                        </Grid>
                                        <Grid item xs={6}>
                                            {log.changesMade.map(log => (
                                                <p>{populatedChangeLog(log)}</p>
                                            ))
                                            }
                                        </Grid>
                                    </Grid>
                                )
                            })
                        :
                            <p>Todays Logs Not Found</p>
                }
            </TabPanel>
            <TabPanel value={value} index={1}>
                {
                    (yesterdaysLogs && yesterdaysLogs.length > 0)
                        ?
                            yesterdaysLogs.map((log, i) => {
                                return (
                                    <Grid container spacing={3}>
                                        <Grid item xs={6}>
                                            <p>{log.modifiedDate} - {log.time} - {log.projectName} - Floor: {log.floorNo} - Room Number: {log.roomNo}</p>
                                        </Grid>
                                        <Grid item xs={6}>
                                            {log.changesMade.map(log => (
                                                <p>{populatedChangeLog(log)}</p>
                                            ))
                                            }
                                        </Grid>
                                    </Grid>
                                )
                            })
                        :
                            <p>Yesterdays Logs Not Found</p>
                }
            </TabPanel>
        </div>
    )
}