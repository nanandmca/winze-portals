import axios from 'axios';

import {userAuthUrl, clearSessionUrl, keepAliveUrl} from '../../utils/security/ApiUrl';
import {populateErrorResponse, populateSuccessResponse, populatePostHeader} from '../common/ServiceUtils';

let serviceErrorCode = "SERVICE_ERROR";
let serviceCallError = "Error in service call.";

//withCredentials: true,
export const aunthenticateUser = function (userAuthData, successCallBack, failureCallBack){
    return axios.post(userAuthUrl, userAuthData.data, {headers : populatePostHeader(userAuthData.headers, false)})
                    .then((response) => response.data)
                    .then((responseJson) => {
                        successCallBack(populateSuccessResponse(responseJson));
                    })
                    .catch((errorData) => {
                        console.error(errorData);
                        failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError));
                    });
}

export const clearLoginSession = function (userAuthData, successCallBack, failureCallBack){
    return axios.post(clearSessionUrl, userAuthData.data, { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            successCallBack(populateSuccessResponse(responseJson));
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError));
        });
}

export const keepSessionAlive = function (userAuthData, successCallBack, failureCallBack){
    return axios.get(keepAliveUrl, { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            successCallBack(populateSuccessResponse(responseJson));
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError));
        });
}

export const changePassword = function (userAuthData, successCallBack, failureCallBack){
    return axios.post(clearSessionUrl, userAuthData.data, { headers : populatePostHeader(userAuthData.headers, true)})
        .then((response) => response.data)
        .then((responseJson) => {
            successCallBack(populateSuccessResponse(responseJson));
        })
        .catch((errorData) => {
            console.error(errorData);
            failureCallBack(populateErrorResponse(errorData, serviceErrorCode, serviceCallError));
        });
}





