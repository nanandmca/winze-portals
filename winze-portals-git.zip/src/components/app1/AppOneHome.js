import React, { useEffect } from 'react';
import {AppOneDashBoard} from "./AppOneDashBoard";
import {Route, Switch} from "react-router-dom";
import {AppOneActionList} from "./AppOneActionList";
import {NoRouteFound} from "../security/NoRouteFound";
import {ADD_LEFT_MENU, UPDATE_TOP_HEADING} from "../../utils/portal/PortalAction";
import {usePortalDispatch, usePortalState} from "../../context/portal/PortalProvider";

export const AppOneHome = (props) => {
    const {leftMenuList} = usePortalState();
    const portalDispatch = usePortalDispatch();

    useEffect(() => {
        console.log("useEffect -> " + leftMenuList)
        console.log("AppOneHome::props -> " + Object.keys(props));
        //console.log("props -> " + props.startLoading())
        if(!leftMenuList){
            portalDispatch({
                type: ADD_LEFT_MENU,
                payload: [
                    {key: "Dashboard", componentGroup: "a", link: "/app1", icon: "home", divider: true},
                    {key: "ActionList", componentGroup: "a", link: "/app1/actionList", icon: "biz"}
                ]
            })
        }
        portalDispatch({
            type: UPDATE_TOP_HEADING,
            payload: "Application One"
        })
    }, []);

    return (
        <div>
            {console.log("Inside AppOneHome")}
            <div className="flex items-center mt-24 mb-10">
                <div className="flex-grow text-left px-4 py-2 m-2">
                    <h5 className="text-gray-900 font-bold text-xl">App One Home Heading</h5>
                </div>
                <Switch>
                    <Route path="/app1" component={AppOneDashBoard} exact/>
                    <Route path="/app1/actionList" component={AppOneActionList} exact/>
                    <Route component={NoRouteFound} />
                </Switch>
            </div>
        </div>
    )
}