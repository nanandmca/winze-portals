import React, {useEffect} from 'react';
import { usePortalState , usePortalDispatch } from './../../context/portal/PortalProvider';
import { Card } from 'semantic-ui-react'
import {Redirect, useHistory} from "react-router-dom";
import { ADD_LEFT_MENU, UPDATE_TOP_HEADING, INCREMENT_DASHBORD_VIEW_COUNT } from "../../utils/portal/PortalAction";

export const PortalAppDashboard = () => {
    const { leftMenuList, dashBoardViewCount, apps} = usePortalState();
    const portalDispatch = usePortalDispatch();
    const history = useHistory();

    useEffect(() => {
        portalDispatch({
            type: ADD_LEFT_MENU,
            payload: null
        })
        portalDispatch({
            type: UPDATE_TOP_HEADING,
            payload: "Winze Portals"
        })
        portalDispatch({
            type: INCREMENT_DASHBORD_VIEW_COUNT
        })
    }, []);

    const doRedirect = (appRoute) => {
        history.push(appRoute);
    }

    let cardList = (apps && apps.length > 0) ? apps.map(function(appRoute){
        return <Card><Card.Content onClick={() => doRedirect(appRoute.route)}>
                                <Card.Header>{appRoute.header}</Card.Header>
                                <Card.Meta>{appRoute.name}</Card.Meta>
                                <Card.Description>
                                    {appRoute.description}
                                </Card.Description>
                            </Card.Content>
                </Card>;
                }) : <></>

    return (
        <>
            {console.log("Inside PortalAppDashboard dashBoardViewCount " + dashBoardViewCount)}
            {
                (apps && (apps.length > 1 || (apps.length == 1 && dashBoardViewCount > 0)) ) ?
                    <>
                        <br/><br/><br/><br/><br/><br/>
                        <Card.Group centered>
                            {cardList}
                        </Card.Group>
                     </>
                :
                    (apps && apps.length == 1) ?
                        <><Redirect to={apps[0].route} /></>
                    :
                        <><h1>No Apps</h1></>
            }
        </>
    )
}