import React, {Fragment, useState} from 'react';

import { withStyles, makeStyles, useTheme } from '@material-ui/core/styles';
import Container from "@material-ui/core/Container";
import PropTypes from 'prop-types';

import { PortalHeader } from './PortalHeader';
import { PortalFooter } from './PortalFooter';
import { usePortalState } from './../../context/portal/PortalProvider';
import { Login } from '../security/Login';
import {PortalAppDashboard} from './PortalAppDashboard';
import {Route, Switch, useHistory} from "react-router-dom";
import {AppOneHome} from "../app1/AppOneHome";
import {AppTwoHome} from "../app2/AppTwoHome";
import {TrackingSystemHome} from "../tracking_system/TrackingSystemHome";
import {NoRouteFound} from "../security/NoRouteFound";
import { AppOneProvider } from "../../context/app1/AppOneProvider";
import { AppTwoProvider } from "../../context/app2/AppTwoProvider";
import { TrackingSystemProvider } from "../../context/tracking_system/TrackingSystemProvider";
import {PortalLeftNav} from "./PortalLeftNav";
import {Backdrop, CircularProgress} from "@material-ui/core";
import {Button, Icon, Modal} from "semantic-ui-react";

const useStyles = makeStyles((theme) => ({
    content: {
        flexGrow: 1,
        padding: theme.spacing(3),
        "margin-top": "75px",
        "margin-left": "10px"
    },
    backdrop: {
        zIndex: theme.zIndex.drawer + 1,
        color: '#fff',
    }
}));

export const PortalHome = (props) => {
    const { window } = props;
    const classes = useStyles();
    const theme = useTheme();
    const {loading, isLoggedIn, apps, portalSessionExpired} = usePortalState();
    const [sessionExpired, setSessionExpired] = useState(portalSessionExpired);
    const history = useHistory();

    console.log("portalDispatch portalSessionExpired" + portalSessionExpired);

    function isRouteApplicable(appName) {
        let filterdApps = apps.filter((appRoute) => appRoute.name == appName);
        //console.log(appName + " -> " + JSON.stringify(filterdApps));
        return filterdApps && filterdApps.length > 0;
    }

    const loadAppOneRoutes = (routes) => {
        if(isRouteApplicable("app1")){
            routes.push(<Route key={"app1"} path="/app1" component={AppOneHome} exact />)
            routes.push(<Route key={"app1Wild"} path="/app1/*" component={AppOneHome} exact />);
        }
    }

    const loadAppTwoRoutes = (routes) => {
        if(isRouteApplicable("app2")){
            routes.push(<Route key={"app2"} path="/app2" component={AppTwoHome} exact />)
            routes.push(<Route key={"app2Wild"} path="/app2/*" component={AppTwoHome} exact />);
        }
    }

    const loadTrackingSystemRoutes = (routes) => {
        if(isRouteApplicable("pts")){
            routes.push(<Route key={"pts"} path="/pts" component={TrackingSystemHome} exact />)
            routes.push(<Route key={"ptsWild"} path="/pts/*" component={TrackingSystemHome} exact />);
        }
    }

    const getRoutes = () => {
        let routes =[];
        loadAppOneRoutes(routes);
        loadAppTwoRoutes(routes)
        loadTrackingSystemRoutes(routes)
        return routes;
    };


    return (
        <AppOneProvider>
            <AppTwoProvider>
                <TrackingSystemProvider>
                    {console.log("Inside PortalHome Route ")}
                    {
                        (isLoggedIn) ?
                                <div className="App">
                                    <div className="container mx-auto">
                                        <Modal
                                            size={"mini"}
                                            open={portalSessionExpired}
                                            onClose={() => setSessionExpired(false)}
                                            onOpen={() => setSessionExpired(true)}
                                            closeOnEscape={false}
                                            closeOnDimmerClick={false}
                                        >
                                            <Modal.Header>
                                                Session Expired
                                            </Modal.Header>
                                            <Modal.Content scrolling>
                                                <Modal.Description>
                                                    Session Expired, Please login again.
                                                </Modal.Description>
                                            </Modal.Content>
                                            <Modal.Actions>
                                                <Button onClick={() => history.push("/logout")}  color={"red"}>
                                                    Ok
                                                </Button>
                                            </Modal.Actions>
                                        </Modal>
                                        <PortalHeader />
                                        <PortalLeftNav />
                                        <main className={classes.content}>
                                            <Container maxWidth="lg">

                                                {/**<h4>Bread Crumb</h4>**/}

                                                <Switch>
                                                    <Route path="/" component={PortalAppDashboard} exact />
                                                    {getRoutes()}
                                                    <Route component={NoRouteFound} />
                                                </Switch>

                                                <Backdrop className={classes.backdrop} open={loading > 0}>
                                                    <CircularProgress color="inherit" />
                                                </Backdrop>

                                            </Container>

                                        </main>
                                        <PortalFooter />
                                    </div>
                                </div>
                            :
                                <Login/>
                    }
                </TrackingSystemProvider>
            </AppTwoProvider>
        </AppOneProvider>
    )
}

PortalHome.propTypes = {
    /**
     * Injected by the documentation to work in an iframe.
     * You won't need it on your project.
     */
    window: PropTypes.func,
};