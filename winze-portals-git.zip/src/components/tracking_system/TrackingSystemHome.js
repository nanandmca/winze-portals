import React, {useEffect} from 'react';
import {TrackingSystemDashBoard} from "./TrackingSystemDashBoard";
import {usePortalDispatch, usePortalState} from "../../context/portal/PortalProvider";
import {
    ADD_LEFT_MENU,
    LOGIN,
    START_LOADING,
    STOP_LOADING,
    UPDATE_LOADING,
    UPDATE_TOP_HEADING
} from "../../utils/portal/PortalAction";
import {Route, Switch} from "react-router-dom";
import {NoRouteFound} from "../security/NoRouteFound";
import {projectAccess} from "../../service/tracking_system/ApiService";
import {
    getFailureResponseData,
    getSuccessResponseData,
    isValidServiceResponse
} from "../../service/common/ServiceUtils";
import {getProjectAccess, setProjectAccess} from "../../utils/tracking_system/TrackingSystemCache";
import {ProjectStatus} from "./ProjectStatus";
import {WingStatus} from "./WingStatus";

export const TrackingSystemHome = () => {

    const {leftMenuList} = usePortalState();
    const portalDispatch = usePortalDispatch();

    const loadProjectRoutes = (routes) => {
        routes.push(<Route key={"project"} path="/pts/project" component={ProjectStatus} exact />)
    }

    const loadWingRoutes = (routes) => {
        routes.push(<Route key={"project"} path="/pts/wing" component={WingStatus} exact />)
    }

    const getRoutes = () => {
        let routes =[];
        loadProjectRoutes(routes);
        loadWingRoutes(routes)
        return routes;
    };

    const loadLeftMenu = function(leftMenuData){
        console.log("loadLeftMenu -> " + JSON.stringify(leftMenuData))
        if(leftMenuData["service_company_user"] == "N"){
            console.log("loadLeftMenu -> service-company-user -> N")
        }
        let company_list = leftMenuData["company_list"];
        console.log("loadLeftMenu -> company_list -> " + company_list)
        let menuPayload = [];
        let subHeadingRequired = false;
        if(company_list.length > 1){
            subHeadingRequired = true;
        }
        menuPayload.push({key: "Dashboard", componentGroup: "a", link: "/pts", icon: "home", divider : true });
        if(leftMenuData.project_access_data){
            leftMenuData.project_access_data.map(function(menuData){
                    if(menuData.projects){
                        let companyRow = {subHeadingRequired: subHeadingRequired, key: menuData.company_name, componentGroup: menuData.company_id, subHeading: menuData.company_name, divider : true};
                        let projectMenu = [];
                        let collapsable = false;
                        if(menuData.menuType == "W"){
                            collapsable = true;
                        }

                        menuData.projects.map(function(project){
                            let projectRow = {collapsable: collapsable, key: project.projectName, componentGroup: project.projectName, icon: "biz", params : {requestType: "P", companyName: menuData.company_name, companyId: menuData.company_id, projectName: project.projectName}};
                            if(collapsable){
                                if(project.wings){
                                    let wingMenu = [];
                                        project.wings.map(function(wing){
                                        wingMenu.push({key: menuData.wingNamePrefix + wing, componentGroup:project.projectName, link: "/pts/project", icon: "star", params : {requestType: "W", companyName: menuData.company_name, companyId: menuData.company_id, projectName: project.projectName, wing: wing, wingNamePrefix: menuData.wingNamePrefix}});
                                    })
                                    projectRow["menu_list"] = wingMenu;
                                }
                            }else{
                                projectRow["link"] = "/pts/project";
                            }
                            projectMenu.push(projectRow);
                            if(collapsable && menuData.projects.length == 1){
                                projectMenu = projectRow["menu_list"];
                            }
                        })
                        companyRow["menu_list"] = projectMenu;
                        menuPayload.push(companyRow);
                    }
            })
        }
        console.log("loadLeftMenu -> menuPayload -> " + JSON.stringify(menuPayload))
        //menuPayload.push({key: "Project One Upd", componentGroup: "a", link: "/pts/project", icon: "biz", params : {projectId: 1}});
        //menuPayload.push({key: "Project Two Upd", componentGroup: "a", link: "/pts/project", icon: "biz", params : {projectId: 2}});
        portalDispatch({
            type: ADD_LEFT_MENU,
            payload: menuPayload
        })
    }

    const projectAccessServiceSuccess = function(successResponse){
        console.log('projectAccessServiceSuccess : ' + JSON.stringify(successResponse));
        if(isValidServiceResponse(successResponse)){
            let projectAccessResponse = getSuccessResponseData(successResponse);
            console.log('storeUserAuthData : ' + JSON.stringify(projectAccessResponse));
            setProjectAccess(projectAccessResponse.data);
            loadLeftMenu(projectAccessResponse.data);
        }
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const projectAccessServiceFailure = function(failureResponse){
        console.log('projectAccessServiceFailure : ' + JSON.stringify(failureResponse));
        let failureData = getFailureResponseData(failureResponse);
        console.log('failureData : ' + JSON.stringify(failureData));
        portalDispatch({
            type: STOP_LOADING
        })
    }

    useEffect(() => {
        console.log("useEffect -> " + leftMenuList)
        if(!leftMenuList){
            if(getProjectAccess()){
                console.log("getProjectAccess -> EXISTS");
                loadLeftMenu(getProjectAccess());
            }else{
                portalDispatch({
                    type: START_LOADING
                })
                projectAccess({}, projectAccessServiceSuccess, projectAccessServiceFailure, portalDispatch);
            }
        }
        portalDispatch({
            type: UPDATE_TOP_HEADING,
            payload: "Project Tracking System"
        })
    }, []);

    return (
        <div>
            <div className="flex items-center mt-24 mb-10">
                {/**<div className="flex-grow text-left px-4 py-2 m-2">
                    <h5 className="text-gray-900 font-bold text-xl">Tracking System Home</h5>
                </div>**/}
                <Switch>
                    <Route path="/pts" component={TrackingSystemDashBoard} exact/>
                    {getRoutes()}
                    <Route component={NoRouteFound} />
                </Switch>
            </div>
        </div>
    )
}