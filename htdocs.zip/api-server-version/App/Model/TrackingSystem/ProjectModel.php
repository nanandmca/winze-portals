<?php

    namespace App\Model\TrackingSystem;

    use App\Model\TrackingSystem\TrackingSystemModel;
    use App\Utils\Common\AppConstants;
    use App\Utils\TrackingSystem\OverallStatusFilter;
    use App\Utils\TrackingSystem\DataFilter;
    use App\Utils\TrackingSystem\RoomModifiedLogDataFilter;
    use App\Utils\TrackingSystem\TrackingSystemConstants;
    use Google\Cloud\Firestore\FieldValue;

/**
     * ProductModel - This Model is consumed basically by the ProductController and is also consumed by other controllers...
     *
     * @author      Ilori Stephen A <stephenilori458@gmail.com>
     * @link        https://github.com/learningdollars/php-rest-api/App/Model/ProductModel.php
     * @license     MIT
     */
    class ProjectModel extends TrackingSystemModel {

        public function isFireStoreDB(){
            return (getenv("FIRESTORE_DB_FLAG") !== false && getenv("FIRESTORE_DB_FLAG") == "Y");
        }

        public function getAlternateFieldList(){
            $alternateFieldNames = [];
            if(isset(TrackingSystemConstants::$templateForCompany[$this->getCompanyId()])
                && isset(TrackingSystemConstants::$templateForCompany[$this->getCompanyId()]["alternateFieldNames"])){
                $alternateFieldNames = TrackingSystemConstants::$templateForCompany[$this->getCompanyId()]["alternateFieldNames"];
            }
            return $alternateFieldNames;
        }

        /**
         * fetchProducts
         *
         * fetches a all of projects..
         *
         * @param void
         * @return array Anonymous
         */
        public function fetchProjects()
        {
            if($this->isFireStoreDB()){
                //echo "getRoomsCollectionName -> " . Parent::getRoomsCollectionName();
                $alternateFieldNames = $this->getAlternateFieldList();
                //echo "alternateFieldNames -> " . json_encode($alternateFieldNames);
                if(!Parent::getFirestoreDB()){
                    return array(
                        'status' => false,
                        'code' => "400",
                        'message' => "No Connection Found",
                        'data' => []
                    );
                }
                $rooms = Parent::getFirestoreDB()->collection(Parent::getRoomsCollectionName());
                $docs = $rooms->documents();
                $data = array();
                foreach ($docs as $document) {
                    $documentWithID = $document->data();
                    $documentWithID["id"] = $document->id();
                    foreach ($alternateFieldNames as $currentFieldName => $newFieldName){
                        if(isset($document[$currentFieldName])){
                            $documentWithID[$newFieldName] = $document[$currentFieldName];
                        }
                    }
                    $data[] = $documentWithID;
                }
                return array(
                    'status' => true,
                    'data' => $data
                );
            }else{
                /*$Sql = "SELECT * FROM `db_products`";
                Parent::query($Sql);
                $products = Parent::fetchAll();
                if (!empty($products)) {
                    return array(
                        'status' => true,
                        'data' => $products
                    );
                }*/

                return array(
                    'status' => false,
                    'code' => 502,
                    'message' => 'Error : No Implemention in place.',
                    'data' => []
                );
            }

        }

        private function populateChangeLogServerData($documentRecord, $tokenData)
        {
            //echo "tokenData -> " . json_encode($tokenData);
            $changeLogDataArr = [
                'projectName' => $documentRecord[0]->projectName,
                'modifiedBy' => isset($tokenData['email']) ? $tokenData['email'] : "System",
                'modifiedDate' => date('d/m/Y'),
                'timestamp' => FieldValue::serverTimestamp()
                //'timestamp' => new Timestamp(new DateTime())
            ];
            return $changeLogDataArr;
        }

        private function populateChangeLogData($documentRecord, $tokenData)
        {
            //echo "tokenData -> " . json_encode($tokenData);
            $alternateFieldNames = $this->getAlternateFieldList();
            $changeLogDataArr = [
                'projectName' => $documentRecord[0]->projectName,
                'wing' => $documentRecord[0]->wing,
                'floorNo' => $documentRecord[0]->floorNo,
                'roomNo' => $documentRecord[0]->roomNo,
                'modifiedBy' => isset($tokenData['email']) ? $tokenData['email'] : "System",
                'modifiedDate' => date('d/m/Y'),
                'timestamp' => FieldValue::serverTimestamp()
                //'timestamp' => new Timestamp(new DateTime())
            ];
            foreach ($alternateFieldNames as $currentFieldName => $newFieldName){
                if(isset($changeLogDataArr[$currentFieldName])){
                    $changeLogDataArr[$currentFieldName] = $changeLogDataArr[$newFieldName];
                    unset($changeLogDataArr[$newFieldName]);
                }
            }
            return $changeLogDataArr;
        }

        /**
         * updateStatus
         *
         * fetches a all of projects..
         *
         * @param void
         * @return array Anonymous
         */
        public function updateStatus($documentId, $modifiedData, $documentRecord, $tokenData)
        {
            if($this->isFireStoreDB()){
                if(!Parent::getFirestoreDB()){
                    return array(
                        'status' => false,
                        'code' => "400",
                        'message' => "No Connection Found",
                        'data' => []
                    );
                }
                $addLogArr = $this->populateChangeLogData($documentRecord, $tokenData);
                $updateArr = [];
                $changesMadeArr = [];
                foreach ($modifiedData as $dataToUpdate){
                    $updateArr[] = array('path' => $dataToUpdate->fieldName, 'value' => $dataToUpdate->fieldValue);
                    $changesMadeArr[] = array('fieldName' => $dataToUpdate->fieldName, 'oldValue' => json_decode(json_encode($documentRecord[0]), true)[$dataToUpdate->fieldName], 'newValue' => $dataToUpdate->fieldValue);
                    //$changesMadeArr[] = $dataToUpdate->fieldName . ': Changed from ' . $documentRecord[0][$dataToUpdate->fieldName] . ' to ' . $dataToUpdate->fieldValue;
                    //$updateArr[] = array('path' => $dataToUpdate->fieldName, 'value' => $dataToUpdate->fieldValue);
                }
                $addLogArr["changesMade"] = $changesMadeArr;
                /*$tmpUpdate = [
                    ['path' => 'age', 'value' => 13],
                    ['path' => 'favorites.color', 'value' => 'Red']
                ];*/
                //echo "addLogArr -> " . json_encode($addLogArr);
                //echo "updateArr -> " . json_encode($updateArr);
                //echo "changesMadeArr -> " . json_encode($changesMadeArr);
                try{
                    if(!Parent::getFirestoreDB()){
                        return array(
                            'status' => false,
                            'code' => "400",
                            'message' => "No Connection Found",
                            'data' => []
                        );
                    }

                    $rooms = Parent::getFirestoreDB()->collection(Parent::getRoomsCollectionName());
                    $rooms->document($documentId)->update($updateArr);

                    $addedLogRef = Parent::getFirestoreDB()->collection(Parent::getRoomModifiedLogCollectionName())->add($addLogArr);
                    //echo "addedLogRef -> " . $addedLogRef->id();
                    return array(
                        'status' => true,
                        'roomLogRef' => $addedLogRef->id(),
                        'data' => []
                    );
                }catch (Exception $e) {
                    echo "Exception -> " . json_encode($e);
                    return array(
                        'status' => false,
                        'data' => []
                    );
                }
            }else{
                /*$Sql = "SELECT * FROM `db_products`";
                Parent::query($Sql);
                $products = Parent::fetchAll();
                if (!empty($products)) {
                    return array(
                        'status' => true,
                        'data' => $products
                    );
                }*/

                return array(
                    'status' => false,
                    'code' => 502,
                    'message' => 'Error : No Implemention in place.',
                    'data' => []
                );
            }

        }

        /**
         * updateServer
         *
         * fetches a all of projects..
         *
         * @param void
         * @return array Anonymous
         */
        public function updateServer($documentId, $modifiedData, $documentRecord, $tokenData)
        {
            if($this->isFireStoreDB()){
                if(!Parent::getFirestoreDB()){
                    return array(
                        'status' => false,
                        'code' => "400",
                        'message' => "No Connection Found",
                        'data' => []
                    );
                }
                //echo "documentRecord -> " . json_encode($documentRecord);
                $addLogArr = $this->populateChangeLogServerData($documentRecord, $tokenData);
                $updateArr = [];
                $changesMadeArr = [];
                foreach ($modifiedData as $dataToUpdate){
                    $updateArr[] = array('path' => $dataToUpdate->fieldName, 'value' => $dataToUpdate->fieldValue);
                    //echo "documentRecord -> " . $dataToUpdate->fieldName;
                    //echo "documentRecord 1 -> " . json_decode(json_encode($documentRecord[0]), true)[$dataToUpdate->fieldName];
                    //echo "documentRecord 2 -> " . $documentRecord[0][$dataToUpdate->fieldName];
                    $changesMadeArr[] = array('fieldName' => $dataToUpdate->fieldName, 'oldValue' => json_decode(json_encode($documentRecord[0]), true)[$dataToUpdate->fieldName], 'newValue' => $dataToUpdate->fieldValue);
                    //$changesMadeArr[] = $dataToUpdate->fieldName . ': Changed from ' . $documentRecord[0][$dataToUpdate->fieldName] . ' to ' . $dataToUpdate->fieldValue;
                    //$updateArr[] = array('path' => $dataToUpdate->fieldName, 'value' => $dataToUpdate->fieldValue);
                }
                $addLogArr["changesMade"] = $changesMadeArr;
                /*$tmpUpdate = [
                    ['path' => 'age', 'value' => 13],
                    ['path' => 'favorites.color', 'value' => 'Red']
                ];*/
                //echo "addLogArr -> " . json_encode($addLogArr);
                //echo "updateArr -> " . json_encode($updateArr);
                //echo "changesMadeArr -> " . json_encode($changesMadeArr);
                try{
                    $rooms = Parent::getFirestoreDB()->collection(Parent::getServerCollectionName());
                    $rooms->document($documentId)->update($updateArr);

                    $addedLogRef = Parent::getFirestoreDB()->collection(Parent::getServerLogsCollectionName())->add($addLogArr);
                    //echo "addedLogRef -> " . $addedLogRef->id();
                    return array(
                        'status' => true,
                        'roomLogRef' => $addedLogRef->id(),
                        'data' => []
                    );
                }catch (Exception $e) {
                    echo "Exception -> " . json_encode($e);
                    return array(
                        'status' => false,
                        'data' => []
                    );
                }
            }else{
                /*$Sql = "SELECT * FROM `db_products`";
                Parent::query($Sql);
                $products = Parent::fetchAll();
                if (!empty($products)) {
                    return array(
                        'status' => true,
                        'data' => $products
                    );
                }*/

                return array(
                    'status' => false,
                    'code' => 502,
                    'message' => 'Error : No Implemention in place.',
                    'data' => []
                );
            }

        }

        /**
         * fetchRoomModifiedLogs
         *
         * fetches a all of projects..
         *
         * @param void
         * @return array Anonymous
         */
        public function fetchRoomModifiedLogs()
        {
            if($this->isFireStoreDB()){
                if(!Parent::getFirestoreDB()){
                    return array(
                        'status' => false,
                        'code' => "400",
                        'message' => "No Connection Found",
                        'data' => []
                    );
                }
                $alternateFieldNames = $this->getAlternateFieldList();
                $rooms = Parent::getFirestoreDB()->collection(Parent::getRoomModifiedLogCollectionName());
                $docs = $rooms->documents();
                $data = array();
                foreach ($docs as $document) {
                    $documentWithID = $document->data();
                    $timestampArr = [];
                    $timestampArr["seconds"] = intval($documentWithID["timestamp"]->get()->format('U'));
                    $timestampArr["nanoseconds"] = $documentWithID["timestamp"]->nanoSeconds();
                    //$documentWithID["time"] = $documentWithID["timestamp"]->get()->format('h:i A');
                    $documentWithID["time"] = date('h:i A', strtotime($documentWithID["timestamp"] . '+6 hours'));
                    $documentWithID["timestamp"] = $timestampArr;
                    $documentWithID["id"] = $document->id();
                    foreach ($alternateFieldNames as $currentFieldName => $newFieldName){
                        if(isset($document[$currentFieldName])){
                            $documentWithID[$newFieldName] = $document[$currentFieldName];
                        }
                    }
                    $data[] = $documentWithID;
                    ///echo '\ndocid : ' . $docid;
                }
                return array(
                    'status' => true,
                    'data' => $data
                );
            }else{
                /*$Sql = "SELECT * FROM `db_products`";
                Parent::query($Sql);
                $products = Parent::fetchAll();
                if (!empty($products)) {
                    return array(
                        'status' => true,
                        'data' => $products
                    );
                }*/

                return array(
                    'status' => false,
                    'code' => 502,
                    'message' => 'Error : No Implemention in place.',
                    'data' => []
                );
            }

        }

        /**
         * fetchSecurityRooms
         *
         * fetches a all of projects..
         *
         * @param void
         * @return array Anonymous
         */
        public function fetchSecurityRooms()
        {
            if($this->isFireStoreDB()){
                if(!Parent::getFirestoreDB()){
                    return array(
                        'status' => false,
                        'code' => "400",
                        'message' => "No Connection Found",
                        'data' => []
                    );
                }
                $rooms = Parent::getFirestoreDB()->collection(Parent::getSecurityRoomsCollectionName());
                $docs = $rooms->documents();
                $data = array();
                foreach ($docs as $document) {
                    $documentWithID = $document->data();
                    //$timestampArr = [];
                    //$timestampArr["seconds"] = intval($documentWithID["timestamp"]->get()->format('U'));
                    //$timestampArr["nanoseconds"] = $documentWithID["timestamp"]->nanoSeconds();
                    //$documentWithID["time"] = $documentWithID["timestamp"]->get()->format('h:i A');
                    //$documentWithID["time"] = date('h:i A', strtotime($documentWithID["timestamp"] . '+6 hours'));
                    //$documentWithID["timestamp"] = $timestampArr;
                    $documentWithID["id"] = $document->id();
                    $data[] = $documentWithID;
                    ///echo '\ndocid : ' . $docid;
                }
                return array(
                    'status' => true,
                    'data' => $data
                );
            }else{
                /*$Sql = "SELECT * FROM `db_products`";
                Parent::query($Sql);
                $products = Parent::fetchAll();
                if (!empty($products)) {
                    return array(
                        'status' => true,
                        'data' => $products
                    );
                }*/

                return array(
                    'status' => false,
                    'code' => 502,
                    'message' => 'Error : No Implemention in place.',
                    'data' => []
                );
            }

        }

        /**
         * fetchServers
         *
         * fetches a all of projects..
         *
         * @param void
         * @return array Anonymous
         */
        public function fetchServers()
        {
            if($this->isFireStoreDB()){
                if(!Parent::getFirestoreDB()){
                    return array(
                        'status' => false,
                        'code' => "400",
                        'message' => "No Connection Found",
                        'data' => []
                    );
                }
                $rooms = Parent::getFirestoreDB()->collection(Parent::getServerCollectionName());
                $docs = $rooms->documents();
                $data = array();
                foreach ($docs as $document) {
                    $documentWithID = $document->data();
                    //$timestampArr = [];
                    //$timestampArr["seconds"] = intval($documentWithID["timestamp"]->get()->format('U'));
                    //$timestampArr["nanoseconds"] = $documentWithID["timestamp"]->nanoSeconds();
                    //$documentWithID["time"] = $documentWithID["timestamp"]->get()->format('h:i A');
                    //$documentWithID["time"] = date('h:i A', strtotime($documentWithID["timestamp"] . '+6 hours'));
                   // $documentWithID["timestamp"] = $timestampArr;
                    $documentWithID["id"] = $document->id();
                    $data[] = $documentWithID;
                    ///echo '\ndocid : ' . $docid;
                }
                return array(
                    'status' => true,
                    'data' => $data
                );
            }else{
                /*$Sql = "SELECT * FROM `db_products`";
                Parent::query($Sql);
                $products = Parent::fetchAll();
                if (!empty($products)) {
                    return array(
                        'status' => true,
                        'data' => $products
                    );
                }*/

                return array(
                    'status' => false,
                    'code' => 502,
                    'message' => 'Error : No Implemention in place.',
                    'data' => []
                );
            }

        }

        /**
         * fetchServers
         *
         * fetches a all of projects..
         *
         * @param void
         * @return array Anonymous
         */
        public function fetchServerLogs()
        {
            if($this->isFireStoreDB()){
                if(!Parent::getFirestoreDB()){
                    return array(
                        'status' => false,
                        'code' => "400",
                        'message' => "No Connection Found",
                        'data' => []
                    );
                }
                $rooms = Parent::getFirestoreDB()->collection(Parent::getServerLogsCollectionName());
                $docs = $rooms->documents();
                $data = array();
                foreach ($docs as $document) {
                    $documentWithID = $document->data();
                    $timestampArr = [];
                    $timestampArr["seconds"] = intval($documentWithID["timestamp"]->get()->format('U'));
                    $timestampArr["nanoseconds"] = $documentWithID["timestamp"]->nanoSeconds();
                    //$documentWithID["time"] = $documentWithID["timestamp"]->get()->format('h:i A');
                    $documentWithID["time"] = date('h:i A', strtotime($documentWithID["timestamp"] . '+6 hours'));
                    $documentWithID["timestamp"] = $timestampArr;
                    $documentWithID["id"] = $document->id();
                    $data[] = $documentWithID;
                    ///echo '\ndocid : ' . $docid;
                }
                return array(
                    'status' => true,
                    'data' => $data
                );
            }else{
                /*$Sql = "SELECT * FROM `db_products`";
                Parent::query($Sql);
                $products = Parent::fetchAll();
                if (!empty($products)) {
                    return array(
                        'status' => true,
                        'data' => $products
                    );
                }*/

                return array(
                    'status' => false,
                    'code' => 502,
                    'message' => 'Error : No Implemention in place.',
                    'data' => []
                );
            }

        }

        public function getCompanyListForServiceUser($user_id)
        {
            $Sql = "SELECT service_users.* FROM db_service_company_mapping service_company, db_service_users service_users WHERE service_users.company_id = service_company.company_id AND service_users.service_company_id = service_company.service_company_id AND service_users.user_id = :user_id AND service_users.active_flag = 'Y'  AND service_company.active_flag = 'Y' AND service_company.service_company_id = :company_id";
            $this->query($Sql);
            // Bind Params...
            $responseData = [];
            $this->bindParams('user_id', $user_id);
            $this->bindParams('company_id', $this->getCompanyId());
            $companyData = $this->fetchAll();
            if (empty($companyData) || count($companyData) == 0) {
                $Response = array(
                    'status' => false,
                    'data' => []
                );
                return $Response;
            }
            $Response = array(
                'status' => true,
                'data' => $companyData
            );
            return $Response;
        }

        public function filterData($data, $filterData){
            //echo "filterData -> " . json_encode($filterData);
            return array_values(array_filter($data, array(new DataFilter($filterData), AppConstants::$filter_getFilteredData)));
        }

        public function filterRoomModifiedLogsData($data, $period){
            //echo "filterData -> " . json_encode($filterData);
            return array_values(array_filter($data, array(new RoomModifiedLogDataFilter($period), TrackingSystemConstants::$filter_getFilteredData)));
        }

        public function populateOverallSummary($data){
            //echo  "\n<BR>array length : " . count($data);
            $projectNameArr = array_column($data, TrackingSystemConstants::$columnName_projectName);
            //echo  "unique array length : " . json_encode($projectNameArr);
            $distinctProjectNames = array_unique($projectNameArr);
            $projectDataArr = array();
            $allCountDataArr = array();
            foreach (TrackingSystemConstants::overallStatusList() as $statusKey) {
                $allCountDataArr[$statusKey] = 0;
            }
            foreach ($distinctProjectNames as $projectName) {
                $overallStatusArr = array();
                $allCount = 0;
                foreach (TrackingSystemConstants::overallStatusList() as $statusKey) {
                    $filtered = array_filter($data, array(new OverallStatusFilter($projectName, $statusKey), TrackingSystemConstants::$filter_getStatusCount));
                    //echo  "\n<BR>projectName: " . $projectName . ",  statusKey" . $statusKey. ", filtered : " .  count($filtered);
                    $overallStatusArr[$statusKey] = count($filtered);
                    $allCountDataArr[$statusKey] = $allCountDataArr[$statusKey] + $overallStatusArr[$statusKey];
                }
                $projectDataArr[$projectName] = $overallStatusArr;
            }
            $projectDataArr[TrackingSystemConstants::$overallStatus_All] = $allCountDataArr;
            return $projectDataArr;
        }

        public function populateOverallSummary_Old($data){
            //echo  "\n<BR>array length : " . count($data);
            $projectNameArr = array_column($data, TrackingSystemConstants::$columnName_projectName);
            //echo  "unique array length : " . json_encode($projectNameArr);
            $distinctProjectNames = array_unique($projectNameArr);
            $overallStatusArr = array();
            foreach (TrackingSystemConstants::overallStatusList() as $statusKey) {
                $projectDataArr = array();
                $allCount = 0;
                foreach ($distinctProjectNames as $projectName) {
                    $filtered = array_filter($data, array(new OverallStatusFilter($projectName, $statusKey), TrackingSystemConstants::$filter_getStatusCount));
                    //echo  "\n<BR>projectName: " . $projectName . ",  statusKey" . $statusKey. ", filtered : " .  count($filtered);
                    $projectDataArr[$projectName] = count($filtered);
                    $allCount = $allCount + $projectDataArr[$projectName];
                }
                $projectDataArr[TrackingSystemConstants::$overallStatus_All] = $allCount;
                $overallStatusArr[$statusKey] = $projectDataArr;
            }
            return $overallStatusArr;
        }

    }
?>
