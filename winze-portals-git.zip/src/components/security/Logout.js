import React, {useEffect, useState} from 'react';
import {Redirect, useHistory} from "react-router-dom";
import {Backdrop, CircularProgress} from '@material-ui/core';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import {makeStyles} from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import {clearLoginSession} from '../../service/security/ApiService';
import {checkLoggedIn} from '../../utils/security/SecurityUtils';
import { LOGOUT} from "../../utils/portal/PortalAction";
import {usePortalDispatch} from "../../context/portal/PortalProvider";

const useStyles = makeStyles((theme) => ({
    paper: {
        marginTop: theme.spacing(40),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        verticalAlign: 'middle',
        height: '200px'
    },
    backdrop: {
        zIndex: theme.zIndex.drawer + 1,
        color: '#fff',
    },
}));

export default function Logout() {
    const classes = useStyles();
    const history = useHistory();
    const dispatch = usePortalDispatch();
    const [isLogin, setIsLoggedIn] = useState(checkLoggedIn());
    const [open, setOpen] = React.useState(false);

    useEffect(() => {
        if(!open){
            clearLoginSession({data:{}}, logoutServiceSuccess, logoutServiceFailure);
        }
        setOpen(true);
    }, []);

    const handleClose = () => {
        setOpen(false);
    };
    const handleToggle = () => {
        setOpen(!open);
    };

    const clearSession = function (successResponse) {
        sessionStorage.clear();
        dispatch({type: LOGOUT});
        setIsLoggedIn(false);
        history.push("/");
    }

    const logoutServiceSuccess = function (successResponse) {
        console.log('logoutServiceSuccess : ' + JSON.stringify(successResponse));
        clearSession();
    }

    const logoutServiceFailure = function (failureResponse) {
        console.log('logoutServiceFailure : ' + JSON.stringify(failureResponse));
        clearSession();
    }

    return (
        (!isLogin) ?
            <Redirect to={{pathname: "/"}}/>
        :
            <Container component="main" maxWidth="xs">
                <CssBaseline/>
                <div className={classes.paper}>
                    <Typography component="h1" variant="h5">
                        Logging out........
                    </Typography>
                </div>
                <Backdrop className={classes.backdrop} open={open}>
                    <CircularProgress color="inherit"/>
                </Backdrop>
            </Container>
    );
}