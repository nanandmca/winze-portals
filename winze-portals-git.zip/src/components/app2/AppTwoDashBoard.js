import React from 'react';
import { useAppTwoState, useAppTwoDispatch } from "../../context/app2/AppTwoProvider";
import {INCREMENT} from './../../utils/app2/AppTwoAction'
import {Link} from "react-router-dom";

export const AppTwoDashBoard = () => {
    const {count} = useAppTwoState();
    const dispatch = useAppTwoDispatch();

    const doIncrement = () => {
        dispatch({
            type : INCREMENT
        });
    }

    return (
        <div>
            {console.log("Inside AppOneDashBoard")}
            <div className="flex items-center mt-24 mb-10">
                <div className="flex-grow text-right px-4 py-2 m-2">
                    {
                        (count) ?
                            <h6>App Two Count : {count}</h6>
                            :
                            <></>
                    }
                    <button onClick={() => doIncrement()} className="bg-green-400 hover:bg-green-500 text-white font-semibold py-2 px-4 rounded inline-flex items-center">
                        <span className="pl-2">Action</span>
                    </button>
                    <Link to={"/"}>Home</Link>
                </div>
            </div>
        </div>
    )
}