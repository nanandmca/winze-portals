<?php

    namespace App;

    use App\Model\Security\UserModel;
    use App\Model\Security\UserAccessModel;
    use App\Model\Samples\CatalogModel;
    use App\Model\Samples\ProductModel;
    use App\Utils\Common\CacheUtils;
    use App\Utils\Common\CommonUtils;
    use App\Utils\Common\SessionUtils;
    use App\Utils\Security\SecurityUtils;
    use App\Utils\Common\TokenUtils;
    use App\Utils\Common\EmailUtils;
    use App\Utils\Common\AppConstants;

    /**
     * Controller - The Base Controller for all other Controllers.... All Other Controllers extends this Controller.
     *
     * @author      Ilori Stephen A <stephenilori458@gmail.com>
     * @link        https://github.com/learningdollars/php-rest-api/App/Controller/Controller.php
     * @license     MIT
     */
    class Controller {

        private $hours = 24;
        private $minutes = 60;
        private $minutes_in_hour = 60;
        public $cacheUtils;
        public $sessionUtils;
        public $securityUtils;
        public $tokenUtils;
        public $emailUtils;
        public $userAccessModel;
        public $commonUtils;
        /**
         * __construct
         *
         * Creates a New Database Connection...
         *
         * @param void
         * @return void
         */
        public function __construct()
        {
            //echo "session_id() " . session_id();
            if(session_id() == ''){
                //echo "session_id() Inside Start : " . session_id();
                session_start();
            }
            //echo "AppConstants::cache_path " . AppConstants::$cache_path;
            $this->cacheUtils = new CacheUtils(dirname(__FILE__). AppConstants::$cache_path, $this->hours * $this->minutes_in_hour * $this->minutes); // 60 = 1 minute
            $this->tokenUtils = new TokenUtils();
            $this->emailUtils = new EmailUtils(dirname(__FILE__) . AppConstants::$email_template_path);
            $this->userAccessModel = new UserAccessModel();
            $this->sessionUtils = new SessionUtils();
            $this->securityUtils = new SecurityUtils();
            $this->commonUtils = new CommonUtils();
        }

        /**
         * validation
         *
         * Validates an array of objects using defined rules...
         *
         * @param array $Payload  Contains an array of Objects that will be validated.
         * @return array $response
         */
        protected function validation($payloads)
        {
            $response = [];
            foreach($payloads as $payload) {
                if ($payload->validator == 'required') {
                    if(isset($payload->datatype) && $payload->datatype == 'array'){
                        if ($payload->data == null || count($payload->data) == 0 || !isset($payload->data)) {
                            array_push($response, [
                                'key' => $payload->key,
                                'message' => "The {$payload->key} field is required"
                            ]);
                        }
                    }else if ($payload->data == null || $payload->data = '' || !isset($payload->data)) {
                        array_push($response, [
                            'key' => $payload->key,
                            'message' => "The {$payload->key} field is required"
                        ]);
                    }
                }

                if ($payload->validator == 'string') {
                    if (preg_match('/[^A-Za-z]/', $payload->data)) {
                        array_push($response, [
                            'key' => $payload->key,
                            'message' => "Sorry {$payload->key} expects an Alphabet."
                        ]);
                    }
                }

                if ($payload->validator == 'numeric') {
                    if (preg_match('/[^0-9_]/', $payload->data)) {
                        array_push($response, [
                            'key' => $payload->key,
                            'message' => "Sorry {$payload->key} expects a Number."
                        ]);
                    }
                }

                if ($payload->validator == 'boolean') {
                    if (strtolower(gettype($payload->data)) !== 'boolean') {
                        array_push($response, [
                            'key' => $payload->key,
                            'message' => "Sorry {$payload->key} expects a Boolean."
                        ]);
                    }
                }

                if (stristr($payload->validator, ':')) {
                    $operationName = explode(':', $payload->validator)[0];
                    $operationChecks = (int) explode(':', $payload->validator)[1];

                    if (strtolower($operationName) == 'min' && $operationChecks > strlen($payload->data)) {
                        array_push($response, [
                            'key' => $payload->key,
                            'message' => "Sorry {$payload->key} is supposed to be less than " . strlen($payload->data)
                        ]);
                    }


                    if (strtolower($operationName) == 'max' && $operationChecks < strlen($payload->data)) {
                        array_push($response, [
                            'key' => $payload->key,
                            'message' => "Sorry {$payload->key} is supposed to be greather than " . strlen($payload->data)
                        ]);
                    }


                    if (strtolower($operationName) == 'between') {
                        $operationChecksTwo = (int) explode(':', $payload->validator)[2];
                        array_push($response, [
                            'key' => $payload->key,
                            'message' => "Sorry {$payload->key} is supposed to be between " . $operationChecks . ' and ' . $operationChecksTwo
                        ]);
                    }

                }

                if ($payload->validator == 'emailExists') {
                    try {
                        $UserModel = new UserModel();
                        $checkEmail = $UserModel->checkEmail($payload->data);

                        if ($checkEmail['status']) {
                            array_push($response, [
                                'key' => $payload->key,
                                'message' => "Sorry {$payload->key} already exists. Please try with a different Email."
                            ]);
                        }
                    } catch (Exception $e) { /** */ }
                }

                if ($payload->validator == 'catalogExists') {
                    try {
                        $CatalogModel = new CatalogModel();
                        $checkCatalog = $CatalogModel::fetchCatalogByID($payload->data);

                        if (!$checkCatalog['status']) {
                            array_push($response, [
                                'key' => $payload->key,
                                'message' => "Sorry, The catalog with this ID could not be found in our database."
                            ]);
                        }
                    } catch (Exception $e) { /** */ }
                }

                if ($payload->validator == 'productExists') {
                    try {
                        $ProductModel = new ProductModel();
                        $checkProduct = $ProductModel::findProductById((int) $payload->data);

                        if (!$checkProduct['status']) {
                            array_push($response, [
                                'key' => $payload->key,
                                'message' => "Sorry, The product with this ID could not be found in our database."
                            ]);
                        }
                    } catch (Exception $e) { /** */ }
                }

                if ($payload->validator == 'img') {
                    try {
                        $files = $payload->data;
                        if ($files) {
                            $fileName = $files['name'];

                            $targetDir = '../../public/img/';
                            $targetFile = $targetDir . basename($files['name']);

                            $fileSize = $files['size'];
                            $fileExtension = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
                            if  (!in_array($fileExtension, $payload->acceptedExtension)) {
                                array_push($response, [
                                    'key' => $payload->key,
                                    'message' => "Sorry, {$payload->key} only accepts the following extensions; " . implode(", ", $payload->acceptedExtension)
                                ]);
                            }

                            if ($fileSize > $payload->maxSize) {
                                array_push($response, [
                                    'key' => $payload->key,
                                    'message' => "Sorry, {$payload->key} File size should be less than " . $payload->maxSize
                                ]);
                            }
                        }
                    } catch (Exception $e) { /** */ }
                }

            }
            //echo "Count : " . count($response);
            if (count($response) < 1) {
                $validationErrors = new \stdClass();
                $validationErrors->status = false;
                $validationErrors->errors = [];

                return $validationErrors;
            }

            $validationErrors = new \stdClass();
            $validationErrors->status = true;
            $validationErrors->errors = $response;
            return $validationErrors;
        }

        /**
         * JWTSecret
         *
         * Returns a JWT Secret....
         *
         * @param void
         * @return string Annonymous
         */
        protected function JWTSecret()
        {
            return 'K-lyniEXe8Gm-WOA7IhUd5xMrqCBSPzZFpv02Q6sJcVtaYD41wfHRL3';
        }


        protected function cleanAppCacheAll($appName, $tokenValidationFlag, $keyList, $request, $response)
        {

            //echo "cleanAppCacheAll";
            if(!$this->tokenUtils->validateJwtToken($tokenValidationFlag, $response)) {
                return;
            }

            try {
                $data = $this->cacheUtils->removeAllAppCache($appName, $keyList);
                $responseHeader = [];
                $responseHeader['code'] = '200';
                $responseHeader['message'] = 'Cache Cleaned';
                $Response['status'] = 200;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(200)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

        protected function cleanAppCacheKey($appName, $tokenValidationFlag, $key, $request, $response)
        {
            if(!$this->tokenUtils->validateJwtToken($tokenValidationFlag, $response)) {
                return;
            }

            try {
                $data = $this->cacheUtils->removeAppCache($appName, $key);
                $responseHeader = [];
                $responseHeader['code'] = '200';
                $responseHeader['message'] = 'Cache Cleaned';
                $Response['status'] = 200;
                $Response['header'] = $responseHeader;
                $Response['data'] = [];

                $response->code(200)->json($Response);
                return;
            } catch (Exception $e) {
                $Response['status'] = 500;
                $Response['message'] = $e->getMessage();
                $Response['data'] = [];

                $response->code(500)->json($Response);
                return;
            }
        }

    }
?>
