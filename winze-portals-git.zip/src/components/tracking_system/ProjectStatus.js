import React, {useEffect, useState} from 'react';
import { useTrackingSystemState, useTrackingSystemDispatch } from "../../context/tracking_system/TrackingSystemProvider";
import {
    modifiedLogsForProject,
    projectDetails,
    securityRoomDetails,
    serverDetails, updateServer,
    updateStatus
} from "./../../service/tracking_system/ApiService";
import {getFailureResponseData, getSuccessResponseData, isValidServiceResponse} from "./../../service/common/ServiceUtils";
import {
    getProjectAccess,
    getProjectDetails,
    getRoomDetailsForProject,
    getSecurityRoomDetailsForProject,
    getServerDetailsForProject,
    resetCacheForServerUpdate,
    resetCacheForStatusUpdate,
    setProjectDetails,
    setRoomDetailsForProject,
    setSecurityRoomDetailsForProject,
    setServerDetailsForProject
} from "./../../utils/tracking_system/TrackingSystemCache";
import {populatedChangeLog} from './../../utils/tracking_system/TrackingSystemUtils';
import {START_LOADING, STOP_LOADING} from "../../utils/portal/PortalAction";
import { Segment, Icon, Table , Button, Modal, Form, Select } from 'semantic-ui-react'
import Grid from "@material-ui/core/Grid";
import {usePortalDispatch} from "../../context/portal/PortalProvider";
import {makeStyles} from "@material-ui/core/styles";
import Pdf from "react-to-pdf";

const pdfRef = React.createRef();
let consoleLog = true;
let consoleDebugLog = true;
const isLogEnabled = function (logLevel){
    if(consoleLog){
        return true;
    }
    if(logLevel == "D" && consoleDebugLog){
        return true;
    }
    if(logLevel == "E"){
        return true;
    }
}
const useStyles = makeStyles((theme) => ({
    headcol : {
        position: "absolute",
        width: "5em",
        left: "0",
        top: "auto",
        "border-top-width": "1px",
        /*only relevant for first row*/
        "margin-top": "-1px",
        /*compensate for top border*/
    }
}));
export const ProjectStatus = (props) => {
    const classes = useStyles();
    const [modalDataOpen, setModalDataOpen] = useState();
    const [modalData, setModalData] = useState();
    const portalDispatch = usePortalDispatch();
    let serviceCompanyUser = false;
    let serverUpdate = false;
    let floorColumnRequired = true;
    let securityRoomsConfigured = false;
    let companyData = {};
    let codeDescriptionList = {};

    if(props.location.linkParam){
        let projectAccessData = getProjectAccess();
        let companyDataArr = projectAccessData.project_access_data.filter(({company_id}) => (company_id === props.location.linkParam.companyId));
        if(companyDataArr && companyDataArr.length > 0){
            companyData = companyDataArr[0];
            if(companyData && companyData.serverUpdate == "Y"){
                serverUpdate = true;
            }
            if(companyData && companyData.securityRooms == "Y"){
                securityRoomsConfigured = true;
            }
            if(companyData && companyData.floorColumnNotNeeded && companyData.floorColumnNotNeeded == "Y"){
                floorColumnRequired = false;
            }
        }
        if(projectAccessData.codeDescriptionList){
            codeDescriptionList = getProjectAccess().codeDescriptionList;
        }
        if(projectAccessData.service_company_user && projectAccessData.service_company_user == "Y"){
            serviceCompanyUser = true;
        }
    }
    const [rooms, setRooms] = useState([]);
    const [roomLogs, setRoomLogs] = useState([]);
    const [securityRoomsResponse, setSecurityRoomsResponse] = useState([]);
    const [serverDetailsResponse, setServerDetailsResponse] = useState([]);
    const [projectDetailsServiceCallInProgress, setProjectDetailsServiceCallInProgress] = useState(false);
    const [modifiedLogsServiceCallInProgress, setModifiedLogsServiceCallInProgress] = useState(false);
    const [securityRoomDetailsServiceCallInProgress, setSecurityRoomDetailsServiceCallInProgress] = useState(false);
    const [serverDetailsServiceCallInProgress, setServerDetailsServiceCallInProgress] = useState(false);

    const [totalFloors, setTotalFloors] = useState('');
    const [totalWings, setTotalWings] = useState('');
    const [modalDataInput, setModalDataInput] = useState({});
    const {count} = useTrackingSystemState();
    const dispatch = useTrackingSystemDispatch();
    const [securityRoomsData, setSecurityRoomsData] = useState([]);
    const [projectData, setProjectData] = useState([]);
    const [modifiedLogsData, setModifiedLogsData] = useState([]);

    if(isLogEnabled()) console.log("ProjectStatus - props " + JSON.stringify(props.location.linkParam));
    if(isLogEnabled()) console.log("ProjectStatus - projectDetailsServiceCallInProgress " + projectDetailsServiceCallInProgress);

    let inputFieldList = [];

    const getViewAuditLogModalContent = () => {
        return modalData.data.map(log => (
                                            <Grid container spacing={3}>
                                                <Grid item xs={4}>
                                                    <p>{log.modifiedDate} - {log.time} - {log.modifiedBy}</p>
                                                </Grid>
                                                <Grid item xs={8}>
                                                    {log.changesMade.map(log => (
                                                        <p>{populatedChangeLog(log)}</p>
                                                    ))
                                                    }
                                                </Grid>
                                            </Grid>
                                        ));
    }

    const handleChange = (event) => {
        if(isLogEnabled()) console.log("handleChange " + event.target.name);
        if(isLogEnabled()) console.log("handleChange " + event.target.value);
        //console.log("handleChange inputFieldRefMap " + JSON.stringify(inputFieldRefMap[event.target.name]));
        //let oldModalInputData = modalData;
        //oldModalInputData["data"][0][event.target.name] = event.target.value;
        //console.log("handleChange oldModalInputData " + JSON.stringify(oldModalInputData));
        //setModalData(oldModalInputData);
    }

    const getGetOptionList = (optionKey) => {
        let optionList = [{ key: 'select', value: '', text: 'Select' }];
        if(isLogEnabled()) console.log("optionList -> optionKey " + optionKey);
        if(isLogEnabled()) console.log("optionList -> codeDescriptionList " + JSON.stringify(codeDescriptionList));
        if(codeDescriptionList && codeDescriptionList[optionKey]){
            Object.keys(codeDescriptionList[optionKey]).forEach(key => {
                optionList.push({ key: key, value: key, text: codeDescriptionList[optionKey][key]});
            })
        }
        if(isLogEnabled()) console.log("optionList -> " + JSON.stringify(optionList));
        return optionList;
    }

    const getInputControl = (fieldNameParam, defaultValue) => {
        let currentValue = (modalData.data[0][fieldNameParam]) ? modalData.data[0][fieldNameParam] : ((defaultValue) ? defaultValue : "");
        let fieldList = getFieldListObject();
        if(fieldList && fieldList.length > 0){
            let fieldListFiltered = fieldList.filter(({fieldName}) => (fieldName == fieldNameParam));
            if(fieldListFiltered && fieldListFiltered.length > 0){
                let fieldItemFiltered = fieldListFiltered[0];
                if(fieldItemFiltered.fieldType == "select"){
                    inputFieldList.push({fieldName: fieldNameParam, fieldType: fieldItemFiltered.fieldType, currentValue: currentValue});
                    return <select id={fieldNameParam} name={fieldNameParam} defaultValue={currentValue} style={{width : "130px"}}>
                                {
                                    getGetOptionList(fieldItemFiltered.optionList).map((optionItem) => {
                                        return <option value={optionItem.value}>{optionItem.text}</option>
                                    })
                                }
                            </select>
                    //return <Select placeholder={"Select"} name={fieldNameParam} id={fieldNameParam} defaultValue={currentValue} options={getGetOptionList(fieldItemFiltered.optionList)} />
                }
            }
        }
        inputFieldList.push({fieldName: fieldNameParam, fieldType: "input", currentValue: currentValue});
        return <Form.Field control={"input"} name={fieldNameParam} id={fieldNameParam} defaultValue={currentValue} />
    }

    const replaceFieldValueDescription = (fieldNameParam, fieldValueParam) => {
        let fieldList = getFieldListObject();
        if(fieldList && fieldList.length > 0) {
            let fieldListFiltered = fieldList.filter(({fieldName}) => (fieldName == fieldNameParam));
            if (fieldListFiltered && fieldListFiltered.length > 0) {
                let fieldItemFiltered = fieldListFiltered[0];
                if (fieldItemFiltered.fieldType == "select") {
                    let filteredOptionList = getGetOptionList(fieldItemFiltered.optionList).filter(optionItem => optionItem.value == fieldValueParam);
                    if(filteredOptionList && filteredOptionList.length > 0){
                        return filteredOptionList[0].text;
                    }
                }
            }
        }
        return fieldValueParam;
    }

    const getFieldValue = (fieldName, defaultValue) => {
        if(modalData.actionType == "UpdateStatus" || modalData.actionType == "UpdateServer"){
            return getInputControl(fieldName, defaultValue);
        }
        return (modalData.data[0][fieldName]) ? replaceFieldValueDescription(fieldName, modalData.data[0][fieldName]) : ((defaultValue) ? defaultValue : "");
    }

    const getTableRow4ColContent = (fieldTwoRowList) => {
        return (<div style={{padding: "0px"}} className="ui grid">
                {
                    fieldTwoRowList.map(fieldsForRow => {
                        if(isLogEnabled()) console.log("fieldsForRow -> " + JSON.stringify(fieldsForRow));
                        if(isLogEnabled()) console.log("fieldsForRow[0] -> " + JSON.stringify(fieldsForRow[0]));
                        if(isLogEnabled()) console.log("fieldsForRow[0].fieldLabel -> " + fieldsForRow[0].fieldLabel);
                        return (<div className="four column row">
                                    <div style={{paddingLeft: "15px", marginTop: "8px", fontWeight: "bold", verticalAlign: "middle"}} className="column">{fieldsForRow[0].fieldLabel}</div>
                                    <div className="column">{getFieldValue(fieldsForRow[0].fieldName, fieldsForRow[0].defaultValue)}</div>
                                    <div style={{paddingLeft: "15px", marginTop: "8px", fontWeight: "bold"}} className="column">{fieldsForRow.length > 1 ? fieldsForRow[1].fieldLabel : ""}</div>
                                    <div className="column">{fieldsForRow.length > 1 ? getFieldValue(fieldsForRow[1].fieldName, fieldsForRow[1].defaultValue) : ""}</div>
                                </div>)
                    })
                }
            </div>);
    }

    const getTableRow2ColContent = (fieldList) => {
        return (<div style={{padding: "0px"}} className="ui grid">
            {
                fieldList.map(fieldRow => {
                    if(isLogEnabled()) console.log("fieldRow -> " + JSON.stringify(fieldRow));
                    if(isLogEnabled()) console.log("fieldRow.fieldLabel -> " + fieldRow.fieldLabel);
                    return (<div className="two column row">
                        <div style={{paddingLeft: "15px", fontWeight: "bold"}} className="column">{fieldRow.fieldLabel}</div>
                        <div className="column">{getFieldValue(fieldRow.fieldName, fieldRow.defaultValue)}</div>
                    </div>)
                })
            }
        </div>);
    }

    const getInOutColsContentHeader = (fieldGroupConfigData) => {
        return <Table.Header>
                    <Table.Row>
                        <Table.HeaderCell></Table.HeaderCell>
                        {
                            getInOutColsGroupFieldList(fieldGroupConfigData).map(group => {
                                if(fieldGroupConfigData[group]){
                                    return  <Table.HeaderCell>{fieldGroupConfigData[group].label}</Table.HeaderCell>
                                }else{
                                    return  <Table.HeaderCell>{group}</Table.HeaderCell>
                                }
                            })
                        }
                    </Table.Row>
                </Table.Header>;
    }

    const getInOutColsContentBody = (fieldListCollection, fieldGroupConfigData) => {
        return <Table.Body>
                    {
                        fieldGroupConfigData.rowLabels.map(rowLabelValue => {
                            return <Table.Row>
                                        <Table.Cell style={{fontWeight : "bold"}}>{rowLabelValue}</Table.Cell>
                                        {
                                            getInOutColsGroupFieldList(fieldGroupConfigData).map(group => {
                                                    if(fieldListCollection[group]){
                                                        let rowLabelObj = fieldListCollection[group].filter(({rowLabel}) => (rowLabel != undefined && rowLabel == rowLabelValue));
                                                        if(isLogEnabled()) console.log(group + " -> " + rowLabelValue + " -> rowLabelObj " + JSON.stringify(rowLabelObj))
                                                        if(rowLabelObj && rowLabelObj.length > 0){
                                                            return <Table.Cell>{getFieldValue(rowLabelObj[0].fieldName)}</Table.Cell>;
                                                        }
                                                        return <Table.Cell>Not Avail</Table.Cell>;
                                                    }else{
                                                        return <Table.Cell>Not Avail</Table.Cell>;
                                                    }
                                                }
                                            )
                                        }
                                    </Table.Row>
                        })
                    }
                </Table.Body>
    }

    const getInOutColsContent = (fieldListCollection, fieldGroupConfigData) => {
        if(isLogEnabled()) console.log("fieldListCollection -> " + JSON.stringify(fieldListCollection));
        return <Table style={{border: "0px", padding: "0px", spacing: "0px", whiteSpace: "nowrap"}}>
                    {getInOutColsContentHeader(fieldGroupConfigData)}
                    {getInOutColsContentBody(fieldListCollection, fieldGroupConfigData)}
                </Table>
    }

    const getInOutColsGroupFieldList = (fieldGroupConfigData) => {
        let groupListTmp = [];
        fieldGroupConfigData.groupList.forEach(group => {
            if(fieldGroupConfigData[group] && (fieldGroupConfigData[group]["actionList"] == undefined || fieldGroupConfigData[group]["actionList"].indexOf(modalData.actionType) != -1)){
                groupListTmp.push(group);
            }
        })
        return groupListTmp;
    }

    const getFieldListContent = (fieldGroupKey, fieldGroupConfigData) => {
        let fieldList = getFieldListObject();
        if(fieldList && fieldList.length > 0){
            if(fieldGroupConfigData.groupType == "4Col"){
                let fieldListTmp = fieldList.filter(({fieldGroup, actionList}) => (fieldGroup != undefined && fieldGroup === fieldGroupKey && (actionList == undefined || actionList.indexOf(modalData.actionType) != -1)));
                if(fieldListTmp && fieldListTmp.length > 0){
                    const fieldTwoRowList = fieldListTmp.reduce(function (fieldTwoRowList, key, index) {
                                                return (index % 2 == 0 ? fieldTwoRowList.push([key])
                                                    : fieldTwoRowList[fieldTwoRowList.length-1].push(key)) && fieldTwoRowList;
                                            }, []);
                    //console.log("fieldTwoRowList -> " + JSON.stringify(fieldTwoRowList));
                    return getTableRow4ColContent(fieldTwoRowList);
                }else{
                    return (<p>Field List NOT exists.</p>);
                }
            }else  if(fieldGroupConfigData.groupType == "2Col"){
                let fieldListTmp = fieldList.filter(({fieldGroup, actionList}) => (fieldGroup != undefined && fieldGroup === fieldGroupKey  && (actionList == undefined || actionList.indexOf(modalData.actionType) != -1)));
                if(fieldListTmp && fieldListTmp.length > 0){
                    return getTableRow2ColContent(fieldListTmp);
                }
                return (<p>Field List NOT exists.</p>);
            }else  if(fieldGroupConfigData.groupType == "InOutCols"){
                let fieldListCollection = {};
                getInOutColsGroupFieldList(fieldGroupConfigData).forEach(group => {
                    let fieldListTmp = fieldList.filter(({fieldGroup, secondaryGroup, actionList}) => (fieldGroup != undefined && secondaryGroup != undefined && fieldGroup === fieldGroupKey && secondaryGroup === group  && (actionList == undefined || actionList.indexOf(modalData.actionType) != -1)));
                    fieldListCollection[group] = fieldListTmp;
                })
                return getInOutColsContent(fieldListCollection, fieldGroupConfigData);
            }
        }
        return (<p>Invalid Group Type / No Field List exists.</p>);
    }

    const getFieldGroupContent = (fieldGroupKey) => {
        let fieldGroupList = getFieldGroupListObject();
        if(fieldGroupList[fieldGroupKey].label){
            return (<>
                        <Segment as='h5' attached='top' inverted color='teal' textAlign={"center"}>
                            {fieldGroupList[fieldGroupKey].label}
                        </Segment>
                        <Segment attached  style={{overflow: 'auto', maxHeight: "550px"}}>
                            <Form>
                                {getFieldListContent(fieldGroupKey, fieldGroupList[fieldGroupKey])}
                            </Form>
                        </Segment>
                        <br/>
                    </>);
        }else{
            return (
                <Segment style={{overflow: 'auto', maxHeight: "550px"}}>
                    <Form>
                        {getFieldListContent(fieldGroupKey, fieldGroupList[fieldGroupKey])}
                    </Form>
                </Segment>);
        }
    }

    const getFieldGroupListObject = () => {
        if(modalData.actionType == "UpdateServer"){
            return companyData.serverFieldGroupList;
        }else{
            return companyData.fieldGroupList;
        }
    }

    const getFieldListObject = () => {
        if(modalData.actionType == "UpdateServer"){
            return companyData.serverFieldList;
        }else{
            return companyData.fieldList;
        }
    }

    const getInOutViewStatusModalContent = () => {
        let fieldGroupList = getFieldGroupListObject();
        if(fieldGroupList && Object.keys(fieldGroupList).length > 0){
            return <>
                {
                    Object.keys(fieldGroupList).map(fieldGroupKey => {
                        return <>{getFieldGroupContent(fieldGroupKey)}</>
                    })
                }
            </>
        }else{
            return (<p>InOutView - Data available - No Field Group.</p>);
        }
    }

    const getUpdateServerModalContent = () => {
        if(companyData.serverUpdateType == "InOutView"){
            return getInOutViewStatusModalContent();
        }
        return (<p>Update Server - Data available {companyData.statusUpdateType} (getUpdateServerModalContent).</p>);
    }

    const getUpdateStatusModalContent = () => {
        if(companyData.statusUpdateType == "InOutView"){
            return getInOutViewStatusModalContent();
        }
        return (<p>UpdateStatus - Data available {companyData.statusUpdateType} (getUpdateStatusModalContent).</p>);
    }

    const getViewStatusModalContent = () => {
        if(companyData.statusViewType == "InOutView"){
            return getInOutViewStatusModalContent();
        }
        return (<p>ViewStatus - Data available {companyData.statusViewType} (getViewStatusModalContent).</p>);
    }

    const getModalDataContent = () => {
        inputFieldList = [];
        if(modalData){
            if(modalData.data && modalData.data.length > 0){
                if(modalData.actionType == "ViewAuditLogs") {
                    return getViewAuditLogModalContent();
                }else if(modalData.actionType == "UpdateStatus"){
                    return getUpdateStatusModalContent();
                }else if(modalData.actionType == "UpdateServer"){
                    return getUpdateServerModalContent();
                }else if(modalData.actionType == "ViewStatus"){
                    return getViewStatusModalContent();
                }else{
                    return (<p>Invalid Action Type.</p>);
                }
            }else{
                return (<p>Data Not available.</p>);
            }
        }else{
            return (<></>);
        }
    }

    const loadDataToState = (modalDataParam) => {
        if(modalDataParam && modalDataParam.length > 0){
            let modalDataToState = {};
            Object.keys(modalDataParam[0]).forEach(modalDataKey => {
                modalDataToState[modalDataKey] = modalDataParam[0][modalDataKey];
            })
            //setModalDataInput(modalDataToState);
        }

        if(modalDataOpen && inputFieldList.length > 0){
            inputFieldList.forEach(fieldDetail => {
                //document.getElementById(fieldDetail.fieldName).value = fieldDetail.currentValue;
            })
        }
        return <></>
    }

    const updateStatusServiceSuccess = function(successResponse, previous, current, documentId){
        if(isLogEnabled()) console.log('updateStatusServiceSuccess : ' + JSON.stringify(successResponse));
        if(isLogEnabled()) console.log('updateStatusServiceSuccess  documentId : ' + documentId);
        if(isLogEnabled()) console.log('updateStatusServiceSuccess current : ' + JSON.stringify(current));

        if(isValidServiceResponse(successResponse)){
            let updateStatusResponse = getSuccessResponseData(successResponse);
            if(isLogEnabled()) console.log('updateStatusResponse : ' + JSON.stringify(updateStatusResponse));
            let sessionProjectDetails = getProjectDetails(props.location.linkParam.companyId, props.location.linkParam.projectName, props.location.linkParam.wing);
            if(isLogEnabled()) console.log("updateStatusServiceSuccess sessionProjectDetails -> " + JSON.stringify(sessionProjectDetails));

            if(sessionProjectDetails && sessionProjectDetails.length > 0){
                let sessionRoomData = sessionProjectDetails.find(roomDataItem => roomDataItem.id == documentId);
                if(sessionRoomData){
                    if(isLogEnabled()) console.log("updateStatusServiceSuccess sessionRoomData -> " + JSON.stringify(sessionRoomData));
                    if(current && current.modifiedData && current.modifiedData.length > 0){
                        current.modifiedData.forEach(modifiedItem => {
                            sessionRoomData[modifiedItem.fieldName] = modifiedItem.fieldValue;
                        })
                        if(isLogEnabled()) console.log("updateStatusServiceSuccess After update sessionRoomData -> " + JSON.stringify(sessionRoomData));
                        if(isLogEnabled()) console.log("updateStatusServiceSuccess After update sessionProjectDetails -> " + JSON.stringify(sessionProjectDetails));
                        setProjectDetails(props.location.linkParam.companyId, props.location.linkParam.projectName, props.location.linkParam.wing, sessionProjectDetails);
                        loadProjectDetailsData(sessionProjectDetails);
                    }

                }else{
                    if(isLogEnabled()) console.log("updateStatusServiceSuccess sessionRoomData NOT Found");
                }
            }
            resetCacheForStatusUpdate(props.location.linkParam.companyId, props.location.linkParam.projectName);
        }
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const updateStatusServiceFailure = function(failureResponse){
        if(isLogEnabled()) console.log('updateStatusServiceFailure : failureResponse -> ' + JSON.stringify(failureResponse));
        let failureData = getFailureResponseData(failureResponse);
        if(isLogEnabled()) console.log('failureData : ' + JSON.stringify(failureData));
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const updateServerServiceSuccess = function(successResponse, previous, current, documentId){
        console.log('updateServerServiceSuccess : ' + JSON.stringify(successResponse));

        if(isValidServiceResponse(successResponse)){
            let updateServerResponse = getSuccessResponseData(successResponse);
            console.log('updateServerResponse : ' + JSON.stringify(updateServerResponse));
            let sessionServerDetails = getServerDetailsForProject(props.location.linkParam.companyId, props.location.linkParam.projectName);
            if(isLogEnabled()) console.log("updateServerServiceSuccess sessionServerDetails -> " + JSON.stringify(sessionServerDetails));

            if(sessionServerDetails && sessionServerDetails.length > 0){
                let serverData = sessionServerDetails.find(roomDataItem => roomDataItem.id == documentId);
                if(serverData){
                    if(isLogEnabled()) console.log("updateServerServiceSuccess serverData -> " + JSON.stringify(serverData));
                    if(current && current.modifiedData && current.modifiedData.length > 0){
                        current.modifiedData.forEach(modifiedItem => {
                            serverData[modifiedItem.fieldName] = modifiedItem.fieldValue;
                        })
                        if(isLogEnabled()) console.log("updateServerServiceSuccess After update serverData -> " + JSON.stringify(serverData));
                        if(isLogEnabled()) console.log("updateServerServiceSuccess After update sessionProjectDetails -> " + JSON.stringify(sessionServerDetails));
                        setServerDetailsForProject(props.location.linkParam.companyId, props.location.linkParam.projectName, sessionServerDetails);
                        loadServerDetailsData(sessionServerDetails);
                    }

                }else{
                    if(isLogEnabled()) console.log("updateServerServiceSuccess sessionRoomData NOT Found");
                }
            }
            resetCacheForServerUpdate(props.location.linkParam.companyId, props.location.linkParam.projectName);
        }
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const updateServerServiceFailure = function(failureResponse){
        console.log('updateServerServiceFailure : ' + JSON.stringify(failureResponse));
        let failureData = getFailureResponseData(failureResponse);
        console.log('failureData : ' + JSON.stringify(failureData));
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const submitStatus = (actionType) => {
        if(isLogEnabled()) console.log("submitStatus " + JSON.stringify(inputFieldList));
        let changedFields = [];
        inputFieldList.forEach(fieldDetail => {
            let currentValue = fieldDetail.currentValue;
            let newValue = "";
            if(fieldDetail.fieldType == "select"){
                //console.log("submitStatus " + fieldDetail.fieldName + " -> " + document.getElementById(fieldDetail.fieldName).options[document.getElementById(fieldDetail.fieldName).selectedIndex].value);
                newValue = document.getElementById(fieldDetail.fieldName).options[document.getElementById(fieldDetail.fieldName).selectedIndex].value;
            }else{
                //console.log("submitStatus " + fieldDetail.fieldName + " -> " + document.getElementById(fieldDetail.fieldName).value);
                newValue = document.getElementById(fieldDetail.fieldName).value;
            }
            if(isLogEnabled()) console.log("submitStatus " + fieldDetail.fieldName + " -> " + currentValue + " : " + newValue);
            if(currentValue != newValue){
                changedFields.push({fieldName: fieldDetail.fieldName, fieldValue: newValue});
            }
        })
        if(isLogEnabled()) console.log("submitStatus changedFields " + JSON.stringify(changedFields));
        if(changedFields.length > 0){
            let updateStatusData = {documentId: modalData.data[0]["id"], modifiedData: changedFields};
            if(isLogEnabled()) console.log("submitStatus updateStatusData " + JSON.stringify(updateStatusData));
            portalDispatch({
                type: START_LOADING
            })
            if(actionType == "UpdateServer") {
                //updateServerServiceSuccess({}, null, updateStatusData, modalData.data[0]["id"]);
                updateServer({headers:{companyId : props.location.linkParam.companyId},data: updateStatusData}, updateServerServiceSuccess, updateServerServiceFailure, portalDispatch, null, updateStatusData, modalData.data[0]["id"]);
            }else if(actionType == "UpdateStatus"){
                //updateStatusServiceSuccess({}, null, updateStatusData, modalData.data[0]["id"]);
                updateStatus({headers:{companyId : props.location.linkParam.companyId}, data: updateStatusData}, updateStatusServiceSuccess, updateStatusServiceFailure, portalDispatch, null, updateStatusData, modalData.data[0]["id"]);
            }else{
                portalDispatch({
                    type: STOP_LOADING
                })
            }
        }
        setModalDataOpen(false);
    }

    const openUpdateServerScreen = (actionType) => {
        if(isLogEnabled()) console.log("openUpdateServerScreen -> " + actionType);
        if(actionType){
            let modalDataObject = {
                actionType: actionType,
                dataAvailable : true
            };
            const headingSuffix = props.location.linkParam.projectName;
            if(actionType == "UpdateServer"){
                modalDataObject.heading = "Update Server - " + headingSuffix;
                if(isLogEnabled()) console.log("openUpdateServerScreen ->  serverDetailsResponse -> " + JSON.stringify(serverDetailsResponse));
                if(serverDetailsResponse && serverDetailsResponse.length > 0){
                    modalDataObject.data = serverDetailsResponse;
                }else{
                    modalDataObject.data = [];
                    modalDataObject.dataAvailable = false;
                }
                setModalData(modalDataObject);
            }
        }
        setModalDataOpen(true);
    }

    const openViewLogScreen = (wingParam, floorParam, roomParam, actionType) => {
        if(isLogEnabled()) console.log("openViewLogScreen -> " + wingParam + ", " + floorParam + ", " + roomParam + ", " + actionType);
        if(actionType){
            let modalDataObject = {
                wing : wingParam.wing,
                wingName : wingParam.wingName,
                floorNo : floorParam,
                roomNo : roomParam,
                dataAvailable : true,
                actionType: actionType
            };
            const headingSuffix = props.location.linkParam.projectName + " | " + ((wingParam.wingName) ? wingParam.wingName : companyData.wingNamePrefix + " - " + ((wingParam.wing) ? wingParam.wing : "")) + " | Floor - " + ((floorParam) ? floorParam : "") + " | Flat - "  + ((roomParam) ? roomParam : "");
            if(actionType == "ViewAuditLogs"){
                if(roomLogs){
                    let roomLogArr = roomLogs.filter(({wing, floorNo, roomNo}) => (wing === wingParam.wing && floorNo === floorParam && roomNo === roomParam));
                    if(isLogEnabled()) console.log("openViewLogScreen -> roomLogs -> " + JSON.stringify(roomLogs));
                    if(roomLogArr && roomLogArr.length > 0){
                        if(isLogEnabled()) console.log("openViewLogScreen -> modalDataObject -> " + JSON.stringify(modalDataObject));
                        modalDataObject.data = roomLogArr.sort(function(objOne, objTwo) {
                            if(objOne.timestamp.seconds > objTwo.timestamp.seconds){
                                return -1;
                            }else{
                                return 1;
                            }
                        });
                        //roomLog.data = roomLogArr;
                    }else{
                        if(isLogEnabled()) console.log("openViewLogScreen -> roomLog -> NOT FOUND");
                        modalDataObject.data = [];
                        modalDataObject.dataAvailable = false;
                    }
                }else{
                    if(isLogEnabled()) console.log("openViewLogScreen -> roomLog -> NOT FOUND");
                    modalDataObject.data = [];
                    modalDataObject.dataAvailable = false;
                }
                modalDataObject.heading = "Audit Logs for - " + headingSuffix;
                setModalData(modalDataObject);
            }else if(actionType == "UpdateStatus"){
                modalDataObject.heading = "Update Status - " + headingSuffix;
                let roomArr = rooms.filter(({wing, floorNo, roomNo}) => (wing === wingParam.wing && floorNo === floorParam && roomNo === roomParam));
                if(isLogEnabled()) console.log("openViewLogScreen -> UpdateStatus ->  roomArr -> " + JSON.stringify(roomArr));
                if(roomArr && roomArr.length > 0){
                    modalDataObject.data = roomArr;
                }else{
                    modalDataObject.data = [];
                    modalDataObject.dataAvailable = false;
                }
                loadDataToState(modalDataObject.data);
                setModalData(modalDataObject);
            }else if(actionType == "ViewStatus"){
                modalDataObject.heading = "View Status - " + headingSuffix;
                let roomArr = rooms.filter(({wing, floorNo, roomNo}) => (wing === wingParam.wing && floorNo === floorParam && roomNo === roomParam));
                if(isLogEnabled()) console.log("openViewLogScreen -> ViewStatus -> roomArr -> " + JSON.stringify(roomArr));
                if(roomArr && roomArr.length > 0){
                    modalDataObject.data = roomArr;
                }else{
                    modalDataObject.data = [];
                    modalDataObject.dataAvailable = false;
                }
                loadDataToState(modalDataObject.data);
                setModalData(modalDataObject);
            }
        }
        setModalDataOpen(true);
    }

    const screenHeading = () => {
        let heading = props.location.linkParam.companyName + " - " + props.location.linkParam.projectName;
        if(props.location.linkParam.requestType == "W"){
            heading += " - " + props.location.linkParam.wingNamePrefix + props.location.linkParam.wing;
        }
        return heading;
    }

    const getDistinctWings = () => {
        //console.log('rooms : ' + JSON.stringify(rooms));
        let uniqueArray = [];
        //const distinctWings = [...new Set(rooms.map(roomDetail => {return roomDetail.wing;}))];
        //console.log('distinctWings : ' + JSON.stringify(distinctWings));
        let distinctWingsNew = [];
        if(rooms && rooms.length > 0){
            distinctWingsNew =  [...new Set(rooms.map(roomDetail => {return {wing : roomDetail.wing, wingName: ((roomDetail.wingName) ? roomDetail.wingName : companyData.wingNamePrefix + " - " + roomDetail.wing)};}))];
        }
        distinctWingsNew = distinctWingsNew.filter((wingItem, index) => {
                                                                    //console.log(JSON.stringify(wingItem) + " -> " + JSON.stringify(uniqueArray));
                                                                    if(uniqueArray.indexOf(JSON.stringify(wingItem)) == -1){
                                                                        uniqueArray.push(JSON.stringify(wingItem));
                                                                        //console.log("TRUE -> ");
                                                                        return true;
                                                                    }
                                                                    //console.log("FALSE -> ");
                                                                    return false;
                                                            });
        //console.log('uniqueArray : ' + JSON.stringify(uniqueArray));
        distinctWingsNew = distinctWingsNew.sort(function(objOne, objTwo) {
                                                                if(objOne.wing > objTwo.wing){
                                                                    return 1;
                                                                }else{
                                                                    return -1;
                                                                }
                                                            });
        //console.log('distinctWingsNew : ' + JSON.stringify(distinctWingsNew));
        return distinctWingsNew;
    }

    const getDistinctFloorsForWing = (wingParam) => {
        let distinctFloors = [];
        if(rooms && rooms.length > 0){
            distinctFloors = [...new Set(rooms.filter(({wing}) => (wing === wingParam.wing)).map(roomDetail => {return roomDetail.floorNo;}))]
        }
        return distinctFloors.sort(function(objOne, objTwo) {
                                                                if(parseInt(objOne) > parseInt(objTwo)){
                                                                    return -1;
                                                                }else{
                                                                    return 1;
                                                                }
                                                            });
    }

    const getDistinctRooms = (wingParam, floorParam) => {
        let distinctRooms = [];
        if(rooms && rooms.length > 0){
            distinctRooms = [...new Set(rooms.filter(({wing, floorNo}) => (wing === wingParam.wing && floorNo === floorParam)).map(roomDetail => {return roomDetail.roomNo;}))]
        }
        return distinctRooms.sort();
    }

    const loadProjectDetailsData = function(projectDetailsData){
        setRooms(projectDetailsData);
    }

    const loadModifiedRoomDetailsData = function(modifiedRoomDetailsData){
        if(isLogEnabled()) console.log('loadModifiedRoomDetailsData : ');
        setRoomLogs(modifiedRoomDetailsData);
    }

    const loadServerDetailsData = function(serverDetailsData){
        if(isLogEnabled()) console.log('loadServerDetailsData : ');
        setServerDetailsResponse(serverDetailsData);
    }

    const loadSecurityRoomDetailsData = function(securityRoomDetailsData){
        if(isLogEnabled()) console.log('loadSecurityRoomDetailsData : ');
        setSecurityRoomsResponse(securityRoomDetailsData);
    }

    const projectDetailsServiceSuccess = function(successResponse, projectName, wing, floor){
        if(isLogEnabled()) console.log('projectDetailsServiceSuccess : ' + JSON.stringify(successResponse));
        if(isValidServiceResponse(successResponse)){
            let projectDetailsResponse = getSuccessResponseData(successResponse);
            if(isLogEnabled()) console.log('projectDetailsResponse : ' + JSON.stringify(projectDetailsResponse));
            if(isLogEnabled()) console.log('projectDetailsResponse : ' + ( Array.isArray(projectDetailsResponse.data) ));
            //setProjectData(projectDetailsResponse.data);
            setProjectDetails(props.location.linkParam.companyId, projectName, wing, projectDetailsResponse.data);
            if(isLogEnabled()) console.log("getProjectDetails(props.building) -> " + getProjectDetails(props.location.linkParam.companyId, props.location.linkParam.projectName, props.location.linkParam.wing));
            loadProjectDetailsData(projectDetailsResponse.data);
            setProjectDetailsServiceCallInProgress(false);
        }
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const projectDetailsServiceFailure = function(failureResponse){
        if(isLogEnabled()) console.log('projectDetailsServiceFailure : ' + JSON.stringify(failureResponse));
        let failureData = getFailureResponseData(failureResponse);
        if(isLogEnabled()) console.log('failureData : ' + JSON.stringify(failureData));
        setProjectDetailsServiceCallInProgress(false);
        setRooms([]);
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const modifiedLogsServiceSuccess = function(successResponse, projectName){
        //console.log('modifiedLogsServiceSuccess : ' + JSON.stringify(successResponse));
        if(isLogEnabled()) console.log('modifiedLogsServiceSuccess : ' + projectName);
        if(isValidServiceResponse(successResponse)){
            let modifiedLogsResponse = getSuccessResponseData(successResponse);
            if(isLogEnabled()) console.log('modifiedLogsResponse : ' + JSON.stringify(modifiedLogsResponse));
            //setModifiedLogsData(modifiedLogsResponse.data);
            setRoomDetailsForProject(props.location.linkParam.companyId, projectName, modifiedLogsResponse.data);
            loadModifiedRoomDetailsData(modifiedLogsResponse.data);
            setModifiedLogsServiceCallInProgress(false);
        }
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const modifiedLogsServiceFailure = function(failureResponse){
        if(isLogEnabled()) console.log('modifiedLogsServiceFailure : ' + JSON.stringify(failureResponse));
        let failureData = getFailureResponseData(failureResponse);
        if(isLogEnabled()) console.log('failureData : ' + JSON.stringify(failureData));
        setModifiedLogsServiceCallInProgress(false);
        setRoomLogs([]);
        portalDispatch({
            type: STOP_LOADING
        })
    }


    const serverDetailsServiceSuccess = function(successResponse, projectName){
        //console.log('serverDetailsServiceSuccess : ' + JSON.stringify(successResponse));
        if(isLogEnabled()) console.log('serverDetailsServiceSuccess : ' + projectName);
        if(isValidServiceResponse(successResponse)){
            let serverDetailsResponse = getSuccessResponseData(successResponse);
            if(isLogEnabled()) console.log('serverDetailsResponse : ' + JSON.stringify(serverDetailsResponse));
            //setSecurityRoomsData(serviceRoomsResponse.data);
            setServerDetailsForProject(props.location.linkParam.companyId, projectName, serverDetailsResponse.data);
            loadServerDetailsData(serverDetailsResponse.data, projectName);
            setServerDetailsServiceCallInProgress(false);
        }
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const serverDetailsServiceFailure = function(failureResponse){
        if(isLogEnabled()) console.log('serverDetailsServiceFailure : ' + JSON.stringify(failureResponse));
        let failureData = getFailureResponseData(failureResponse);
        if(isLogEnabled()) console.log('failureData : ' + JSON.stringify(failureData));
        setServerDetailsServiceCallInProgress(false);
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const securityRoomDetailsServiceSuccess = function(successResponse, projectName){
        //console.log('securityRoomDetailsServiceSuccess : ' + JSON.stringify(successResponse));
        if(isLogEnabled()) console.log('securityRoomDetailsServiceSuccess : ' + projectName);
        if(isValidServiceResponse(successResponse)){
            let securityRoomDetailsResponse = getSuccessResponseData(successResponse);
            if(isLogEnabled()) console.log('securityRoomDetailsResponse : ' + JSON.stringify(securityRoomDetailsResponse));
            //setSecurityRoomsData(serviceRoomsResponse.data);
            setSecurityRoomDetailsForProject(props.location.linkParam.companyId, projectName, securityRoomDetailsResponse.data);
            loadSecurityRoomDetailsData(securityRoomDetailsResponse.data, projectName);
            setSecurityRoomDetailsServiceCallInProgress(false);
        }
        portalDispatch({
            type: STOP_LOADING
        })
    }

    const securityRoomDetailsServiceFailure = function(failureResponse){
        if(isLogEnabled()) console.log('securityRoomDetailsServiceFailure : ' + JSON.stringify(failureResponse));
        let failureData = getFailureResponseData(failureResponse);
        if(isLogEnabled()) console.log('failureData : ' + JSON.stringify(failureData));
        setSecurityRoomDetailsServiceCallInProgress(false);
        portalDispatch({
            type: STOP_LOADING
        })
    }

    useEffect(() => {
        if(isLogEnabled()) console.log('Inside useEffect : ');
        if(props.location.linkParam){
            if(props.location.linkParam.requestType == "P" || props.location.linkParam.requestType == "W"){
                let projectDetailsFromSession = getProjectDetails(props.location.linkParam.companyId, props.location.linkParam.projectName, props.location.linkParam.wing);
                let roomDetailsFromSession = getRoomDetailsForProject(props.location.linkParam.companyId, props.location.linkParam.projectName);
                if(isLogEnabled()) console.log('FROM Before loadprojectDetailsData : projectDetailsFromSession ' + projectDetailsFromSession);
                if(isLogEnabled()) console.log('FROM Before loadprojectDetailsData : roomDetailsFromSession ' + roomDetailsFromSession);
                if(projectDetailsFromSession != null){
                    if(isLogEnabled()) console.log('FROM Before loadprojectDetailsData : ');
                    loadProjectDetailsData(projectDetailsFromSession);
                }else{
                    if(isLogEnabled()) console.log('NOT From Before loadprojectDetailsData : ');
                    if(!projectDetailsServiceCallInProgress){
                        if(isLogEnabled()) console.log('projectDetailsServiceCallInProgress TRUE : ');
                        portalDispatch({
                            type: START_LOADING
                        })
                        setProjectDetailsServiceCallInProgress(true);
                        projectDetails({headers:{companyId : props.location.linkParam.companyId}}, projectDetailsServiceSuccess, projectDetailsServiceFailure, portalDispatch, props.location.linkParam.projectName, props.location.linkParam.wing);
                    }
                    if(isLogEnabled()) console.log('projectDetailsServiceCallInProgress Outside Check : ');
                }
                if(roomDetailsFromSession != null){
                    if(isLogEnabled()) console.log('FROM Before loadModifiedRoomDetailsData : ');
                    loadModifiedRoomDetailsData(roomDetailsFromSession);
                }else{
                    if(isLogEnabled()) console.log('NOT from Before loadModifiedRoomDetailsData : ');
                    if(!modifiedLogsServiceCallInProgress) {
                        portalDispatch({
                            type: START_LOADING
                        })
                        modifiedLogsForProject({headers:{companyId : props.location.linkParam.companyId}}, modifiedLogsServiceSuccess, modifiedLogsServiceFailure, portalDispatch, props.location.linkParam.projectName, props.location.linkParam.projectName);
                    }
                }
                if(securityRoomsConfigured){
                    if(getSecurityRoomDetailsForProject(props.location.linkParam.companyId, props.location.linkParam.projectName) != null){
                        if(isLogEnabled()) console.log('FROM Before loadSecurityRoomDetailsData : ');
                        loadSecurityRoomDetailsData(getSecurityRoomDetailsForProject(props.location.linkParam.companyId, props.location.linkParam.projectName));
                    }else{
                        if(isLogEnabled()) console.log('NOT from Before loadSecurityRoomDetailsData : ');
                        if(!securityRoomDetailsServiceCallInProgress) {
                            portalDispatch({
                                type: START_LOADING
                            })
                            securityRoomDetails( {headers:{companyId : props.location.linkParam.companyId}}, securityRoomDetailsServiceSuccess, securityRoomDetailsServiceFailure, portalDispatch, props.location.linkParam.projectName);
                        }
                    }
                }
                if(serverUpdate && serviceCompanyUser){
                    if(getServerDetailsForProject(props.location.linkParam.companyId, props.location.linkParam.projectName) != null){
                        if(isLogEnabled()) console.log('FROM Before loadServerDetailsData : ');
                        loadServerDetailsData(getServerDetailsForProject(props.location.linkParam.companyId, props.location.linkParam.projectName));
                    }else{
                        if(isLogEnabled()) console.log('NOT from Before loadServerDetailsData : ');
                        if(!serverDetailsServiceCallInProgress) {
                            portalDispatch({
                                type: START_LOADING
                            })
                            serverDetails( {headers:{companyId : props.location.linkParam.companyId}}, serverDetailsServiceSuccess, serverDetailsServiceFailure, portalDispatch, props.location.linkParam.projectName);
                        }
                    }
                }
            }else if(props.location.linkParam.requestType == "W"){

            }
        }
    }, [props.location.linkParam]);

    return (
        <div>
            <Pdf targetRef={pdfRef} filename="code-example.pdf" options={{orientation: "landscape", unit: "in"}} >
                {({ toPdf }) => <button onClick={toPdf}>Generate Pdf</button>}
            </Pdf>
            {console.log("Inside Project View screen")}
            {
                (props.location.linkParam)
                ?
                    <div ref={pdfRef}>
                        <div style={{padding: "15px"}} className="ui grid">
                            <div className="two column row border">
                                <div style={{padding: "0px", verticalAlign: "middle"}} className="column"><h5>{screenHeading()}</h5></div>
                                <div style={{padding: "0px", verticalAlign: "middle", textAlign: "right"}} className="column">
                                    {
                                        (serverUpdate && serviceCompanyUser)
                                        ?
                                            <h5 style={{cursor: "pointer", color: "#CD1144"}}  onClick={() => openUpdateServerScreen("UpdateServer")}><Icon className={"server"} />Update Server</h5>
                                        :
                                            <></>
                                    }
                                </div>
                            </div>
                        </div>
                        {
                            getDistinctWings().map((wingItem) => {
                                return  <>
                                            <Segment as='h5' attached='top' inverted color='teal' textAlign={"center"}>{wingItem.wingName}</Segment>
                                            <Segment attached>
                                                <Table celled structured>
                                                    <Table.Body>
                                                        {
                                                            getDistinctFloorsForWing(wingItem).map((floorItem) => {
                                                                return <>
                                                                            <Table.Row>
                                                                                {
                                                                                    floorColumnRequired
                                                                                    ?
                                                                                        <Table.Cell style={{fontStyle: "italic", fontWeight: "bold"}}>Floor-{floorItem}</Table.Cell>
                                                                                    :
                                                                                        <></>
                                                                                }
                                                                                {
                                                                                    getDistinctRooms(wingItem, floorItem).map((roomItem) => {
                                                                                        return <>
                                                                                                <Table.Cell>
                                                                                                    <div style={{padding: "0px"}} className="ui grid">
                                                                                                        <div className={serviceCompanyUser ? "three column row" : "two column row"}>
                                                                                                            {
                                                                                                                serviceCompanyUser ?
                                                                                                                    <div style={{padding: "0px", textAlign: "center"}} className="column"><Icon style={{cursor: "pointer"}} className={"edit"}  onClick={() => openViewLogScreen(wingItem, floorItem, roomItem, "UpdateStatus")} /></div>
                                                                                                                :
                                                                                                                    <></>
                                                                                                            }
                                                                                                            <div style={{padding: "0px", textAlign: "center"}} className="column"><a style={{cursor: "pointer", whiteSpace: "nowrap"}} onClick={() => openViewLogScreen(wingItem, floorItem, roomItem, "ViewAuditLogs")}>{roomItem}</a></div>
                                                                                                            <div style={{padding: "0px", textAlign: "center"}} className="column"><Icon style={{cursor: "pointer"}} className={"list alternate"}  onClick={() => openViewLogScreen(wingItem, floorItem, roomItem, "ViewStatus")} /></div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </Table.Cell>
                                                                                            </>
                                                                                    })
                                                                                }
                                                                            </Table.Row>
                                                                        </>
                                                            })
                                                        }
                                                    </Table.Body>
                                                </Table>
                                            </Segment>
                                        </>
                            })
                        }
                        <Modal
                            size={"large"}
                            open={modalDataOpen}
                            onClose={() => setModalDataOpen(false)}
                            onOpen={() => setModalDataOpen(true)}
                        >
                            <Modal.Header>
                                {(modalDataOpen) ? ((modalData && modalData.heading) ? modalData.heading : props.location.linkParam.projectName) : ""}
                            </Modal.Header>
                            <Modal.Content scrolling>
                                <Modal.Description>
                                    {getModalDataContent()}
                                </Modal.Description>
                            </Modal.Content>
                            <Modal.Actions>
                                {
                                    (modalData && modalData.dataAvailable && (modalData.actionType == "UpdateStatus" || modalData.actionType == "UpdateServer"))  ?
                                        <Button onClick={() => submitStatus(modalData.actionType)} primary>
                                            Update <Icon name='refresh right' />
                                        </Button>
                                    :
                                       <></>
                                }
                                <Button onClick={() => setModalDataOpen(false)} primary>
                                    Close <Icon name='close right' />
                                </Button>
                            </Modal.Actions>
                        </Modal>
                    </div>
                :
                    <div>Invalid access</div>
            }
        </div>
    )
}