<?php

    namespace App\Utils\Security;

    use App\Model\Security\UserAccessModel;
    use App\Utils\Common\TokenUtils;
    use App\Utils\Security\SecurityConstants;
    use App\Utils\Common\SessionUtils;


    class SecurityUtils
    {
        private $sessionUtils;
        private $userAccessModel;
        private $tokenUtils;
        function __construct () {
            $this->sessionUtils = new SessionUtils();
            $this->userAccessModel = new UserAccessModel();
            $this->tokenUtils = new TokenUtils();
        }

        function getCustomerData() {
            if(SecurityConstants::$sessionValidation_Required == false){
                $tokenData = $this->tokenUtils->getTokenData();
                //echo "getCustomerData -> tokenData  " . json_encode($tokenData);
                if(isset($tokenData["user_id"])){
                    $userAccessData = $this->userAccessModel->getUserAccessDetails($tokenData['user_id']);
                    //echo "getCustomerData -> userAccessData  " . json_encode($userAccessData);
                    if($userAccessData['status']){
                        return $userAccessData['data']['company'];
                    }
                }
                //echo "getCustomerData -> Before null ";
                return null;
            }
            if(!$this->sessionUtils::getAppSession(SecurityConstants::$cacheKey_AppName, "user_access_data") == null){
                return $this->sessionUtils::getAppSession(SecurityConstants::$cacheKey_AppName, "user_access_data")->company;
            }
            return null;
        }
    }

