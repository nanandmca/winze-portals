import React from 'react'

const AppTwoStateContext = React.createContext()
const AppTwoDispatchContext = React.createContext()

function appTwoReducer(state, action) {
    switch (action.type) {
        case 'increment': {
            return {count: state.count + 1}
        }
        case 'decrement': {
            return {count: state.count - 1}
        }
        default: {
            throw new Error(`Unhandled action type: ${action.type}`)
        }
    }
}

function AppTwoProvider({children}) {
    const [state, dispatch] = React.useReducer(appTwoReducer, {count: 0})
    return (

        <AppTwoStateContext.Provider value={state}>
            <AppTwoDispatchContext.Provider value={dispatch}>
                {children}
            </AppTwoDispatchContext.Provider>
        </AppTwoStateContext.Provider>
    )
}

function useAppTwoState() {
    const context = React.useContext(AppTwoStateContext)
    if (context === undefined) {
        throw new Error('useAppTwoState must be used within a AppTwoProvider')
    }
    return context
}

function useAppTwoDispatch() {
    const context = React.useContext(AppTwoDispatchContext)
    if (context === undefined) {
        throw new Error('useAppTwoDispatch must be used within a AppTwoProvider')
    }
    return context
}

export {AppTwoProvider, useAppTwoState, useAppTwoDispatch}