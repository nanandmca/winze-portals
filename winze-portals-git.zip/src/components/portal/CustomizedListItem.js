import React from 'react';
import ListItem from "@material-ui/core/ListItem";
import {Link} from "react-router-dom";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import HomeIcon from "@material-ui/icons/Home";
import BusinessIcon from "@material-ui/icons/Business";
import Divider from "@material-ui/core/Divider";
import { makeStyles } from '@material-ui/core/styles';
import ListSubheader from '@material-ui/core/ListSubheader';
import List from '@material-ui/core/List';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import Collapse from '@material-ui/core/Collapse';
import StarBorder from '@material-ui/icons/StarBorder';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        maxWidth: 200,
        backgroundColor: theme.palette.background.paper,
    },
    nested: {
        paddingLeft: theme.spacing(4),
    },
}));

export const CustomizedListItem = (props) => {
    const classes = useStyles();
    const [open, setOpen] = React.useState(false);
    let menuItem = props.menuItem;
    let level = 0;
    if(props.level){
        level = props.level;
    }

    const handleClick = () => {
        console.log("Handle Clicked....");
        setOpen(!open);
    }

    const getMenuIcon = (iconKey) => {
        if(iconKey === "home"){
            return <HomeIcon/>;
        }else if(iconKey === "biz"){
            return <BusinessIcon/>;
        }else if(iconKey === "star"){
            return <StarBorder/>;
        }
        return <BusinessIcon/>;
    };

    const getDivider = (dividerFlag) => {
        if(dividerFlag){
            return <Divider/>;
        }
        return <></>;
    };

    return (
        (!menuItem.subHeadingRequired && !menuItem.collapsable && !menuItem.menu_list) ?
            <>
                <ListItem button key={menuItem.key} button component={Link} to={{pathname: menuItem.link, linkParam : menuItem.params}} >
                    <ListItemIcon>{getMenuIcon(menuItem.icon)}</ListItemIcon>
                    <ListItemText primary={menuItem.key}/>
                </ListItem>
                {getDivider(menuItem.divider)}
            </>
        :
            (menuItem.subHeadingRequired && menuItem.menu_list && menuItem.menu_list.length > 0) ?
                <List
                    component='li'
                    aria-labelledby="nested-list-subheader"
                    disablePadding style={{paddingLeft:  ((level + 1) * 5 ) + "px"}} key={menuItem.componentGroup}
                    subheader={
                        <ListSubheader component="div" id={"nested-list-subheader-" + menuItem.componentGroup}  style={{fontWeight : "bold", fontFamily: "Verdana", fontStyle: "italic", color: "#D62A44"}}>
                            {menuItem.subHeading}
                        </ListSubheader>
                    }
                    className={classes.root}
                >
                    {menuItem.menu_list.map((menuData) => {
                        return <CustomizedListItem menuItem={menuData} level={level + 1}/>
                    })}
                </List>
             :
                (menuItem.collapsable && menuItem.menu_list && menuItem.menu_list.length > 0) ?
                    <div>
                        <ListItem  style={{paddingLeft: (level * 15 ) + "px"}} button key={menuItem.key} onClick={() => handleClick()}>
                            <ListItemIcon><BusinessIcon/></ListItemIcon>
                            <ListItemText primary={menuItem.key} />
                            {open ? <ExpandLess /> : <ExpandMore />}
                        </ListItem>
                        <Collapse
                            key={menuItem.key}
                            in={open}
                            timeout='auto'
                            unmountOnExit
                        >
                            <List component='li' disablePadding style={{paddingLeft:  ((level + 1) * 10 ) + "px"}}>
                                {menuItem.menu_list.map((menuData) => {
                                    return <CustomizedListItem menuItem={menuData} level={level + 1}/>
                                })}
                            </List>
                        </Collapse>
                    </div>
                :
                    (menuItem.menu_list && menuItem.menu_list.length > 0) ?
                        menuItem.menu_list.map((menuData) => {
                            return <CustomizedListItem menuItem={menuData} level={level + 1}/>
                        })
                    :
                        <></>
    )

}