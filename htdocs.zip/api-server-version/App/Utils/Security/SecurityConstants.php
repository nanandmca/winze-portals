<?php


namespace App\Utils\Security;


class SecurityConstants
{
    public static $cacheKey_AppName = 'security';
    public static $sessionValidation_Required = false;

    public static $sessionKey_UserAccessData = 'user_access_data';
    public static $sessionKey_UserData = 'user_data';

}