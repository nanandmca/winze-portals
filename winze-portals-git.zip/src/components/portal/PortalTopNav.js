import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import MenuIcon from '@material-ui/icons/Menu';
import IconButton from '@material-ui/core/IconButton';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import {usePortalState} from '../../context/portal/PortalProvider'

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
        height: "80px"
    },
    menuButton: {
        marginRight: theme.spacing(2),
    },
    title: {
        flexGrow: 1,
        height: "75px"
    },
    logo: {
        width: '120px',
        padding: '5px',
        background: "white",
        borderRadius: "5px"
    }
}));

export const PortalTopNav = () => {
    const {topHeading} = usePortalState();
    const classes = useStyles();

    return (
        <Toolbar className={classes.root}>
            <Typography variant='h4'  className={classes.title} style={{fontWeight: 'bold', textAlign: 'center', marginTop: '40px'}}> {(topHeading) ? topHeading : "Winze Portals"} </Typography>
            {<Button color="inherit" href="/logout">Logout</Button>}
        </Toolbar>
    )
}