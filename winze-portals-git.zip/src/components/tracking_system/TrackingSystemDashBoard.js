import React, {useState} from 'react';
import { useTrackingSystemState, useTrackingSystemDispatch } from "../../context/tracking_system/TrackingSystemProvider";
import {INCREMENT} from './../../utils/app2/AppTwoAction'
import {Link} from "react-router-dom";
import { Accordion, Icon } from 'semantic-ui-react'
import {getProjectAccess} from "../../utils/tracking_system/TrackingSystemCache";
import {OverallSummary} from "./OverallSummary";
import {ProjectLogs} from "./ProjectLogs";

export const TrackingSystemDashBoard = (props) => {
    const {count} = useTrackingSystemState();
    const dispatch = useTrackingSystemDispatch();
    const projectAcessData = getProjectAccess();
    const [activeIndex, setActiveIndex] = useState(0);

    console.log("props " + JSON.stringify(props.location.linkParam));

    const doIncrement = () => {
        dispatch({
            type : INCREMENT
        });
    }

    const handleClick = (menuIndex) => {
        if(projectAcessData.project_access_data.length > 1){
            console.log("titleProps menuIndex " + menuIndex.menuIndex);
            const newIndex = activeIndex === menuIndex.menuIndex ? -1 : menuIndex.menuIndex;
            console.log("titleProps newIndex " + newIndex);
            setActiveIndex(newIndex);
        }
    }

    return (
        <div>
            {console.log("Inside Tracking System DashBoard")}
            {
                (projectAcessData && projectAcessData.project_access_data)
                    ?
                    <>
                    <Accordion>
                        {
                            projectAcessData.project_access_data.map(function(menuData, menuIndex){
                                return <div className="flex items-center mt-24 mb-10">
                                        <br/>
                                        {console.log("menuIndex " + menuIndex)}
                                        {console.log("activeIndex " + activeIndex)}
                                        {console.log("activeIndex=== " + (activeIndex === menuIndex))}
                                        <Accordion.Title
                                            active={activeIndex == menuIndex}
                                            index={menuIndex}
                                            onClick={() => handleClick({menuIndex})}
                                        >
                                            <h4><Icon name='dropdown' />{menuData.company_name}</h4>
                                        </Accordion.Title>
                                    <Accordion.Content active={activeIndex == menuIndex}>
                                        {console.log("Tracking System DashBoard -> menuData -> " + JSON.stringify(menuData))}
                                        {
                                            (menuData && menuData.dashboard && menuData.dashboard.OverallSummary && menuData.dashboard.OverallSummary == "Y")
                                            ?
                                                <OverallSummary company={menuData}></OverallSummary>
                                            :
                                                <></>
                                        }
                                        {
                                            (menuData && menuData.dashboard && menuData.dashboard.RoomLogs && menuData.dashboard.RoomLogs == "Y")
                                            ?
                                                <ProjectLogs company={menuData} logsType={"R"}></ProjectLogs>
                                            :
                                                <></>
                                        }
                                        {
                                            (menuData && menuData.dashboard && menuData.dashboard.ServerLogs && menuData.dashboard.ServerLogs == "Y")
                                                ?
                                                <ProjectLogs company={menuData} logsType={"S"}></ProjectLogs>
                                                :
                                                <></>
                                        }
                                    </Accordion.Content>
                                            {/**<div className="flex-grow text-right px-4 py-2 m-2">
                                     {
                                                (count) ?
                                                    <h6>Tracking System Count : {count}</h6>
                                                    :
                                                    <></>
                                            }
                                     <button onClick={() => doIncrement()} className="bg-green-400 hover:bg-green-500 text-white font-semibold py-2 px-4 rounded inline-flex items-center">
                                     <span className="pl-2">Action</span>
                                     </button>
                                     <Link to={"/"}>Home</Link>
                                     </div>**/}
                                </div>
                            })
                        }
                    </Accordion>
                    </>
                    :
                    <></>
            }
        </div>
    )
}