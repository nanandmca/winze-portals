import React from 'react';
import Typography from '@material-ui/core/Typography';
import Link from '@material-ui/core/Link';
import './../../stylesheet/common/common.css'

export const Copyright = () => {
    return (
        <Typography className="Copyright" align={"center"}>
            <span style={{"padding" : "5px"}}>
                {new Date().getFullYear()}
                {'.'}
            </span>
            <Link color="inherit" href="http://www.winzetech.com/">
                Winzetech
            </Link>{' '}
            {'Copyright © '}
        </Typography>
    )
}