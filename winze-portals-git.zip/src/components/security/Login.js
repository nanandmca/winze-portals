import React, { useState } from 'react';
import { CircularProgress, Backdrop } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { Button, Form, Grid, Header, Message, Segment } from 'semantic-ui-react'
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import { Alert } from '@material-ui/lab';
import { usePortalDispatch } from './../../context/portal/PortalProvider';
import {LOGIN } from './../../utils/portal/PortalAction';
import { aunthenticateUser } from '../../service/security/ApiService';
import { isValidServiceResponse, getFailureResponseData, getSuccessResponseData } from '../../service/common/ServiceUtils';
import {storeUserAccessData, storeUserAuthData, getUserApplicationList} from '../../utils/security/SecurityUtils';

const useStyles = makeStyles((theme) => ({
    backdrop: {
        zIndex: theme.zIndex.drawer + 1,
        color: '#fff',
    }
}));

export const Login = () => {
    const classes = useStyles();
    const dispatch = usePortalDispatch();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [isError, setIsError] = useState(false);
    const [open, setOpen] = React.useState(false);

    const aunthenticationServiceSuccess = function(successResponse){
        console.log('aunthenticationSuccess : ' + JSON.stringify(successResponse));
        if(isValidServiceResponse(successResponse)){
            let authResponse = getSuccessResponseData(successResponse);
            let stored = storeUserAuthData(authResponse);
            let userAccessDataStored = storeUserAccessData(authResponse);
            if(stored && userAccessDataStored){
                console.log('storeUserAuthData : ' + stored);
                console.log('storeUserAccessData : ' + userAccessDataStored);
                dispatch({
                    type: LOGIN,
                    payload: {
                        apps: getUserApplicationList()
                    }
                })
            }
        }
    }

    const aunthenticationServiceFailure = function(failureResponse){
        console.log('aunthenticationFailure : ' + JSON.stringify(failureResponse));
        let failureData = getFailureResponseData(failureResponse);
        console.log('failureData : ' + JSON.stringify(failureData));
        setErrorMessage("Error while login, please retry...");
        setIsError(true);
        setOpen(false);
    }

    const doLogin = (event) => {
        sessionStorage.clear();
        event.preventDefault();
        console.log("doLogin -> After preventDefault")
        let isValid = true;
        if(email.length == 0 && password.length == 0){
            setErrorMessage("Please enter email and password.");
            setIsError(true);
            isValid = false;
        }else if(email.length == 0){
            setErrorMessage("Please enter email.");
            setIsError(true);
            isValid = false;
        }else if(password.length == 0){
            setErrorMessage("Please enter password.");
            setIsError(true);
            isValid = false;
        }
        if(isValid){
            setOpen(true);
            aunthenticateUser({
                                    data:
                                        {
                                            email: email,
                                            password: password
                                        }
                                }, aunthenticationServiceSuccess, aunthenticationServiceFailure);
        }
    }

    return (
        <>
            <Grid textAlign='center' style={{ height: '80vh' }} verticalAlign='middle'>
                <Grid.Column style={{ maxWidth: 450 }}>
                    <Header as='h2' color='blue' textAlign='center'>
                        <LockOutlinedIcon /> Log-in to your account
                    </Header>
                    <Form size='large'>
                        <Segment stacked>
                            <Form.Input
                                fluid
                                icon='user'
                                iconPosition='left'
                                placeholder='E-mail address'
                                onChange={event => setEmail(event.target.value)}
                            />
                            <Form.Input
                                fluid
                                icon='lock'
                                iconPosition='left'
                                placeholder='Password'
                                type='password'
                                onChange={event => setPassword(event.target.value)}
                            />
                            {(isError) ? <Alert severity="error">{errorMessage}</Alert> : <></>}
                            <Button id="loginBtn" onClick={(event) => doLogin(event)}  color='blue' fluid size='large'>
                                Login
                            </Button>
                        </Segment>
                    </Form>
                    <Message>
                        New to us? <a href='#'>Sign Up</a>
                    </Message>
                </Grid.Column>
            </Grid>
            <Backdrop className={classes.backdrop} open={open}>
                <CircularProgress color="inherit" />
            </Backdrop>
        </>
    )
}
